// 学习目标：理解云数据库基本操作 | 核心知识点：数据库初始化、查询数据、分页加载 | 个人版限制：个人版可使用云数据库，但要注意数据安全规则

// ==================== 云数据库基础 ====================

// 知识点：初始化数据库
// 为什么需要：使用云数据库前必须初始化
const db = wx.cloud.database()

// 知识点：获取数据库命令
// 为什么需要：用于构建复杂查询条件（如大于、小于、包含等）
const _ = db.command

// ==================== 帖子列表页面 ====================

Page({
  data: {
    posts: [],           // 帖子列表
    page: 1,             // 当前页码
    hasMore: true,       // 是否有更多数据
    loading: false,      // 是否正在加载
    refreshing: false    // 是否正在刷新
  },

  onLoad() {
    this.loadPosts()
  },

  // 知识点：查询帖子列表
  // 为什么用云函数而不是直接查询：云函数可以处理复杂逻辑，如关联查询、数据脱敏
  async loadPosts() {
    if (this.data.loading) return
    this.setData({ loading: true })

    try {
      // 知识点：wx.cloud.callFunction 调用云函数
      // 为什么用云函数：帖子列表需要关联用户信息、处理图片URL等复杂逻辑
      // 个人版适配：云函数是个人版后端逻辑的主要载体
      const res = await wx.cloud.callFunction({
        name: 'forum',           // 云函数名称
        data: {
          action: 'getPosts',    // 操作类型
          data: {
            page: this.data.page,
            pageSize: 10
          }
        }
      })

      // 知识点：云函数返回结果在result中
      if (res.result && res.result.success) {
        // 知识点：数组拼接
        // 为什么用条件判断：第一页要替换，后续页要追加
        const posts = res.result.posts.map(post => ({
          ...post,
          createTimeText: this.formatTime(post.createTime)
        }))
        
        this.setData({
          posts: this.data.page === 1 ? posts : [...this.data.posts, ...posts],
          hasMore: res.result.hasMore
        })
      }
    } catch (err) {
      console.error('加载帖子失败:', err)
      wx.showToast({ title: '加载失败', icon: 'none' })
    } finally {
      this.setData({ loading: false, refreshing: false })
    }
  },

  // 知识点：直接查询数据库（简化版）
  // 为什么有时候直接查：简单查询不需要云函数，减少云函数调用次数
  async loadPostsSimple() {
    try {
      // 知识点：db.collection 获取集合引用
      // 集合相当于数据库中的"表"
      const postsCollection = db.collection('forum_post')
      
      // 知识点：where 条件查询
      // 为什么用_.neq：排除已删除的帖子
      const res = await postsCollection
        .where({
          status: _.neq('deleted')  // 状态不等于deleted
        })
        // 知识点：orderBy 排序
        // 为什么先按时间降序：最新帖子在前
        .orderBy('createTime', 'desc')
        // 知识点：limit 限制返回数量
        // 为什么限制：云数据库单次最多返回20条
        .limit(10)
        // 知识点：get 执行查询
        .get()
      
      console.log('查询结果:', res.data)
      // res.data 是查询到的数据数组
      // res.data.length 是返回的数据条数
      
    } catch (err) {
      console.error('查询失败:', err)
    }
  },

  // 知识点：分页查询
  // 为什么需要分页：数据量大时不能一次加载全部
  async loadPostsWithPaging() {
    const page = this.data.page
    const pageSize = 10
    
    // 知识点：skip 跳过指定数量
    // 为什么需要skip：实现分页，跳过已加载的数据
    const skip = (page - 1) * pageSize
    
    try {
      const res = await db.collection('forum_post')
        .where({
          status: _.neq('deleted')
        })
        .orderBy('createTime', 'desc')
        .skip(skip)    // 跳过前N条
        .limit(pageSize)
        .get()
      
      // 判断是否还有更多数据
      const hasMore = res.data.length === pageSize
      
      this.setData({
        posts: page === 1 ? res.data : [...this.data.posts, ...res.data],
        hasMore: hasMore
      })
    } catch (err) {
      console.error('分页查询失败:', err)
    }
  },

  // 下拉刷新
  onRefresh() {
    this.setData({ refreshing: true, page: 1 })
    this.loadPosts()
  },

  // 上拉加载更多
  onLoadMore() {
    if (!this.data.hasMore || this.data.loading) return
    this.setData({ page: this.data.page + 1 })
    this.loadPosts()
  },

  // 格式化时间
  formatTime(date) {
    if (!date) return ''
    const d = new Date(date)
    const now = new Date()
    const diff = now.getTime() - d.getTime()
    
    // 知识点：时间差计算
    // 为什么这样计算：更友好的时间显示
    if (diff < 60000) return '刚刚'
    if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前'
    if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前'
    if (diff < 604800000) return Math.floor(diff / 86400000) + '天前'
    
    return (d.getMonth() + 1) + '月' + d.getDate() + '日'
  },

  // 跳转到详情页
  goToDetail(e) {
    // 知识点：e.currentTarget.dataset 获取data-*传递的参数
    const postId = e.currentTarget.dataset.id
    wx.navigateTo({
      url: '/pages/detail/detail?id=' + postId
    })
  }
})

// ==================== 云数据库知识点总结 ====================

/*
知识点：数据库操作方法

1. 查询数据
- collection.get()：获取所有数据（最多20条）
- collection.doc(id).get()：根据ID获取单条
- collection.where().get()：条件查询

2. 条件操作符
- _.eq(val)：等于
- _.neq(val)：不等于
- _.gt(val)：大于
- _.gte(val)：大于等于
- _.lt(val)：小于
- _.lte(val)：小于等于
- _.in(array)：在数组中
- _.nin(array)：不在数组中
- _.or([...])：或条件
- _.and([...])：与条件

3. 排序和分页
- orderBy(field, order)：排序，order为'asc'或'desc'
- skip(n)：跳过n条
- limit(n)：限制返回n条

4. 添加数据
- collection.add({ data: {...} })

5. 更新数据
- collection.doc(id).update({ data: {...} })
- collection.where().update({ data: {...} })

6. 删除数据
- collection.doc(id).remove()
- collection.where().remove()

7. 计数
- collection.where().count()

个人版注意：
- 数据库安全规则要设置好，防止数据泄露
- 敏感操作（如删除）建议在云函数中进行
- 单次查询最多返回20条，云函数中最多100条
*/

// 学习思考题：
// 1. 为什么有时候用云函数查询，有时候直接查询数据库？
// 2. 分页查询时如何判断是否还有更多数据？
// 3. 云数据库的安全规则是什么？如何设置？
