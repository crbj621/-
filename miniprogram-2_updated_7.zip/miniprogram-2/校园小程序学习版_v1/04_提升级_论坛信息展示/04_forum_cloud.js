// 学习目标：理解云函数中的数据库操作 | 核心知识点：云函数入口、数据库CRUD、分页查询 | 个人版限制：云函数中单次查询最多100条

// 知识点：引入云开发SDK
const cloud = require('wx-server-sdk')

// 知识点：初始化云开发
// 为什么用DYNAMIC_CURRENT_ENV：自动使用当前环境
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

// 知识点：获取数据库引用
const db = cloud.database()
// 知识点：获取数据库命令
const cmd = db.command

// 知识点：云函数入口函数
// event：调用时传入的参数
// context：运行上下文，包含用户信息
exports.main = async function(event, context) {
  // 知识点：获取用户openid
  // 为什么需要：很多操作需要知道是哪个用户
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID
  
  // 知识点：从event中获取参数
  const action = event.action    // 操作类型
  const data = event.data || {}  // 操作数据

  // 知识点：路由分发
  // 为什么用switch：根据不同action执行不同操作
  try {
    switch (action) {
      case 'getPosts':
        return await getPosts(data)
      case 'getPostDetail':
        return await getPostDetail(data, openid)
      case 'createPost':
        return await createPost(openid, data)
      case 'deletePost':
        return await deletePost(openid, data)
      default:
        return { success: false, msg: '未知操作' }
    }
  } catch (error) {
    console.error('云函数错误:', error)
    return { success: false, msg: error.message }
  }
}

// ==================== 查询帖子列表 ====================

async function getPosts(data) {
  const page = data.page || 1
  const pageSize = data.pageSize || 10
  const category = data.category
  
  // 知识点：构建查询条件
  // 为什么用对象：可以动态添加条件
  const query = { status: cmd.neq('deleted') }
  
  // 知识点：可选条件
  // 为什么判断：有分类才添加分类条件
  if (category) {
    query.category = category
  }

  // 知识点：分页计算
  // skip = (页码 - 1) * 每页数量
  const skip = (page - 1) * pageSize

  // 知识点：执行查询
  // 云函数中limit最大100，小程序端最大20
  const res = await db.collection('forum_post')
    .where(query)
    .orderBy('createTime', 'desc')  // 按时间降序
    .skip(skip)
    .limit(pageSize)
    .get()

  // 知识点：数据处理
  // 为什么需要处理：原始数据可能需要格式化
  const posts = res.data.map(item => ({
    _id: item._id,
    title: item.title,
    content: item.content,
    imgList: item.imgList || [],
    authorName: item.authorName || '匿名用户',
    likeCount: item.likeCount || 0,
    commentCount: item.commentCount || 0,
    createTime: item.createTime,
    createTimeText: formatTime(item.createTime)
  }))

  // 知识点：判断是否有更多
  // 为什么这样判断：返回数量等于pageSize说明可能还有更多
  const hasMore = res.data.length === pageSize

  return {
    success: true,
    posts: posts,
    hasMore: hasMore
  }
}

// ==================== 查询帖子详情 ====================

async function getPostDetail(data, openid) {
  const postId = data.postId
  
  if (!postId) {
    return { success: false, msg: '帖子ID缺失' }
  }

  // 知识点：根据ID查询单条数据
  // doc()方法用于根据_id查询
  const postRes = await db.collection('forum_post').doc(postId).get()
  
  if (!postRes.data) {
    return { success: false, msg: '帖子不存在' }
  }

  const post = postRes.data

  // 知识点：权限检查
  // 为什么需要：已删除的帖子不能查看
  if (post.status === 'deleted') {
    return { success: false, msg: '帖子已被删除' }
  }

  // 知识点：关联查询
  // 为什么需要：帖子作者信息存在用户表中
  // 注意：云数据库不支持join，需要手动关联
  let authorInfo = { nickname: '匿名用户', avatar: '' }
  
  if (!post.isAnonymous && post._openid) {
    const userRes = await db.collection('users')
      .where({ openid: post._openid })
      .limit(1)
      .get()
    
    if (userRes.data.length > 0) {
      authorInfo = {
        nickname: userRes.data[0].nickName || '用户',
        avatar: userRes.data[0].avatarUrl || ''
      }
    }
  }

  // 知识点：查询当前用户是否已点赞/收藏
  // 为什么需要：前端需要显示点赞状态
  const likeRes = await db.collection('forum_like')
    .where({ postId: postId, _openid: openid })
    .limit(1)
    .get()

  return {
    success: true,
    post: {
      _id: post._id,
      title: post.title,
      content: post.content,
      imgList: post.imgList || [],
      authorInfo: authorInfo,
      likeCount: post.likeCount || 0,
      commentCount: post.commentCount || 0,
      isLiked: likeRes.data.length > 0,  // 是否已点赞
      createTime: post.createTime,
      createTimeText: formatTime(post.createTime)
    }
  }
}

// ==================== 创建帖子 ====================

async function createPost(openid, data) {
  const title = data.title
  const content = data.content
  const category = data.category
  const imgList = data.imgList || []
  const isAnonymous = data.isAnonymous || false

  // 知识点：参数校验
  // 为什么必须校验：防止脏数据进入数据库
  if (!title || !title.trim()) {
    return { success: false, msg: '请输入标题' }
  }
  if (!content || !content.trim()) {
    return { success: false, msg: '请输入内容' }
  }
  if (!category) {
    return { success: false, msg: '请选择分类' }
  }

  // 知识点：添加数据到数据库
  // add方法返回包含_id的对象
  const res = await db.collection('forum_post').add({
    data: {
      _openid: openid,              // 作者openid
      title: title.trim(),          // 标题（去除首尾空格）
      content: content.trim(),      // 内容
      imgList: imgList,             // 图片列表
      category: category,           // 分类
      isAnonymous: isAnonymous,     // 是否匿名
      authorName: isAnonymous ? '匿名用户' : data.nickname || '用户',
      likeCount: 0,                 // 点赞数
      commentCount: 0,              // 评论数
      collectCount: 0,              // 收藏数
      status: 'normal',             // 状态
      createTime: db.serverDate(),  // 创建时间（服务器时间）
      updateTime: db.serverDate()   // 更新时间
    }
  })

  // 知识点：db.serverDate()
  // 为什么用服务器时间：避免客户端时间不准确
  // 返回的是数据库服务器的时间

  return {
    success: true,
    postId: res._id,  // 新创建记录的_id
    msg: '发布成功'
  }
}

// ==================== 删除帖子 ====================

async function deletePost(openid, data) {
  const postId = data.postId
  
  if (!postId) {
    return { success: false, msg: '帖子ID缺失' }
  }

  // 知识点：先查询再操作
  // 为什么需要：检查帖子是否存在、是否有权限删除
  const postRes = await db.collection('forum_post').doc(postId).get()
  
  if (!postRes.data) {
    return { success: false, msg: '帖子不存在' }
  }
  
  // 知识点：权限检查
  // 只有作者才能删除自己的帖子
  if (postRes.data._openid !== openid) {
    return { success: false, msg: '无权限删除此帖子' }
  }

  // 知识点：软删除
  // 为什么不直接remove：保留数据便于恢复和审计
  await db.collection('forum_post').doc(postId).update({
    data: {
      status: 'deleted',
      updateTime: db.serverDate()
    }
  })

  return { success: true, msg: '删除成功' }
}

// ==================== 工具函数 ====================

// 格式化时间
function formatTime(value) {
  if (!value) return ''
  
  // 知识点：处理云数据库时间类型
  // 云数据库时间可能是Date对象或特殊对象
  let date
  if (typeof value.toDate === 'function') {
    date = value.toDate()  // 云数据库时间对象转Date
  } else {
    date = new Date(value)
  }
  
  const y = date.getFullYear()
  const m = String(date.getMonth() + 1).padStart(2, '0')
  const d = String(date.getDate()).padStart(2, '0')
  const hh = String(date.getHours()).padStart(2, '0')
  const mm = String(date.getMinutes()).padStart(2, '0')
  
  return `${y}-${m}-${d} ${hh}:${mm}`
}

// 学习思考题：
// 1. 为什么云函数中查询数据比小程序端直接查询更安全？
// 2. 为什么删除帖子用软删除而不是直接remove？
// 3. db.serverDate()和new Date()有什么区别？
