# 校园小程序学习版_v1 - 文件夹结构清单

```
校园小程序学习版_v1/
│
├── 01_入门级_基础语法/          【学习时长：30分钟】
│   ├── 01_app基础结构.js        # 学习目标：理解小程序"总管家"App是什么
│   ├── 02_page基础结构.js       # 学习目标：理解页面"部门经理"Page是什么
│   └── 03_基础wxml语法.wxml     # 学习目标：理解页面结构怎么写
│   └── 核心知识点：
│       ├── App()注册、globalData公共储物柜、生命周期
│       ├── Page()注册、data公告板、页面跳转API
│       └── 数据绑定{{}}、条件渲染wx:if、列表渲染wx:for
│
├── 02_基础级_全局登录/          【学习时长：1小时】
│   ├── 02_login_app.js          # 学习目标：理解全局登录状态管理
│   ├── 02_login_page.js         # 学习目标：理解登录页面实现
│   └── 02_login_cloud.js        # 学习目标：理解云函数获取openid
│   └── 核心知识点：
│       ├── globalData全局变量、wx.setStorageSync缓存
│       ├── 云函数获取openid（个人版必须）
│       └── 登录状态检查与恢复
│
├── 03_进阶级_校园跑定位/        【学习时长：1.5小时】
│   ├── 03_location_page.js      # 学习目标：理解定位API和距离计算
│   └── 03_location_page.wxml    # 学习目标：理解地图组件使用
│   └── 核心知识点：
│       ├── wx.getLocation获取位置
│       ├── wx.startLocationUpdate持续定位
│       ├── Haversine公式计算距离
│       └── map地图组件、polyline轨迹线
│
├── 04_提升级_论坛信息展示/      【学习时长：2小时】
│   ├── 04_forum_page.js         # 学习目标：理解云数据库基本操作
│   ├── 04_forum_cloud.js        # 学习目标：理解云函数中的数据库操作
│   └── 04_subpackage_config.json # 学习目标：理解小程序分包机制
│   └── 核心知识点：
│       ├── 云数据库CRUD操作
│       ├── 分页查询、条件查询
│       └── subpackages分包、preloadRule预下载
│
└── 05_合规级_消息提醒/          【学习时长：1小时】
    ├── 05_notification_page.js  # 学习目标：理解订阅消息合规实现
    └── 05_notification_cloud.js # 学习目标：理解云函数发送订阅消息
    └── 核心知识点：
        ├── 一次性订阅消息（个人版限制）
        ├── wx.requestSubscribeMessage
        ├── 订阅凭证池设计
        └── 站内通知作为备选方案
```

---

# 学习路径建议

## 第一阶段：入门级（30分钟）
**目标**：掌握小程序最基础的结构

### 学习顺序：
1. **01_app基础结构.js**（10分钟）
   - 重点理解：App()是什么、globalData是什么、生命周期是什么
   - 动手练习：修改globalData里的数据，观察console.log输出

2. **02_page基础结构.js**（10分钟）
   - 重点理解：Page()是什么、data是什么、setData为什么必须用
   - 动手练习：添加一个新变量到data，用setData更新它

3. **03_基础wxml语法.wxml**（10分钟）
   - 重点理解：{{}}数据绑定、wx:if条件渲染、wx:for列表渲染
   - 动手练习：写一个简单的列表，用wx:for渲染

### 新手常见问题：
- ❓ 为什么直接改this.data.xxx页面不变？
- ❓ onLaunch和onShow有什么区别？
- ❓ 页面栈是什么？为什么最多10层？

---

## 第二阶段：基础级（1小时）
**目标**：掌握登录功能的完整实现

### 学习顺序：
1. **02_login_app.js**（30分钟）
   - 重点理解：globalData和缓存的区别、云函数获取openid
   - 动手练习：打印openid看看是什么

2. **02_login_page.js**（20分钟）
   - 重点理解：头像上传云存储、调用全局登录方法
   - 动手练习：修改登录成功后的跳转页面

3. **02_login_cloud.js**（10分钟）
   - 重点理解：云函数入口、wxContext获取用户信息
   - 动手练习：在云开发控制台查看云函数日志

### 新手常见问题：
- ❓ 为什么个人版要用云函数获取openid？
- ❓ 头像为什么要上传到云存储？
- ❓ 缓存和globalData哪个更好？

---

## 第三阶段：进阶级（1.5小时）
**目标**：掌握定位功能和地图使用

### 学习顺序：
1. **03_location_page.js**（1小时）
   - 重点理解：wx.getLocation、wx.startLocationUpdate、距离计算
   - 动手练习：打印定位坐标，计算两点距离

2. **03_location_page.wxml**（30分钟）
   - 重点理解：map组件、markers标记点、polyline轨迹线
   - 动手练习：在地图上添加一个自定义标记点

### 新手常见问题：
- ❓ 为什么定位坐标要用gcj02？
- ❓ Haversine公式是什么？
- ❓ 为什么要过滤精度大于65米的数据？

---

## 第四阶段：提升级（2小时）
**目标**：掌握云数据库和分包机制

### 学习顺序：
1. **04_forum_page.js**（45分钟）
   - 重点理解：云数据库初始化、查询、分页
   - 动手练习：查询数据库并打印结果

2. **04_forum_cloud.js**（45分钟）
   - 重点理解：云函数中的数据库操作、软删除
   - 动手练习：创建一个帖子并查询

3. **04_subpackage_config.json**（30分钟）
   - 重点理解：subpackages配置、独立分包、预下载
   - 动手练习：配置一个简单的分包

### 新手常见问题：
- ❓ 为什么有时候用云函数查询，有时候直接查？
- ❓ 软删除是什么？为什么不直接remove？
- ❓ 分包有什么好处？

---

## 第五阶段：合规级（1小时）
**目标**：掌握个人版消息提醒的合规实现

### 学习顺序：
1. **05_notification_page.js**（30分钟）
   - 重点理解：一次性订阅消息、wx.requestSubscribeMessage
   - 动手练习：触发订阅弹窗，观察返回值

2. **05_notification_cloud.js**（30分钟）
   - 重点理解：订阅凭证池、云函数发送消息
   - 动手练习：在云函数中发送一条测试消息

### 新手常见问题：
- ❓ 为什么个人版只能用一次性订阅？
- ❓ 订阅凭证池是什么？
- ❓ 用户拒绝订阅怎么办？

---

# 个人版小程序核心限制速查表

| 功能 | 个人版 | 企业版 |
|------|--------|--------|
| 微信登录 | ❌ 不能用wx.login | ✅ 可以用 |
| 获取头像昵称 | ❌ 不能自动获取 | ✅ 可以用getUserProfile |
| openid获取 | ✅ 云函数获取 | ✅ 服务端解密 |
| 订阅消息 | ⚠️ 只能一次性订阅 | ✅ 可用长期订阅 |
| 支付功能 | ❌ 不能用 | ✅ 可以用 |
| 云开发 | ✅ 可以用 | ✅ 可以用 |
| 分包 | ✅ 主包2MB/总包20MB | ✅ 同左 |

---

# 新手避坑指南

## 1. 数据绑定相关
```
❌ 错误写法：this.data.motto = '新值'
✅ 正确写法：this.setData({ motto: '新值' })
```

## 2. null判断相关
```
❌ 错误写法：if (userInfo.nickName)  // userInfo可能是null
✅ 正确写法：if (userInfo && userInfo.nickName)
```

## 3. 异步操作相关
```
❌ 错误写法：const res = wx.cloud.callFunction({ name: 'login' })
✅ 正确写法：const res = await wx.cloud.callFunction({ name: 'login' })
            // 记得函数前加async
```

## 4. 页面跳转相关
```
❌ TabBar页面用navigateTo会报错
✅ TabBar页面必须用switchTab
```

## 5. 缓存相关
```
❌ wx.getStorage('key') 返回Promise，不是值
✅ wx.getStorageSync('key') 直接返回值
```

---

祝学习顺利！🎉
