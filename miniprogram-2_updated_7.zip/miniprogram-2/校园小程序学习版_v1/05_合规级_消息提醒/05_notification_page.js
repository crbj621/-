// 学习目标：理解个人版小程序消息提醒合规实现 | 核心知识点：一次性订阅消息、wx.requestSubscribeMessage、模板消息 | 个人版限制：个人版只能用一次性订阅消息，不能用长期订阅消息

Page({
  data: {
    notifications: [],    // 通知列表
    loading: false,
    hasMore: true
  },

  onLoad() {
    this.loadNotifications()
  },

  // ==================== 通知列表 ====================

  // 知识点：加载通知列表
  // 为什么用云函数：通知存储在云数据库中
  async loadNotifications() {
    if (this.data.loading) return
    this.setData({ loading: true })

    try {
      const res = await wx.cloud.callFunction({
        name: 'forum',
        data: {
          action: 'getNotifications',
          page: 1,
          pageSize: 20
        }
      })

      if (res.result && res.result.success) {
        this.setData({
          notifications: res.result.notifications
        })
      }
    } catch (err) {
      console.error('加载通知失败:', err)
    } finally {
      this.setData({ loading: false })
    }
  },

  // 标记已读
  async markAsRead(notificationId) {
    try {
      await wx.cloud.callFunction({
        name: 'forum',
        data: {
          action: 'markNotificationRead',
          notificationId: notificationId
        }
      })
      
      // 更新本地状态
      const notifications = this.data.notifications.map(item => {
        if (item._id === notificationId) {
          return { ...item, isRead: true }
        }
        return item
      })
      this.setData({ notifications })
    } catch (err) {
      console.error('标记已读失败:', err)
    }
  },

  // ==================== 订阅消息（核心知识点） ====================

  // 知识点：wx.requestSubscribeMessage 请求订阅消息
  // 为什么需要订阅：微信规定，发送消息前必须用户主动订阅
  // 个人版限制：个人版只能使用一次性订阅消息
  // 
  // 一次性订阅 vs 长期订阅：
  // - 一次性订阅：用户每次订阅只能收到一条消息，需要多次订阅才能收到多条
  // - 长期订阅：用户订阅一次可以长期接收消息（仅企业版可用）
  // 
  // 个人版适配：只能用一次性订阅，需要设计"订阅凭证池"机制
  requestSubscribe() {
    // 知识点：tmplIds 模板ID数组
    // 为什么是数组：可以一次请求多个模板的订阅
    // 模板ID：在微信公众平台-订阅消息中创建模板后获取
    // 易错点：模板ID必须与小程序AppID匹配
    wx.requestSubscribeMessage({
      tmplIds: ['模板ID1', '模板ID2'],  // 替换为你的模板ID
      
      // 知识点：success 回调
      // 返回值：{ '模板ID': 'accept' | 'reject' | 'ban' }
      // - accept：用户同意订阅
      // - reject：用户拒绝订阅
      // - ban：被后台封禁
      success: (res) => {
        console.log('订阅结果:', res)
        
        // 知识点：检查每个模板的订阅结果
        if (res['模板ID1'] === 'accept') {
          // 用户同意订阅，保存订阅凭证
          this.saveSubscriptionCredential('模板ID1')
          wx.showToast({ title: '订阅成功', icon: 'success' })
        } else if (res['模板ID1'] === 'reject') {
          wx.showToast({ title: '您拒绝了订阅', icon: 'none' })
        }
      },
      
      fail: (err) => {
        console.error('订阅失败:', err)
        // 常见错误：
        // - 模板ID不存在
        // - 用户关闭了订阅消息开关
      }
    })
  },

  // 知识点：保存订阅凭证
  // 为什么需要保存：一次性订阅只能发一条消息，需要记录用户订阅了几次
  // 个人版适配：这是个人版实现"多次消息"的关键
  async saveSubscriptionCredential(tmplId) {
    try {
      const app = getApp()
      const openid = app.getOpenIdSync()
      
      // 知识点：将订阅凭证存入数据库
      // 每次订阅增加一条记录，发送消息时消耗一条
      await wx.cloud.callFunction({
        name: 'notification',
        data: {
          action: 'saveCredential',
          tmplId: tmplId
        }
      })
      
      console.log('订阅凭证已保存')
    } catch (err) {
      console.error('保存订阅凭证失败:', err)
    }
  },

  // ==================== 发送订阅消息（云函数中执行） ====================

  // 知识点：发送订阅消息的流程
  // 注意：发送操作必须在云函数中进行，小程序端无法直接发送
  // 
  // 流程：
  // 1. 用户点击订阅 -> wx.requestSubscribeMessage
  // 2. 用户同意 -> 保存订阅凭证到数据库
  // 3. 触发发送条件（如评论被回复）-> 云函数发送消息
  // 4. 发送成功 -> 删除已使用的凭证
  // 
  // 个人版适配：每次发送消耗一个凭证，凭证用完则无法发送

  // 触发发送订阅消息的场景示例
  async triggerNotification(toOpenid, type, content) {
    try {
      // 知识点：调用云函数发送消息
      // 为什么用云函数：发送订阅消息需要云调用权限
      const res = await wx.cloud.callFunction({
        name: 'notification',
        data: {
          action: 'sendNotification',
          toOpenid: toOpenid,
          type: type,
          content: content
        }
      })
      
      if (res.result && res.result.success) {
        console.log('通知发送成功')
      } else {
        // 可能的原因：用户没有订阅凭证
        console.log('通知发送失败:', res.result.msg)
      }
    } catch (err) {
      console.error('发送通知失败:', err)
    }
  },

  // ==================== 个人版订阅消息最佳实践 ====================

  // 知识点：订阅凭证池设计
  // 为什么需要凭证池：一次性订阅只能发一条，需要管理用户订阅次数
  // 
  // 设计思路：
  // 1. 用户每次订阅，在数据库中增加一条凭证记录
  // 2. 发送消息时，查询用户是否有可用凭证
  // 3. 发送成功后，删除已使用的凭证
  // 
  // 数据库设计：
  // subscription_credentials 集合：
  // {
  //   _openid: '用户openid',
  //   tmplId: '模板ID',
  //   createTime: Date,
  //   used: false
  // }

  // 引导用户订阅的最佳时机
  // 1. 用户发布内容后（可能收到评论通知）
  // 2. 用户参与活动前（活动开始提醒）
  // 3. 用户设置提醒时（如定时提醒）
  // 
  // 易错点：不要在页面加载时立即弹出订阅弹窗，用户体验差

  // 知识点：订阅消息审核注意事项
  // 1. 模板内容必须与实际业务匹配
  // 2. 不能发送营销类消息
  // 3. 不能诱导用户订阅
  // 4. 发送频率不能过高
  // 
  // 个人版特别注意：
  // - 个人版审核更严格
  // - 违规可能导致小程序被封禁
  // - 建议只发送用户主动请求的通知

  goBack() {
    wx.navigateBack()
  }
})

// ==================== 知识点总结 ====================

/*
知识点：订阅消息类型对比

| 特性         | 一次性订阅（个人版可用） | 长期订阅（仅企业版） |
|-------------|------------------------|-------------------|
| 订阅次数     | 每次订阅发1条          | 订阅一次长期有效    |
| 适用场景     | 评论回复、活动提醒     | 课程提醒、账单通知  |
| 个人版可用   | ✓                      | ✗                 |
| 审核难度     | 较低                   | 较高              |

知识点：订阅消息模板

1. 在微信公众平台创建模板
2. 选择合适的模板类型
3. 自定义模板内容（有字数限制）
4. 提交审核（1-7天）
5. 审核通过后获取模板ID

知识点：发送订阅消息参数

wx.cloud.openapi.subscribeMessage.send({
  touser: '接收者openid',
  templateId: '模板ID',
  page: '点击跳转页面',
  data: {
    // 模板中定义的字段
    thing1: { value: '内容1' },
    time2: { value: '2024-01-01 12:00' }
  }
})

个人版合规建议：
1. 只发送用户主动请求的通知
2. 每次发送前检查用户是否有订阅凭证
3. 提供取消订阅的入口
4. 不要频繁发送消息打扰用户
*/

// 学习思考题：
// 1. 为什么个人版只能用一次性订阅消息？这对产品设计有什么影响？
// 2. 如何设计"订阅凭证池"来支持多次消息发送？
// 3. 订阅消息审核有哪些注意事项？如何避免违规？
