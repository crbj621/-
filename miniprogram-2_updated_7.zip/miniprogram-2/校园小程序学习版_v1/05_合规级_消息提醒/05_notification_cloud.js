// 学习目标：理解云函数中发送订阅消息 | 核心知识点：云调用、subscribeMessage.send、订阅凭证管理 | 个人版限制：个人版只能发送一次性订阅消息，需要管理凭证池

// 知识点：引入云开发SDK
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

const db = cloud.database()
const cmd = db.command

// 知识点：云函数入口
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID
  const { action, toOpenid, type, content, relatedId, tmplId } = event

  switch (action) {
    case 'saveCredential':
      return await saveCredential(openid, tmplId)
    case 'sendNotification':
      return await sendNotification(openid, toOpenid, type, content, relatedId)
    case 'getNotifications':
      return await getNotifications(openid, event)
    case 'markAsRead':
      return await markAsRead(openid, relatedId)
    default:
      return { success: false, errMsg: 'Unknown action' }
  }
}

// ==================== 保存订阅凭证 ====================

// 知识点：保存订阅凭证
// 为什么需要：用户订阅后记录凭证，发送时消耗
// 个人版适配：这是实现"多次消息"的关键
async function saveCredential(openid, tmplId) {
  try {
    // 知识点：将订阅凭证存入数据库
    // 每次订阅增加一条记录
    await db.collection('subscription_credentials').add({
      data: {
        _openid: openid,
        tmplId: tmplId,           // 模板ID
        used: false,              // 是否已使用
        createTime: db.serverDate()
      }
    })
    
    return { success: true, msg: '凭证保存成功' }
  } catch (e) {
    console.error('保存凭证失败:', e)
    return { success: false, errMsg: e.message }
  }
}

// ==================== 发送订阅消息 ====================

// 知识点：发送订阅消息
// 注意：必须在云函数中调用，小程序端无法直接发送
async function sendNotification(fromOpenid, toOpenid, type, content, relatedId) {
  try {
    // 知识点：查询接收者是否有可用凭证
    // 个人版适配：必须检查凭证，否则发送会失败
    const credentialRes = await db.collection('subscription_credentials')
      .where({
        _openid: toOpenid,
        used: false
      })
      .limit(1)
      .get()

    // 知识点：没有凭证时的处理
    // 为什么返回特定消息：前端可以提示用户订阅
    if (credentialRes.data.length === 0) {
      // 没有订阅凭证，改为站内通知
      await db.collection('notifications').add({
        data: {
          fromOpenid: fromOpenid,
          toOpenid: toOpenid,
          type: type,
          content: content,
          relatedId: relatedId,
          read: false,
          createTime: db.serverDate()
        }
      })
      
      return { success: true, msg: '已发送站内通知（无订阅凭证）' }
    }

    const credential = credentialRes.data[0]

    // 知识点：获取发送者信息
    const fromUserRes = await db.collection('users')
      .where({ openid: fromOpenid })
      .limit(1)
      .get()
    
    const fromName = fromUserRes.data.length > 0 
      ? (fromUserRes.data[0].nickName || '用户') 
      : '用户'

    // 知识点：cloud.openapi.subscribeMessage.send 发送订阅消息
    // 这是云调用接口，只能在云函数中使用
    // 个人版适配：个人版模板有特定限制，需选择合适的模板
    try {
      await cloud.openapi.subscribeMessage.send({
        touser: toOpenid,                    // 接收者openid
        templateId: '你的模板ID',            // 替换为实际模板ID
        page: 'pages/index/index',           // 点击跳转页面
        // 知识点：data 模板数据
        // 字段名必须与模板中定义的一致
        // 常见字段类型：thing（事物）、time（时间）、number（数字）
        data: {
          thing1: {                          // 通知类型
            value: getNotificationTypeText(type)
          },
          thing2: {                          // 通知内容
            value: content.substring(0, 20)  // 有字数限制，需截断
          },
          time3: {                           // 通知时间
            value: formatTime(new Date())
          },
          thing4: {                          // 发送者
            value: fromName
          }
        },
        // 知识点：miniprogramState 跳转小程序类型
        // developer：开发版
        // trial：体验版
        // formal：正式版（默认）
        miniprogramState: 'formal'
      })

      // 知识点：发送成功后标记凭证已使用
      await db.collection('subscription_credentials')
        .doc(credential._id)
        .update({
          data: { used: true }
        })

      // 同时保存站内通知
      await db.collection('notifications').add({
        data: {
          fromOpenid: fromOpenid,
          toOpenid: toOpenid,
          type: type,
          content: content,
          relatedId: relatedId,
          read: false,
          sentToWechat: true,  // 标记已发送微信通知
          createTime: db.serverDate()
        }
      })

      return { success: true, msg: '通知发送成功' }
      
    } catch (sendErr) {
      // 知识点：发送失败处理
      // 常见错误：
      // - 用户拒收消息
      // - 模板ID不正确
      // - 模板参数不匹配
      console.error('发送订阅消息失败:', sendErr)
      
      // 发送失败也保存站内通知
      await db.collection('notifications').add({
        data: {
          fromOpenid: fromOpenid,
          toOpenid: toOpenid,
          type: type,
          content: content,
          relatedId: relatedId,
          read: false,
          createTime: db.serverDate()
        }
      })
      
      return { success: true, msg: '已发送站内通知（微信通知失败）' }
    }

  } catch (e) {
    console.error('发送通知失败:', e)
    return { success: false, errMsg: e.message }
  }
}

// ==================== 获取通知列表 ====================

async function getNotifications(openid, event) {
  const page = event.page || 1
  const pageSize = event.pageSize || 20
  const skip = (page - 1) * pageSize

  try {
    const res = await db.collection('notifications')
      .where({ toOpenid: openid })
      .orderBy('createTime', 'desc')
      .skip(skip)
      .limit(pageSize)
      .get()

    return res.data
  } catch (e) {
    console.error('获取通知失败:', e)
    return []
  }
}

// ==================== 标记已读 ====================

async function markAsRead(openid, notificationId) {
  try {
    await db.collection('notifications')
      .where({
        _id: notificationId,
        toOpenid: openid
      })
      .update({
        data: { read: true }
      })
    
    return { success: true }
  } catch (e) {
    console.error('标记已读失败:', e)
    return { success: false, errMsg: e.message }
  }
}

// ==================== 工具函数 ====================

function getNotificationTypeText(type) {
  const typeMap = {
    'comment': '评论回复',
    'like': '点赞通知',
    'follow': '新粉丝',
    'system': '系统通知'
  }
  return typeMap[type] || '新通知'
}

function formatTime(date) {
  const y = date.getFullYear()
  const m = String(date.getMonth() + 1).padStart(2, '0')
  const d = String(date.getDate()).padStart(2, '0')
  const hh = String(date.getHours()).padStart(2, '0')
  const mm = String(date.getMinutes()).padStart(2, '0')
  return `${y}-${m}-${d} ${hh}:${mm}`
}

// ==================== 知识点总结 ====================

/*
知识点：订阅消息发送流程

1. 用户订阅
   wx.requestSubscribeMessage({ tmplIds: ['xxx'] })
   ↓
2. 保存凭证
   subscription_credentials 集合新增记录
   ↓
3. 触发发送
   云函数调用 cloud.openapi.subscribeMessage.send
   ↓
4. 消耗凭证
   标记凭证为已使用
   ↓
5. 发送完成
   用户收到微信通知

知识点：个人版订阅消息限制

1. 只能使用一次性订阅
2. 每次订阅只能发一条消息
3. 模板需审核通过
4. 不能发送营销类消息

知识点：常见错误码

- 43101：用户拒绝接收消息
- 47003：模板参数不准确
- 40001：不合法的凭证
- 40003：不合法的openid

个人版合规建议：
1. 实现站内通知作为备选方案
2. 用户无订阅凭证时降级为站内通知
3. 在合适时机引导用户订阅
4. 避免频繁发送打扰用户
*/

// 学习思考题：
// 1. 为什么发送订阅消息必须在云函数中进行？
// 2. 如何设计"订阅凭证池"来支持多次消息发送？
// 3. 当用户没有订阅凭证时，如何保证通知送达？
