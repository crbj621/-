// ============================================================
// 【学习目标】理解小程序的"总管家"——App是什么
// 【核心知识点】App()注册、globalData公共储物柜、生命周期
// 【个人版限制】无特殊限制
// ============================================================

// 【是什么】App({...}) —— 创建小程序的"总管家"
// 【为什么】·1·
  //          每个页面（部门）都需要共享一些数据，比如"当前用户是谁"
  //          globalData就是放在公司大厅的公共储物柜，所有人都能存取
  // 【新手坑】❌ 在页面里直接定义变量，其他页面访问不到
  //          ✓ 需要共享的数据，必须放在globalData里
  // ============================================================
  globalData: {
    
    // 【是什么】userInfo —— 用户信息（头像、昵称等）
    // 【为什么】用户登录后，所有页面都要知道"用户是谁"
    //          放在globalData里，任何页面都能取用
    // 【为什么初始值是null】null表示"空的、没有值"
    //          用户还没登录时，userInfo就是空的
    // 【新手坑】❌ 初始值写成undefined，后面判断容易出错
    //          ✓ 用null表示"暂无数据"更清晰
    userInfo: null,
    
    // 【是什么】openid —— 用户的"身份证号"
    // 【为什么】微信给每个用户分配一个唯一标识，就像身份证号
    //          有了openid，我们就能识别"这是哪个用户"
    // 【为什么初始值是空字符串】空字符串''和null不同：
    //          null = 什么都没有
    //          '' = 有东西，但内容是空的
    // 【新手坑】❌ 判断openid时写成 if(openid) 会出错（null和''都算false）
    //          ✓ 判断写成 if(openid !== '') 更准确
    openid: '',
    
    // 【是什么】hasUserInfo —— "用户登录了吗"的标记
    // 【为什么】布尔值（true/false）就像开关，只有两个状态
    //          true = 已登录，false = 未登录
    //          比判断userInfo是否为null更直观
    // 【新手坑】❌ 用数字0和1表示，代码可读性差
    //          ✓ 用布尔值，一看就懂
    hasUserInfo: false
  },

  // ============================================================
  // 【是什么】o开业典礼"的流程清单
  // 【什么时候执行】小程序第一次启动时执nLaunch —— 小程序"开业典礼"
  // 【为什么】小程序启动时，就像公司开业，需要做一些初始化工作
  //          onLaunch就是"行，整个生命周期只执行一次
  // 【新手坑】❌ 在onLaunch里做耗时操作，会导致小程序启动很慢
  //          ✓ 只做必要的初始化，其他事情延后处理
  // ============================================================
  onLaunch() {
    
    // 【是什么】console.log() —— "小纸条打印"
    // 【为什么】开发时需要知道代码执行到哪一步、数据是什么
    //          console.log()就是把信息打印到"调试器"这个小纸条上
    // 【怎么查看】在微信开发者工具的"调试器-Console"面板查看
    // 【新手坑】❌ 上线前忘了删除console.log，影响性能（虽然影响很小）
    //          ✓ 开发时尽情用，上线前检查删除
    console.log('小程序启动了，总管家开始工作！')
    
    // 【是什么】wx.getStorageSync —— 从"本地仓库"取东西
    // 【为什么】用户上次登录的信息，我们存在了手机的"本地仓库"里
    //          wx.getStorageSync就是去仓库取东西
    //          'userInfo'是储物柜的"编号/名字"
    // 【Sync是什么意思】Sync = 同步 = 等取到东西再往下执行
    //          就像去快递柜取快递，取到快递才走
    // 【与Async区别】Async = 异步 = 先去取，不等结果，回头再来拿
    // 【新手坑】❌ 写成wx.getStorage（没有Sync），返回的是Promise对象
    //          ✓ 初学者建议用Sync版本，代码更直观
    const cachedUserInfo = wx.getStorageSync('userInfo')
    
    // 【是什么】if判断 —— "如果...就..."
    // 【为什么】用户可能是"老用户"（之前登录过），也可能是"新用户"
    //          老用户的信息存在仓库里，我们需要取出来恢复登录状态
    //          if(cachedUserInfo) = 如果仓库里有用户信息
    // 【如果不写if会怎样】cachedUserInfo可能是null，null没有属性
    //          访问null.nickName会报错：Cannot read property 'nickName' of null
    // 【新手坑】❌ 忘了判断null，直接用变量，程序崩溃
    //          ✓ 养成习惯：从外部获取的数据，先判断是否存在
    if (cachedUserInfo) {
      
      // 【是什么】this —— "我自己"
      // 【为什么】在App里，this指向App这个"总管家"
      //          this.globalData = App的globalData = 总管家的公共储物柜
      // 【新手坑】❌ 在某些回调函数里，this可能不是App
      //          ✓ 用箭头函数(() => {})可以保持this指向
      // 【是什么】赋值 = 把右边的东西放进左边
      // 【两行赋值的区别】
      //          this.globalData.userInfo = cachedUserInfo（放进储物柜）
      //          cachedUserInfo = this.globalData.userInfo（从储物柜取出）
      //          = 是"从右往左"赋值！
      this.globalData.userInfo = cachedUserInfo
      
      // 【是什么】true —— "真/是"
      // 【为什么】找到用户信息了，就把"已登录"标记改为true
      //          就像开关从OFF拨到ON
      this.globalData.hasUserInfo = true
      
      console.log('从本地仓库恢复用户信息成功！', cachedUserInfo)
    }
    
    // 【是什么】if(!xxx) —— "如果没有..."
    // 【为什么】!是"非/不是"的意思
    //          !cachedUserInfo = 缓存里没有用户信息
    //          新用户第一次来，需要引导登录
    if (!cachedUserInfo) {
      console.log('新用户，需要登录')
      // 这里可以跳转到登录页
    }
  ,

  // ============================================================
  // 【是什么】onShow —— 小程序"开门营业"
  // 【为什么】小程序可能被用户"最小化"（按Home键）
  //          用户再切回来时，onShow就会执行
  // 【与onLaunch区别】
  //          onLaunch = 开业典礼，只执行一次
  //          onShow = 开门营业，每次用户回来都执行
  // 【什么时候执行】
  //          1. 小程序首次启动（onLaunch之后）
  //          2. 从后台切回前台
  //          3. 从其他小程序返回
  // 【新手坑】❌ 把只需要执行一次的代码放在onShow，会重复执行
  //          ✓ 初始化代码放onLaunch，刷新代码放onShow
  // ============================================================
  onShow() {
    console.log('小程序显示了，开门营业！')
  },

  // ============================================================
  // 【是什么】onHide —— 小程序"打烊休息"
  // 【为什么】用户按Home键、切换到其他App时，小程序进入后台
  //          这时可以保存数据，防止丢失
  // 【什么时候执行】
  //          1. 用户按Home键
  //          2. 切换到其他小程序
  //          3. 手机锁屏
  // 【新手坑】❌ 以为onHide时小程序就关闭了，其实还在后台运行
  //          ✓ 重要数据要在onHide时保存
  // ============================================================
  onHide() {
    console.log('小程序隐藏了，打烊休息！')
    
    // 【是什么】if判断 + 多条件
    // 【为什么】this.globalData.userInfo 可能是null
    //          如果是null，访问.userInfo.nickName会报错
    //          所以先判断userInfo存在，再判断nickName存在
    // 【&&是什么】"并且"的意思，两个条件都要满足
    //          就像"你要有票并且有钱才能进"
    // 【如果不判断会怎样】
    //          报错：Cannot read property 'nickName' of null
    //          程序崩溃，用户看到空白页
    if (this.globalData.userInfo && this.globalData.userInfo.nickName) {
      // 【是什么】wx.setStorageSync —— 往"本地仓库"存东西
      // 【为什么】用户可能很久不来，内存里的数据会丢失
      //          存到本地仓库（手机存储），下次来还能找到
      // 【参数】('储物柜名字', 要存的东西)
      this.globalData.userInfo
    }
  },

  // ============================================================
  // 【是什么】自定义方法 —— 总管家的"技能"
  // 【为什么】有些功能很多页面都要用，比如"检查用户登录了吗"
  //          写在App里，所有页面都能调用
  // 【怎么调用】const app = getApp() 获取总管家
  //            app.isLoggedIn() 调用总管家的技能
  // ============================================================
  
  // 【技能】获取用户信息
  getUserInfo() {
    // 【是什么】if...else if... —— 多重判断
    // 【为什么】获取用户信息有两个来源：
    //          1. 内存里的globalData（最快）
    //          2. 本地仓库的缓存（备用）
    //          先查内存，内存没有再查仓库
    if (this.globalData.userInfo) {
      // 内存里有，直接返回
      return this.globalData.userInfo
    }
    // 【是什么】return —— "返回结果，结束函数"
    // 【为什么】函数执行到return就结束了，后面的代码不执行
    //          return xxx = 把xxx作为结果交还给调用者
    // 【新手坑】❌ 忘了return，调用者收到undefined
    //          ✓ 需要返回结果的函数，记得return
    return wx.getStorageSync('userInfo') || null
    // 【是什么】|| —— "或者"
    // 【为什么】wx.getStorageSync('userInfo')可能返回空字符串''
    //          空字符串是"假值"，|| 会返回后面的null
    //          这样保证返回值要么是用户信息，要么是null
  },

  // 【技能】检查登录状态
  isLoggedIn() {
    // 【是什么】!! —— "转成布尔值"
    // 【为什么】有时候值不是true/false，但我们需要判断真假
    //          !userInfo = 把值取反（变成true/false）
    //          !!userInfo = 再取反（恢复原意，但变成了布尔值）
    // 【例子】
    //          !!null = !(!null) = !(true) = false
    //          !!'hello' = !(!'hello') = !(false) = true
    //          !!'' = !(!'') = !(true) = false
    // 【新手坑】❌ 直接用if(userInfo)，可能把空字符串当true
    //          ✓ 用!!明确转成布尔值
    return !!(this.globalData.userInfo && this.globalData.userInfo.nickName)
  }
})

// ============================================================
// 【如果删掉if判断会怎样？】
// 比如删掉 onLaunch 里的 if (cachedUserInfo)：
// 
// const cachedUserInfo = wx.getStorageSync('userInfo')  // 可能是null
// this.globalData.userInfo = cachedUserInfo  // 把null赋值给userInfo
// this.globalData.hasUserInfo = true  // 标记为已登录（但实际没登录）
// 
// 结果：
// 1. 新用户第一次打开，userInfo是null，但hasUserInfo是true
// 2. 页面显示"已登录"，但实际没有用户数据
// 3. 显示昵称时报错：Cannot read property 'nickName' of null
// 4. 用户看到空白页或报错页面
//
// ============================================================

// ============================================================
// 【新手优化建议】
// 
// 1. 添加注释说明每个变量的用途
// 2. 用有意义的变量名（userInfo比u更清晰）
// 3. 判断条件可以更严格：
//    if (cachedUserInfo && cachedUserInfo.nickName) { ... }
// 4. 添加错误处理：
//    try { ... } catch(e) { console.error(e) }
// 5. 上线前删除console.log
//
// ============================================================

// ============================================================
// 【学习思考题】
// 1. globalData里的数据在小程序重启后为什么会丢失？
//    提示：globalData存在内存里，重启后内存清空
//    解决：用wx.setStorageSync存到本地
// 
// 2. onLaunch和onShow有什么区别？
//    提示：onLaunch只执行一次，onShow每次显示都执行
// 
// 3. 为什么推荐用缓存而不是云数据库存储简单数据？
//    提示：缓存免费、快速、离线可用；云数据库需要网络、有成本
// ============================================================
