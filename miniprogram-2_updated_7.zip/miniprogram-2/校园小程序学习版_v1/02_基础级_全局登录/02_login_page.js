// 学习目标：理解登录页面实现 | 核心知识点：头像选择、昵称输入、云存储上传、调用全局登录方法 | 个人版限制：个人版无法获取微信头像昵称，需用户手动填写

Page({
  // 知识点：data 页面数据
  // 为什么需要这些数据：登录表单需要收集头像和昵称
  data: {
    isLoading: false,      // 为什么需要：防止重复提交
    userInfo: {
      avatarUrl: '',       // 头像URL
      nickName: ''         // 昵称
    },
    tempAvatarPath: ''     // 临时头像路径，用于判断是否需要上传
  },

  // 知识点：onLoad 页面加载生命周期
  // 为什么检查登录：已登录用户直接跳转，无需重复登录
  onLoad(options) {
    this.checkLogin(options)
  },

  // 检查登录状态
  checkLogin(options) {
    // 知识点：getApp() 获取全局App实例
    // 为什么用getApp：访问全局方法和数据
    const app = getApp()
    
    // 为什么有forceLogin参数：某些场景需要强制重新登录
    if (options.forceLogin === 'true') {
      console.log('强制登录模式，不检查登录状态')
      return
    }
    
    // 已登录则跳转
    if (app.isLoggedIn()) {
      console.log('已登录，跳转到首页')
      wx.redirectTo({
        url: '/pages/index/index'
      })
    }
  },

  // 知识点：头像选择回调
  // 为什么用open-type="chooseAvatar"：个人版无法调用wx.getUserProfile，用button的open-type
  // 个人版适配：这是个人版获取头像的标准方式
  onChooseAvatar(e) {
    // 知识点：e.detail.avatarUrl 是选择的头像临时路径
    // 为什么是临时路径：微信返回的是本地临时文件，需要上传到云存储才能持久化
    const avatarUrl = e.detail.avatarUrl
    console.log('选择的头像路径:', avatarUrl)
    
    this.setData({
      'userInfo.avatarUrl': avatarUrl,
      tempAvatarPath: avatarUrl  // 记录临时路径，后续上传用
    })
  },

  // 昵称输入回调
  onNicknameInput(e) {
    this.setData({
      'userInfo.nickName': e.detail.value
    })
  },

  // 昵称失焦回调
  // 为什么需要onBlur：确保最终值被记录
  onNicknameBlur(e) {
    this.setData({
      'userInfo.nickName': e.detail.value
    })
  },

  // 知识点：执行登录
  // 为什么是async函数：头像上传和云函数调用都是异步操作
  async doLogin() {
    const { userInfo, tempAvatarPath } = this.data
    
    // 表单验证
    if (!userInfo.nickName) {
      wx.showToast({ title: '请输入昵称', icon: 'none' })
      return
    }
    
    // 防止重复提交
    this.setData({ isLoading: true })
    wx.showLoading({ title: '登录中...', mask: true })
    
    try {
      let avatarUrl = userInfo.avatarUrl || ''
      
      // 知识点：头像上传到云存储
      // 为什么需要上传：临时文件会过期，需要持久化存储
      // 个人版适配：云存储是个人版最简单的文件存储方案
      if (tempAvatarPath) {
        // 判断是否是临时路径
        const isTempPath = tempAvatarPath.indexOf('wxfile://') === 0 || 
                          tempAvatarPath.indexOf('http://tmp') === 0 ||
                          tempAvatarPath.indexOf('https://tmp') === 0
        
        if (isTempPath) {
          wx.showLoading({ title: '上传头像...', mask: true })
          
          // 知识点：wx.cloud.uploadFile 上传文件到云存储
          // cloudPath：云存储路径，建议用时间戳+随机数避免重名
          // filePath：本地文件路径
          const cloudPath = 'avatars/' + Date.now() + '-' + Math.random().toString(36).substr(2, 9) + '.jpg'
          
          const uploadRes = await wx.cloud.uploadFile({
            cloudPath: cloudPath,
            filePath: tempAvatarPath
          })
          
          // 知识点：uploadRes.fileID 是云存储文件ID
          // 为什么用fileID：这是云存储的唯一标识，可以用来下载或获取临时URL
          if (uploadRes.fileID) {
            avatarUrl = uploadRes.fileID
            console.log('头像上传成功:', avatarUrl)
          }
        }
      }
      
      // 调用全局登录方法
      const app = getApp()
      const result = await app.doLogin({
        nickName: userInfo.nickName,
        avatarUrl: avatarUrl
      })
      
      wx.hideLoading()
      
      if (result.success) {
        wx.showToast({ title: '登录成功', icon: 'success' })
        // 延迟跳转，让用户看到成功提示
        setTimeout(() => {
          wx.redirectTo({
            url: '/pages/index/index'
          })
        }, 1000)
      } else {
        wx.showToast({ title: result.message || '登录失败', icon: 'none' })
        this.setData({ isLoading: false })
      }
    } catch (err) {
      wx.hideLoading()
      console.error('登录失败:', err)
      wx.showToast({ title: '登录失败', icon: 'none' })
      this.setData({ isLoading: false })
    }
  },

  // 跳过登录
  // 为什么需要跳过：允许用户先体验，后续再登录
  skipLogin() {
    const app = getApp()
    const openid = app.getOpenIdSync()
    
    // 保存openid，用于标识用户
    if (openid) {
      wx.setStorageSync('openid', openid)
    }
    
    // 标记为跳过登录
    wx.setStorageSync('skipAuth', true)
    wx.showToast({ title: '已跳过登录', icon: 'success' })
    
    setTimeout(() => {
      wx.redirectTo({
        url: '/pages/index/index'
      })
    }, 500)
  }
})

// 学习思考题：
// 1. 为什么个人版小程序要用open-type="chooseAvatar"而不是wx.getUserProfile？
// 2. 头像为什么要上传到云存储？不上传会怎样？
// 3. 为什么要提供"跳过登录"功能？这对用户体验有什么影响？
