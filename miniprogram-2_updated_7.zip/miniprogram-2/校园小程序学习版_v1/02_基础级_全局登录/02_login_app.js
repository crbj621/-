// ============================================================
// 【学习目标】理解全局登录状态管理 —— "总管家的登录技能"
// 【核心知识点】globalData全局变量、wx.setStorageSync缓存、云函数获取openid
// 【个人版限制】个人版无法使用微信登录接口，需用云函数获取openid
// ============================================================

// 【是什么】App({...}) —— 创建小程序的"总管家"
// 【为什么】登录状态需要全局共享，所有页面都要知道"用户登录了吗"
//          App就是管理全局事务的总管家
App({
  
  // ============================================================
  // 【是什么】globalData —— "公共储物柜"
  // 【为什么】登录状态、用户信息需要所有页面共享
  //          放在globalData里，任何页面都能取用
  // 【与缓存的区别】
  //          globalData = 内存里的储物柜，读写快，但重启后清空
  //          缓存 = 硬盘里的储物柜，读写慢，但永久保存
  // 【新手坑】❌ 把临时数据放缓存，浪费存储空间
  //          ❌ 把重要数据只放globalData，重启后丢失
  //          ✓ 重要数据同时放globalData和缓存
  // ============================================================
  globalData: {
    
    // 【是什么】userInfo —— "用户信息包"
    // 【为什么】存储用户的头像、昵称等信息
    // 【null是什么】null = 空的 = 什么都没有
    //          用户还没登录时，userInfo就是null
    // 【新手坑】❌ 访问null.nickName会报错
    //          ✓ 使用前先判断 if(userInfo)
    userInfo: null,
    
    // 【是什么】openid —— "用户身份证号"
    // 【为什么】微信给每个用户分配的唯一标识
    //          有了openid，我们就能识别"这是哪个用户"
    // 【为什么初始值是空字符串】空字符串''和null不同：
    //          null = 什么都没有
    //          '' = 有东西，但内容是空的
    // 【新手坑】❌ 判断openid时写成 if(openid) 会出错（null和''都算false）
    //          ✓ 判断写成 if(openid !== '') 更准确
    openid: '',
    
    // 【是什么】hasUserInfo —— "用户登录了吗"的标记
    // 【为什么】布尔值（true/false）就像开关，只有两个状态
    //          true = 已登录，false = 未登录
    //          比判断userInfo是否为null更直观
    // 【新手坑】❌ 用数字0和1表示，代码可读性差
    //          ✓ 用布尔值，一看就懂
    hasUserInfo: false
  },

  // ============================================================
  // 【是什么】onLaunch —— 小程序"开业典礼"
  // 【为什么】小程序启动时，就像公司开业，需要做一些初始化工作
  //          onLaunch就是"开业典礼"的流程清单
  // 【什么时候执行】小程序第一次启动时执行，整个生命周期只执行一次
  // 【新手坑】❌ 在onLaunch里做耗时操作，会导致小程序启动很慢
  //          ✓ 只做必要的初始化，其他事情延后处理
  // ============================================================
  onLaunch() {
    
    // 【是什么】wx.cloud.init() —— 初始化"云服务"
    // 【为什么】个人版小程序没有自己的服务器
    //          微信提供了"云开发"服务，可以存储数据、运行代码
    //          使用云服务前，必须先初始化
    // 【env是什么】env = environment = 环境
    //          云开发有多个环境（开发环境、生产环境）
    //          需要指定使用哪个环境
    // 【traceUser是什么】trace = 追踪，自动记录用户访问信息
    wx.cloud.init({
      env: 'your-env-id',  // 【重要】替换为你的云开发环境ID
      traceUser: true
    })

    // 调用登录状态初始化
    this.initLoginState()
  },

  // ============================================================
  // 【是什么】initLoginState —— 初始化登录状态
  // 【为什么】用户可能之前登录过，我们需要检查并恢复登录状态
  //          就像检查"仓库"里有没有之前的登录记录
  // ============================================================
  initLoginState() {
    
    // 【是什么】wx.getStorageSync —— 从"本地仓库"取东西
    // 【为什么】用户上次登录的信息，我们存在了手机的"本地仓库"里
    //          wx.getStorageSync就是去仓库取东西
    //          'userInfo'是储物柜的"编号/名字"
    // 【Sync是什么意思】Sync = 同步 = 等取到东西再往下执行
    //          就像去快递柜取快递，取到快递才走
    // 【与Async区别】Async = 异步 = 先去取，不等结果，回头再来拿
    // 【新手坑】❌ 写成wx.getStorage（没有Sync），返回的是Promise对象
    //          ✓ 初学者建议用Sync版本，代码更直观
    const cachedUserInfo = wx.getStorageSync('userInfo')
    const cachedOpenid = wx.getStorageSync('openid')
    
    // 【是什么】if判断 —— "如果...就..."
    // 【为什么】用户可能是"老用户"（之前登录过）
    //          老用户的信息存在仓库里，我们需要取出来恢复登录状态
    // 【如果不判断会怎样】直接取可能取到null，后面使用会报错
    if (cachedOpenid) {
      // 【是什么】this.globalData.xxx —— 访问"公共储物柜"
      // 【为什么】把仓库里的东西放到公共储物柜，方便其他页面取用
      this.globalData.openid = cachedOpenid
    }
    
    if (cachedUserInfo) {
      this.globalData.userInfo = cachedUserInfo
      this.globalData.hasUserInfo = true
      console.log('从仓库恢复登录状态成功！')
    }
    
    // 【是什么】if(!xxx) —— "如果没有..."
    // 【为什么】!是"非/不是"的意思
    //          !cachedOpenid = 缓存里没有openid
    //          新用户第一次来，需要获取openid
    if (!cachedOpenid) {
      this.getOpenId()
    }
  },

  // ============================================================
  // 【是什么】getOpenId —— 获取用户身份证号
  // 【为什么】个人版小程序不能用wx.login获取用户信息
  //          只能通过云函数获取openid
  // 【async是什么】async = 异步 = 这个函数里有"等待"操作
  //          云函数调用需要时间，用async标记这个函数会"等待"
  // ============================================================
  async getOpenId() {
    try {
      // 【是什么】wx.cloud.callFunction —— 调用"云函数"
      // 【为什么】云函数是运行在微信服务器上的代码
      //          可以做一些小程序端做不了的事情（如获取openid）
      // 【name是什么】云函数的名字，需要在云开发控制台创建
      const res = await wx.cloud.callFunction({
        name: 'login'  // 云函数名称
      })
      
      // 【是什么】await —— "等待"
      // 【为什么】云函数调用需要时间，await让代码"暂停"等待结果
      //          没有await，res还是Promise对象，不是结果
      // 【新手坑】❌ 忘了await，res.result是undefined
      //          ✓ async函数里用await等待异步操作
      
      // 【是什么】res.result —— 云函数返回的结果
      // 【为什么】云函数返回的数据在result里
      if (res.result && res.result.openid) {
        this.globalData.openid = res.result.openid
        
        // 【是什么】wx.setStorageSync —— 往"本地仓库"存东西
        // 【为什么】openid要保存到仓库，下次启动不用重新获取
        // 【参数】('储物柜名字', 要存的东西)
        wx.setStorageSync('openid', res.result.openid)
        console.log('openid获取成功:', res.result.openid)
      }
    } catch (err) {
      // 【是什么】try...catch —— "尝试...捕获错误"
      // 【为什么】云函数可能失败（网络问题、云函数不存在等）
      //          catch可以捕获错误，防止程序崩溃
      // 【新手坑】❌ 不写catch，出错后程序直接崩溃
      //          ✓ 网络请求、云函数调用都要用try...catch
      console.error('获取openid失败:', err)
    }
  },

  // ============================================================
  // 【是什么】getOpenIdSync —— 同步获取openid
  // 【为什么】其他页面可能需要"立刻"拿到openid，不能等
  //          这个方法先检查内存，再检查缓存，立刻返回结果
  // ============================================================
  getOpenIdSync() {
    // 先检查内存（最快）
    if (this.globalData.openid) {
      return this.globalData.openid
    }
    // 再检查缓存（备用）
    return wx.getStorageSync('openid') || ''
    // 【是什么】|| —— "或者"
    // 【为什么】如果缓存也没有，返回空字符串''
    //          避免 返回null或undefined导致后续判断出错
  },

  // ============================================================
  // 【是什么】getUserInfo —— 获取用户信息
  // 【为什么】统一获取用户信息的入口
  //          其他页面调用这个方法就能拿到用户信息
  // ============================================================
  getUserInfo() {
    // 先检查内存
    if (this.globalData.userInfo) {
      return this.globalData.userInfo
    }
    // 再检查缓存
    return wx.getStorageSync('userInfo') || null
  },

  // ============================================================
  // 【是什么】isLoggedIn —— 检查登录状态
  // 【为什么】很多页面需要知道"用户登录了吗"
  //          统一封装这个方法，方便调用
  // ============================================================
  isLoggedIn() {
    // 【是什么】&& —— "并且"
    // 【为什么】需要同时满足多个条件：
    //          1. hasUserInfo是true
    //          2. userInfo存在
    //          3. userInfo.nickName存在
    // 【为什么检查nickName】只有有昵称才算真正完成登录
    if (this.globalData.hasUserInfo && 
        this.globalData.userInfo && 
        this.globalData.userInfo.nickName) {
      return true
    }
    
    // 【是什么】双重检查 —— 内存没有再查缓存
    // 【为什么】防止globalData丢失（小程序重启）
    var cachedUserInfo = wx.getStorageSync('userInfo')
    var cachedOpenid = wx.getStorageSync('openid')
    
    // 【是什么】!! —— "转成布尔值"
    // 【为什么】需要返回true/false，而不是具体值
    //          !!cachedOpenid = 把cachedOpenid转成true/false
    return !!(cachedOpenid && cachedUserInfo && cachedUserInfo.nickName)
  },

  // ============================================================
  // 【是什么】doLogin —— 执行登录
  // 【为什么】登录页收集完用户信息后，调用这个方法完成登录
  // 【参数】userInfo = 用户填写的信息（昵称、头像）
  // ============================================================
  async doLogin(userInfo) {
    // 【是什么】参数校验
    // 【为什么】用户可能没填昵称就点登录
    //          需要检查参数是否合法
    if (!userInfo || !userInfo.nickName) {
      return { success: false, message: '请输入昵称' }
    }

    // 获取openid
    var openid = this.getOpenIdSync()
    
    // 【为什么可能没有openid】首次登录时云函数可能还没返回
    if (!openid) {
      try {
        await this.getOpenId()
        openid = this.getOpenIdSync()
      } catch (err) {
        console.error('获取openid失败:', err)
        return { success: false, message: '获取openid失败' }
      }
    }

    if (!openid) {
      return { success: false, message: '登录失败，请重试' }
    }

    // 更新全局状态
    this.globalData.userInfo = userInfo
    this.globalData.openid = openid
    this.globalData.hasUserInfo = true

    // 保存到缓存（实现"记住登录"）
    wx.setStorageSync('userInfo', userInfo)
    wx.setStorageSync('openid', openid)

    // 返回成功结果
    return { success: true, openid: openid }
  },

  // ============================================================
  // 【是什么】doLogout —— 退出登录
  // 【为什么】用户可能需要切换账号或清除登录状态
  // ============================================================
  doLogout() {
    // 清除全局状态
    this.globalData.userInfo = null
    this.globalData.openid = ''
    this.globalData.hasUserInfo = false

    // 【是什么】wx.removeStorageSync —— 清除指定缓存
    // 【为什么】退出登录需要清除所有登录相关缓存
    wx.removeStorageSync('userInfo')
    wx.removeStorageSync('openid')
  },

  // ============================================================
  // 【是什么】checkLogin —— 检查登录并跳转
  // 【为什么】很多页面需要登录才能访问
  //          统一封装"未登录跳转登录页"的逻辑
  // ============================================================
  checkLogin(options) {
    // 【是什么】options —— 可选参数
    // 【为什么】有些场景需要强制跳转，有些不需要
    var redirect = options && options.redirect !== false
    
    if (!this.isLoggedIn()) {
      if (redirect) {
        // 未登录跳转到登录页
        wx.reLaunch({ url: '/pages/login/login' })
      }
      return false  // 返回false表示未登录
    }
    return true  // 返回true表示已登录
  }
})

// ============================================================
// 【如果删掉if判断会怎样？】
// 比如删掉 isLoggedIn() 里的判断：
// 
// isLoggedIn() {
//   return true  // 直接返回true
// }
// 
// 结果：
// 1. 所有页面都认为用户已登录
// 2. 但userInfo是null，显示昵称时报错
// 3. 报错：Cannot read property 'nickName' of null
// 4. 用户看到空白页或报错页面
// ============================================================

// ============================================================
// 【新手优化建议】
// 
// 1. 添加错误处理
//    所有网络请求、云函数调用都要用try...catch
// 
// 2. 添加日志
//    关键步骤打印日志，方便调试
// 
// 3. 添加类型检查
//    if (typeof userInfo.nickName === 'string')
//    确保数据类型正确
// 
// 4. 添加超时处理
//    云函数调用可能卡住，添加超时机制
// ============================================================

// ============================================================
// 【学习思考题】
// 1. 为什么个人版小程序要用云函数获取openid，而不是用wx.login？
//    提示：wx.login需要服务端解密，个人版没有服务端
// 
// 2. globalData和缓存有什么区别？为什么两者都要用？
//    提示：从"速度"和"持久性"两方面思考
// 
// 3. 登录状态为什么要同时检查globalData和缓存？
//    提示：小程序重启后会发生什么？
// ============================================================
