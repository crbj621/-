// 学习目标：理解云函数获取openid | 核心知识点：云函数入口、wxContext获取用户信息 | 个人版限制：个人版必须用云函数获取openid，无法使用服务端解密

// 知识点：引入云开发SDK
// 为什么需要：云函数中操作云开发资源需要这个SDK
const cloud = require('wx-server-sdk')

// 知识点：cloud.init 初始化云开发
// 为什么用DYNAMIC_CURRENT_ENV：自动使用当前云函数所在环境，无需手动指定
cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

// 知识点：云函数入口函数
// 为什么是这个格式：云函数的标准写法，exports.main导出主函数
// 参数说明：
// - event：调用云函数时传入的参数
// - context：运行上下文
exports.main = async (event, context) => {
  // 知识点：cloud.getWXContext() 获取微信上下文
  // 为什么用这个方法：可以获取用户的openid、appid、unionid等信息
  // 个人版适配：这是个人版获取openid的唯一方式
  // 为什么安全：openid在云端获取，无法伪造
  const wxContext = cloud.getWXContext()
  
  // 知识点：wxContext 包含的信息
  // OPENID：用户在该小程序下的唯一标识
  // APPID：小程序的AppID
  // UNIONID：用户在同一开放平台下的唯一标识（需要绑定开放平台）
  const openid = wxContext.OPENID
  const appid = wxContext.APPID
  const unionid = wxContext.UNIONID

  // 为什么打印日志：便于调试，在云开发控制台可以看到
  console.log('login 云函数被调用')
  console.log('OPENID:', openid)
  console.log('APPID:', appid)

  // 知识点：返回结果
  // 为什么返回这些信息：小程序端需要openid来标识用户
  // 返回格式：建议用对象，便于扩展
  return {
    openid: openid,      // 用户唯一标识，最常用
    appid: appid,        // 小程序AppID
    unionid: unionid     // 开放平台统一标识
  }
}

// ==================== 知识扩展 ====================

// 知识点：openid vs unionid
// openid：用户在该小程序下的唯一标识，不同小程序的openid不同
// unionid：用户在同一微信开放平台下的唯一标识，可用于多小程序/公众号打通
// 个人版注意：个人主体无法注册开放平台，所以个人版小程序通常只用openid

// 知识点：为什么个人版要用云函数获取openid
// 企业版流程：wx.login获取code -> 发送给服务端 -> 服务端调用微信API解密获取openid
// 个人版限制：没有服务端，无法完成上述流程
// 云函数方案：云函数中直接调用getWXContext()获取openid，无需服务端

// 知识点：云函数调用方式（小程序端）
// wx.cloud.callFunction({
//   name: 'login',  // 云函数名称
//   data: {},       // 传入参数
//   success: res => {
//     console.log(res.result.openid)
//   }
// })

// 学习思考题：
// 1. 为什么openid在云函数中获取比在小程序端获取更安全？
// 2. openid和unionid有什么区别？什么场景需要用unionid？
// 3. 个人版小程序为什么不能使用wx.login+服务端解密的方式获取openid？
