// 学习目标：理解微信定位API使用 | 核心知识点：wx.getLocation获取位置、wx.startLocationUpdate持续定位、距离计算公式 | 个人版限制：需在app.json中配置permission

Page({
  data: {
    // 定位相关数据
    latitude: 0,           // 当前纬度
    longitude: 0,          // 当前经度
    accuracy: 0,           // 定位精度（米）
    speed: 0,              // 速度（米/秒）
    altitude: 0,           // 海拔（米）
    
    // 跑步数据
    totalMeter: 0,         // 总距离（米）
    isRunning: false,      // 是否正在跑步
    isPaused: false,       // 是否暂停
    
    // 轨迹数据
    path: [],              // 跑步轨迹点数组
    polyline: [],          // 地图绑定的折线数据
    
    // 上一个有效位置
    lastLat: null,
    lastLng: null
  },

  // 定位监听是否激活
  locationListenerActive: false,

  onLoad() {
    // 初始化位置
    this.getCurrentLocation()
  },

  // ==================== 定位API ====================

  // 知识点：wx.getLocation 获取当前位置
  // 为什么需要：获取用户当前位置，显示在地图上
  // 个人版适配：个人版可以使用定位功能，但需要在app.json中配置权限说明
  getCurrentLocation() {
    wx.showLoading({ title: '定位中...', mask: true })
    
    // 知识点：wx.getLocation 参数说明
    // type：坐标类型，gcj02是国测局坐标（适合国内地图）
    // isHighAccuracy：是否开启高精度定位
    // highAccuracyExpireTime：高精度定位超时时间
    wx.getLocation({
      type: 'gcj02',              // 为什么用gcj02：国内地图使用国测局坐标，wgs84会有偏移
      isHighAccuracy: true,       // 为什么开启高精度：跑步需要精确位置
      highAccuracyExpireTime: 5000,
      altitude: true,             // 为什么需要海拔：可以计算爬升高度
      success: (res) => {
        wx.hideLoading()
        
        // 知识点：返回的位置信息
        // latitude：纬度，-90到90
        // longitude：经度，-180到180
        // accuracy：精度，单位米，越小越精确
        // speed：速度，单位米/秒
        // altitude：海拔，单位米
        this.setData({
          latitude: res.latitude,
          longitude: res.longitude,
          altitude: res.altitude || 0,
          speed: res.speed || 0,
          accuracy: res.accuracy || 0
        })
        
        console.log('定位成功:', res.latitude, res.longitude, '精度:', res.accuracy)
      },
      fail: (err) => {
        wx.hideLoading()
        console.error('定位失败:', err)
        
        // 知识点：定位失败处理
        // 常见原因：用户拒绝授权、手机定位关闭、网络问题
        wx.showModal({
          title: '定位失败',
          content: '无法获取您的位置，请检查定位权限设置',
          confirmText: '去设置',
          success: (modalRes) => {
            if (modalRes.confirm) {
              // 知识点：wx.openSetting 打开设置页
              // 为什么需要：用户拒绝授权后，只能去设置页手动开启
              wx.openSetting()
            }
          }
        })
      }
    })
  },

  // 知识点：wx.startLocationUpdate 持续定位
  // 为什么需要：跑步需要实时追踪位置变化
  // 与getLocation区别：getLocation只获取一次，startLocationUpdate持续监听
  // 个人版适配：需要用户授权，建议在跑步开始时申请
  startLocation() {
    // 知识点：wx.startLocationUpdateBackground 后台定位
    // 为什么用Background版本：用户锁屏后也能继续定位
    // 个人版注意：后台定位需要在app.json配置requiredBackgroundModes
    wx.startLocationUpdateBackground({
      success: () => {
        this.locationListenerActive = true
        console.log('后台定位开启成功')
        this.setupLocationListener()
      },
      fail: () => {
        // 如果后台定位失败，尝试前台定位
        wx.startLocationUpdate({
          success: () => {
            this.locationListenerActive = true
            console.log('前台定位开启成功')
            this.setupLocationListener()
          },
          fail: (err) => {
            console.error('定位开启失败:', err)
            wx.showToast({ title: '定位开启失败', icon: 'none' })
          }
        })
      }
    })
  },

  // 知识点：wx.onLocationChange 位置变化监听
  // 为什么需要：实时获取位置变化，计算跑步距离
  setupLocationListener() {
    // 知识点：wx.onLocationChange 注册位置变化回调
    // 触发时机：位置发生变化时（具体频率由系统决定）
    wx.onLocationChange((res) => {
      if (!this.data.isRunning || this.data.isPaused) return

      const now = Date.now()
      const accuracy = res.accuracy

      // 知识点：精度过滤
      // 为什么需要：GPS信号不稳定时会返回精度很差的位置
      // 过滤策略：精度大于65米的位置可能是漂移，忽略
      if (accuracy > 65) {
        console.log('精度太差，忽略:', accuracy)
        return
      }

      // 知识点：位置有效性检查
      // 为什么需要：有时会返回无效坐标
      if (!res.latitude || !res.longitude) return

      const currentLocation = {
        latitude: res.latitude,
        longitude: res.longitude,
        accuracy: accuracy,
        speed: res.speed || 0,
        timestamp: now
      }

      // 计算距离
      if (this.data.lastLat && this.data.lastLng) {
        // 知识点：计算两点间距离
        const dis = this.calcDistance(
          this.data.lastLat,
          this.data.lastLng,
          currentLocation.latitude,
          currentLocation.longitude
        )

        // 知识点：异常跳跃过滤
        // 为什么需要：GPS漂移会导致位置突然跳跃
        // 过滤策略：两点距离超过50米可能是漂移
        if (dis > 50) {
          console.log('异常跳跃，忽略:', dis)
          return
        }

        // 累加距离
        this.setData({
          totalMeter: Math.round((this.data.totalMeter + dis) * 100) / 100
        })
      }

      // 更新当前位置
      this.setData({
        lastLat: currentLocation.latitude,
        lastLng: currentLocation.longitude,
        latitude: currentLocation.latitude,
        longitude: currentLocation.longitude
      })

      // 更新轨迹
      this.updatePath(currentLocation)
    })
  },

  // ==================== 距离计算 ====================

  // 知识点：Haversine公式计算两点间距离
  // 为什么用这个公式：考虑了地球曲率，比简单的勾股定理更准确
  // 原理：将经纬度转换为球面坐标，计算球面距离
  calcDistance(lat1, lng1, lat2, lng2) {
    // 地球半径（米）
    const R = 6378137
    
    // 知识点：角度转弧度
    // 为什么需要：三角函数需要弧度参数
    const radLat1 = lat1 * Math.PI / 180
    const radLat2 = lat2 * Math.PI / 180
    const a = radLat1 - radLat2
    const b = (lng1 - lng2) * Math.PI / 180
    
    // 知识点：Haversine公式
    // 公式推导：球面三角学
    // 适用范围：适合短距离计算（几公里内误差很小）
    const s = 2 * R * Math.asin(
      Math.sqrt(
        Math.pow(Math.sin(a / 2), 2) + 
        Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(Math.sin(b / 2), 2)
      )
    )
    
    return s
  },

  // 更新跑步轨迹
  updatePath(location) {
    const newPath = [...this.data.path, {
      latitude: location.latitude,
      longitude: location.longitude,
      timestamp: location.timestamp
    }]
    
    // 知识点：polyline 地图折线
    // 为什么需要：在地图上显示跑步轨迹
    // points：折线点数组
    // color：线条颜色
    // width：线条宽度
    this.setData({
      path: newPath,
      polyline: [{
        points: newPath,
        color: '#0088ff',
        width: 5
      }]
    })
  },

  // ==================== 跑步控制 ====================

  // 开始跑步
  startRun() {
    this.setData({
      isRunning: true,
      isPaused: false,
      totalMeter: 0,
      path: [],
      lastLat: null,
      lastLng: null
    })
    
    this.startLocation()
    console.log('开始跑步')
  },

  // 暂停/继续
  pauseRun() {
    if (this.data.isPaused) {
      this.setData({ isPaused: false })
      this.startLocation()
    } else {
      this.setData({ isPaused: true })
      this.stopLocation()
    }
  },

  // 停止跑步
  stopRun() {
    this.setData({ isRunning: false, isPaused: false })
    this.stopLocation()
    
    wx.showModal({
      title: '运动完成',
      content: `距离：${this.data.totalMeter} 米`,
      showCancel: false
    })
  },

  // 停止定位
  stopLocation() {
    if (this.locationListenerActive) {
      // 知识点：wx.stopLocationUpdate 停止定位
      // 为什么需要：停止跑步后不再需要定位，节省电量
      wx.stopLocationUpdate()
      this.locationListenerActive = false
    }
  }
})

// 学习思考题：
// 1. 为什么定位坐标要用gcj02而不是wgs84？
// 2. Haversine公式和简单的勾股定理计算距离有什么区别？
// 3. 为什么要过滤精度大于65米的位置数据？
