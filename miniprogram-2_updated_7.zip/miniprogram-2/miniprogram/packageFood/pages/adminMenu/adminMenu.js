Page({
  data: {
    menus: [],
    categories: [],
    loading: false,
    showAddModal: false,
    editingId: null,
    selectedCategoryName: '',
    formData: {
      name: '',
      price: '',
      originalPrice: '',
      categoryId: '',
      description: '',
      stock: '999',
      status: true
    }
  },

  onLoad() {
    this.loadCategories()
    this.loadMenus()
  },

  async loadCategories() {
    try {
      var res = await wx.cloud.callFunction({
        name: 'globalAdmin',
        data: { action: 'getFoodCategories' }
      })
      if (res.result && res.result.code === 0) {
        this.setData({ categories: res.result.data })
      }
    } catch (err) {
      console.error('加载分类失败:', err)
    }
  },

  async loadMenus() {
    this.setData({ loading: true })
    try {
      var res = await wx.cloud.callFunction({
        name: 'globalAdmin',
        data: {
          action: 'getFoodMenus',
          data: { pageSize: 100 }
        }
      })

      if (res.result && res.result.code === 0) {
        this.setData({ menus: res.result.data.list })
      }
    } catch (err) {
      console.error('加载菜品失败:', err)
    }
    this.setData({ loading: false })
  },

  showAddModal() {
    this.setData({
      showAddModal: true,
      editingId: null,
      selectedCategoryName: '',
      formData: {
        name: '',
        price: '',
        originalPrice: '',
        categoryId: '',
        description: '',
        stock: '999',
        status: true
      }
    })
  },

  hideModal() {
    this.setData({ showAddModal: false })
  },

  onInputChange(e) {
    var field = e.currentTarget.dataset.field
    var value = e.detail.value
    this.setData({ ['formData.' + field]: value })
  },

  onSwitchChange(e) {
    this.setData({ ['formData.status']: e.detail.value })
  },

  onCategoryChange(e) {
    var index = e.detail.value
    var category = this.data.categories[index]
    this.setData({ 
      ['formData.categoryId']: category._id,
      selectedCategoryName: category.name
    })
  },

  async submitForm() {
    var formData = this.data.formData
    if (!formData.name || !formData.price) {
      wx.showToast({ title: '请填写菜品名称和价格', icon: 'none' })
      return
    }

    try {
      var action = this.data.editingId ? 'updateFoodMenu' : 'createFoodMenu'
      var data = {
        name: formData.name,
        price: Number(formData.price),
        originalPrice: formData.originalPrice ? Number(formData.originalPrice) : null,
        categoryId: formData.categoryId,
        description: formData.description,
        stock: Number(formData.stock),
        status: formData.status
      }
      if (this.data.editingId) {
        data.id = this.data.editingId
      }

      var res = await wx.cloud.callFunction({
        name: 'globalAdmin',
        data: { action: action, data: data }
      })

      if (res.result && res.result.code === 0) {
        wx.showToast({ title: this.data.editingId ? '更新成功' : '添加成功', icon: 'success' })
        this.hideModal()
        this.loadMenus()
      }
    } catch (err) {
      wx.showToast({ title: '操作失败', icon: 'none' })
    }
  },

  editMenu(e) {
    var item = e.currentTarget.dataset.item
    var categoryName = ''
    if (item.categoryId) {
      var category = this.data.categories.find(function(c) { return c._id === item.categoryId })
      if (category) categoryName = category.name
    }
    this.setData({
      showAddModal: true,
      editingId: item._id,
      selectedCategoryName: categoryName,
      formData: {
        name: item.name,
        price: String(item.price),
        originalPrice: item.originalPrice ? String(item.originalPrice) : '',
        categoryId: item.categoryId || '',
        description: item.description || '',
        stock: String(item.stock || 999),
        status: item.status !== false
      }
    })
  },

  async deleteMenu(e) {
    var id = e.currentTarget.dataset.id
    var that = this
    wx.showModal({
      title: '删除菜品',
      content: '确定要删除这个菜品吗？',
      success: function(res) {
        if (res.confirm) {
          that.doDeleteMenu(id)
        }
      }
    })
  },

  async doDeleteMenu(id) {
    try {
      var result = await wx.cloud.callFunction({
        name: 'globalAdmin',
        data: { action: 'deleteFoodMenu', data: { id: id } }
      })
      if (result.result && result.result.code === 0) {
        wx.showToast({ title: '已删除', icon: 'success' })
        this.loadMenus()
      }
    } catch (err) {
      wx.showToast({ title: '删除失败', icon: 'none' })
    }
  }
})
