import { callFoodFunction } from '../../utils/food-cloud'

Page({
  data: {
    shops: [] as any[],
    loading: true,
    keyword: '',
    page: 1,
    pageSize: 10,
    hasMore: true,
    refreshing: false,
    isLoggedIn: false
  },

  onLoad() {
    this.checkLogin()
  },

  onShow() {
    this.checkLogin()
  },

  checkLogin() {
    const app = getApp()
    const openid = app.getGlobalOpenId()
    const skipLogin = wx.getStorageSync('food_skip_login')
    
    if (!openid && !skipLogin) {
      wx.redirectTo({
        url: '/packageFood/pages/login/login'
      })
      return
    }
    
    this.setData({ isLoggedIn: !!(openid || skipLogin) })
    this.loadShops()
  },

  onPullDownRefresh() {
    this.onRefresh()
  },

  onRefresh() {
    this.setData({ refreshing: true, page: 1, hasMore: true })
    this.loadShops().then(() => {
      this.setData({ refreshing: false })
      wx.stopPullDownRefresh()
    })
  },

  loadMore() {
    if (this.data.loading || !this.data.hasMore) return
    this.setData({ page: this.data.page + 1 })
    this.loadShops(true)
  },

  loadShops(isLoadMore = false) {
    if (!isLoadMore) {
      this.setData({ loading: true, page: 1 })
    }
    
    return callFoodFunction('getShopList', { 
      keyword: this.data.keyword,
      page: this.data.page,
      pageSize: this.data.pageSize
    }).then((result: any) => {
      const newList = result.list || []
      const shops = isLoadMore ? [...this.data.shops, ...newList] : newList
      
      this.setData({
        shops,
        loading: false,
        hasMore: newList.length >= this.data.pageSize
      })
    }).catch(err => {
      wx.showToast({ title: err.message || '加载失败', icon: 'none' })
      this.setData({ loading: false })
    })
  },

  onSearchInput(e: any) {
    this.setData({ keyword: e.detail.value })
  },

  onSearch(e: any) {
    this.setData({ keyword: e.detail.value, page: 1, hasMore: true })
    this.loadShops()
  },

  goToShop(e: any) {
    const shopId = e.currentTarget.dataset.id
    wx.navigateTo({
      url: '/packageFood/pages/shop/shop?id=' + shopId
    })
  },

  goToMine() {
    wx.navigateTo({
      url: '/pages/profile/profile?source=food'
    })
  },

  goToOrders() {
    wx.navigateTo({
      url: '/packageFood/pages/order_list/order_list'
    })
  },

  goToRider() {
    // 骑手入口放在点餐右上角（不在主页展示）
    wx.cloud.callFunction({
      name: 'rider',
      data: { action: 'getProfile' },
      success: (res: any) => {
        if (res.result && res.result.code === 0 && res.result.data && res.result.data.registered) {
          wx.setStorageSync('riderInfo', res.result.data.rider)
          wx.navigateTo({ url: '/packageRider/pages/hall/hall' })
        } else {
          wx.navigateTo({ url: '/packageRider/pages/register/register' })
        }
      },
      fail: (err) => {
        console.error('获取骑手信息失败:', err)
        wx.showToast({ title: '骑手功能暂不可用', icon: 'none' })
      }
    })
  }
})
