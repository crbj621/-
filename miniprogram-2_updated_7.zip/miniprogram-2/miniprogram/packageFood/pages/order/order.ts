import { callFoodFunction } from '../../utils/food-cloud'

Page({
  data: {
    shop: null as any,
    items: [] as any[],
    totalPrice: 0,
    type: 'pickup' as 'pickup' | 'delivery',
    phone: '',
    address: '',
    pickupTime: '',
    remark: '',
    submitting: false,
    isLoggedIn: false,
    userInfo: null as any
  },

  onLoad() {
    this.checkLogin()
    const orderData = wx.getStorageSync('current_order')
    if (!orderData) {
      wx.showToast({ title: '订单数据异常', icon: 'none' })
      setTimeout(() => wx.navigateBack(), 1000)
      return
    }
    this.setData({
      shop: orderData.shop,
      items: orderData.items,
      totalPrice: orderData.totalPrice
    })
  },

  checkLogin() {
    const app = getApp()
    const openid = app.getGlobalOpenId()
    const userInfo = wx.getStorageSync('userInfo')
    this.setData({
      isLoggedIn: !!openid,
      userInfo: userInfo
    })
  },

  goToLogin() {
    wx.reLaunch({
      url: '/pages/login/login'
    })
  },

  onTypeChange(e: any) {
    this.setData({ type: e.detail.value })
  },

  onPhoneInput(e: any) {
    this.setData({ phone: e.detail.value })
  },

  onAddressInput(e: any) {
    this.setData({ address: e.detail.value })
  },

  onPickupTimeChange(e: any) {
    this.setData({ pickupTime: e.detail.value })
  },

  onRemarkInput(e: any) {
    this.setData({ remark: e.detail.value })
  },

  async submitOrder() {
    const { shop, items, totalPrice, type, phone, address, pickupTime, remark, submitting, isLoggedIn, userInfo } = this.data
    
    if (submitting) return

    if (!isLoggedIn) {
      wx.showModal({
        title: '请先登录',
        content: '提交订单需要登录，是否立即登录？',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            this.goToLogin()
          }
        }
      })
      return
    }

    if (!phone) {
      wx.showToast({ title: '请输入联系电话', icon: 'none' })
      return
    }
    if (type === 'delivery' && !address) {
      wx.showToast({ title: '请输入配送地址', icon: 'none' })
      return
    }
    if (type === 'pickup' && !pickupTime) {
      wx.showToast({ title: '请选择取餐时间', icon: 'none' })
      return
    }

    this.setData({ submitting: true })

    try {
      const res = await callFoodFunction('createOrder', {
        shopId: shop._id,
        items,
        totalPrice,
        type,
        phone,
        address,
        pickupTime,
        remark,
        userNickName: userInfo && userInfo.nickName ? userInfo.nickName : '',
        userAvatarUrl: userInfo && userInfo.avatarUrl ? userInfo.avatarUrl : ''
      }, { showLoading: true, loadingTitle: '提交中' })

      wx.removeStorageSync('current_order')
      
      wx.showModal({
        title: '下单成功',
        content: type === 'pickup' ? `取餐码: ${res.pickupCode}` : '请等待商家配送',
        showCancel: false,
        success: () => {
          wx.redirectTo({
            url: '/packageFood/pages/order_list/order_list'
          })
        }
      })
    } catch (err: any) {
      wx.showToast({ title: err.message || '下单失败', icon: 'none' })
    } finally {
      this.setData({ submitting: false })
    }
  }
})
