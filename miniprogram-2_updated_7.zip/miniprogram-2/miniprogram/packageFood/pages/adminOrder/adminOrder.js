Page({
  data: {
    orders: [],
    loading: false,
    status: '',
    page: 1,
    hasMore: true
  },

  onLoad() {
    this.loadOrders()
  },

  onPullDownRefresh() {
    this.setData({ page: 1, hasMore: true, orders: [] })
    this.loadOrders().then(() => wx.stopPullDownRefresh())
  },

  onReachBottom() {
    this.loadOrders()
  },

  async loadOrders() {
    if (this.data.loading || !this.data.hasMore) return

    this.setData({ loading: true })
    try {
      var res = await wx.cloud.callFunction({
        name: 'globalAdmin',
        data: {
          action: 'getFoodOrders',
          data: {
            page: this.data.page,
            pageSize: 20,
            status: this.data.status
          }
        }
      })

      if (res.result && res.result.code === 0) {
        var newOrders = res.result.data.list
        this.setData({
          orders: this.data.page === 1 ? newOrders : this.data.orders.concat(newOrders),
          hasMore: newOrders.length >= 20,
          page: this.data.page + 1
        })
      }
    } catch (err) {
      console.error('加载订单失败:', err)
    }
    this.setData({ loading: false })
  },

  onStatusChange(e) {
    var status = e.detail.value
    this.setData({ 
      status: status === '0' ? '' : status,
      page: 1, 
      hasMore: true, 
      orders: [] 
    })
    this.loadOrders()
  },

  async updateOrderStatus(e) {
    var orderId = e.currentTarget.dataset.id
    var newStatus = e.currentTarget.dataset.status

    try {
      var res = await wx.cloud.callFunction({
        name: 'globalAdmin',
        data: {
          action: 'updateFoodOrder',
          data: { id: orderId, status: newStatus }
        }
      })

      if (res.result && res.result.code === 0) {
        wx.showToast({ title: '状态已更新', icon: 'success' })
        this.setData({ page: 1, hasMore: true, orders: [] })
        this.loadOrders()
      }
    } catch (err) {
      wx.showToast({ title: '操作失败', icon: 'none' })
    }
  },

  getStatusText(status) {
    var texts = {
      'pending': '待处理',
      'confirmed': '已确认',
      'preparing': '制作中',
      'ready': '待取餐',
      'completed': '已完成',
      'cancelled': '已取消'
    }
    return texts[status] || status
  },

  getStatusClass(status) {
    var classes = {
      'pending': 'warning',
      'confirmed': 'info',
      'preparing': 'info',
      'ready': 'success',
      'completed': 'success',
      'cancelled': 'danger'
    }
    return classes[status] || ''
  }
})
