App({
  globalData: {
    openid: ''
  },

  onLaunch() {
    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力')
      return
    }

    wx.cloud.init({
      env: 'cloudbase-8gy1i7h07bd9a58c',
      traceUser: true
    })

    const openid = wx.getStorageSync('global_openid')
    if (openid) {
      this.globalData.openid = openid
    }
  },

  getGlobalOpenId() {
    if (this.globalData.openid) {
      return this.globalData.openid
    }
    return wx.getStorageSync('global_openid') || ''
  }
})
