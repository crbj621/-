Component({
  properties: {
    selected: {
      type: Number,
      value: 0
    }
  },
  data: {
    color: "#7A7E83",
    selectedColor: "#0088ff"
  },
  methods: {
    switchTab(e: any) {
      const data = e.currentTarget.dataset
      const url = data.path
      wx.redirectTo({ url })
    }
  }
})