Page({
  data: {
    category: '',
    categoryName: '',
    orderBy: 'latest',
    keyword: '',
    showSearch: false,
    posts: [] as any[],
    page: 1,
    hasMore: true,
    loading: false
  },

  onLoad(options: any) {
    if (options.search === '1') {
      this.setData({ showSearch: true })
    }
    if (options.category) {
      this.setData({ category: options.category })
      const categoryNames: Record<string, string> = {
        'gossip': '灌水区',
        'confession': '表白墙',
        'melon': '吃瓜',
        'job': '兼职',
        'lost': '失物招领',
        'study': '学习互助'
      }
      this.setData({ categoryName: categoryNames[options.category] || '帖子列表' })
    }
    if (options.orderBy) {
      this.setData({ orderBy: options.orderBy })
    }
    this.loadPosts()
  },

  goBack() {
    wx.navigateBack({
      fail: () => {
        wx.switchTab({ url: '/pages/index/index' })
      }
    })
  },

  formatTime(date: any): string {
    if (!date) return ''
    const d = new Date(date)
    const now = new Date()
    const diff = now.getTime() - d.getTime()
    
    if (diff < 60000) return '刚刚'
    if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前'
    if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前'
    if (diff < 604800000) return Math.floor(diff / 86400000) + '天前'
    
    const month = d.getMonth() + 1
    const day = d.getDate()
    return `${month}月${day}日`
  },

  onPullDownRefresh() {
    this.setData({ page: 1, posts: [], hasMore: true })
    this.loadPosts().then(() => {
      wx.stopPullDownRefresh()
    })
  },

  async loadPosts() {
    if (this.data.loading || !this.data.hasMore) return

    this.setData({ loading: true })

    try {
      const data: any = {
        orderBy: this.data.orderBy,
        page: this.data.page,
        pageSize: 10
      }
      if (this.data.category) data.category = this.data.category

      const res = await wx.cloud.callFunction({
        name: 'forum',
        data: { action: 'getPosts', data }
      }) as any

      if (res.result.success) {
        const posts = res.result.posts.map((post: any) => {
          let authorName = '用户'
          let authorAvatar = ''
          if (post.isAnonymous) {
            authorName = '匿名用户'
          } else {
            if (post.authorName) {
              authorName = post.authorName
            } else if (post.authorInfo && post.authorInfo.nickname) {
              authorName = post.authorInfo.nickname
            }
            if (post.authorAvatar) {
              authorAvatar = post.authorAvatar
            } else if (post.authorInfo && post.authorInfo.avatar) {
              authorAvatar = post.authorInfo.avatar
            }
          }
          return {
            ...post,
            authorName,
            authorAvatar,
            createTimeText: this.formatTime(post.createTime)
          }
        })

        this.setData({
          posts: this.data.page === 1 ? posts : [...this.data.posts, ...posts],
          hasMore: res.result.hasMore,
          page: this.data.page + 1
        })
      }
    } catch (err) {
      console.error('加载帖子失败:', err)
      wx.showToast({ title: '加载失败', icon: 'none' })
    } finally {
      this.setData({ loading: false })
    }
  },

  loadMore() {
    this.loadPosts()
  },

  changeOrder(e: any) {
    const orderBy = e.currentTarget.dataset.order
    this.setData({ orderBy, page: 1, posts: [], hasMore: true })
    this.loadPosts()
  },

  toggleSearch() {
    this.setData({ showSearch: !this.data.showSearch })
  },

  onSearchInput(e: any) {
    this.setData({ keyword: e.detail.value })
  },

  async onSearch() {
    const { keyword } = this.data
    if (!keyword.trim()) {
      this.setData({ page: 1, posts: [], hasMore: true })
      this.loadPosts()
      return
    }

    this.setData({ loading: true, posts: [] })

    try {
      const res = await wx.cloud.callFunction({
        name: 'forum',
        data: { action: 'searchPosts', data: { keyword } }
      }) as any

      if (res.result.success) {
        const posts = res.result.posts.map((post: any) => {
          let authorName = '用户'
          let authorAvatar = ''
          if (post.isAnonymous) {
            authorName = '匿名用户'
          } else {
            if (post.authorName) {
              authorName = post.authorName
            } else if (post.authorInfo && post.authorInfo.nickname) {
              authorName = post.authorInfo.nickname
            }
            if (post.authorAvatar) {
              authorAvatar = post.authorAvatar
            } else if (post.authorInfo && post.authorInfo.avatar) {
              authorAvatar = post.authorInfo.avatar
            }
          }
          return {
            ...post,
            authorName,
            authorAvatar,
            createTimeText: this.formatTime(post.createTime)
          }
        })
        this.setData({
          posts,
          hasMore: false
        })
      }
    } catch (err) {
      console.error('搜索失败:', err)
      wx.showToast({ title: '搜索失败', icon: 'none' })
    } finally {
      this.setData({ loading: false })
    }
  },

  previewImage(e: any) {
    const url = e.currentTarget.dataset.url
    const urls = e.currentTarget.dataset.urls
    wx.previewImage({
      current: url,
      urls: urls
    })
  },

  goToDetail(e: any) {
    const id = e.currentTarget.dataset.id
    wx.navigateTo({
      url: `/packageForum/pages/detail/detail?id=${id}`
    })
  },

  goToPost() {
    wx.navigateTo({
      url: '/packageForum/pages/post/post'
    })
  }
})
