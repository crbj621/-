Page({
  data: {
    categories: [] as Array<{key: string, name: string}>,
    posts: [] as any[],
    currentCategory: '',
    activeTab: 'latest',
    page: 1,
    hasMore: true,
    loading: false,
    refreshing: false,
    unreadCount: 0,
    showAnnouncement: false,
    announcement: null as any
  },

  onLoad() {
    this.loadCategories()
    this.loadPosts()
    this.checkAnnouncement()
  },

  onShow() {
    this.loadUnreadCount()
  },

  async checkAnnouncement() {
    const lastAnnouncementId = wx.getStorageSync('lastReadAnnouncementId')
    
    try {
      const res = await wx.cloud.callFunction({
        name: 'forum',
        data: { action: 'getAnnouncement' }
      }) as any
      
      if (res.result && res.result.success && res.result.announcement) {
        const announcement = res.result.announcement
        if (announcement._id !== lastAnnouncementId) {
          this.setData({ 
            showAnnouncement: true, 
            announcement: announcement 
          })
        }
      }
    } catch (err) {
      console.error('检查公告失败:', err)
    }
  },

  onCloseAnnouncement() {
    if (this.data.announcement) {
      wx.setStorageSync('lastReadAnnouncementId', this.data.announcement._id)
    }
    this.setData({ showAnnouncement: false })
  },

  async loadCategories() {
    try {
      const res = await wx.cloud.callFunction({
        name: 'forum',
        data: { action: 'getCategories' }
      }) as any
      if (res.result && res.result.success) {
        this.setData({ categories: res.result.categories })
      }
    } catch (err) {
      console.error('加载分类失败:', err)
    }
  },

  async loadPosts() {
    if (this.data.loading) return
    this.setData({ loading: true })

    try {
      const res = await wx.cloud.callFunction({
        name: 'forum',
        data: {
          action: 'getPosts',
          data: {
            category: this.data.currentCategory,
            orderBy: this.data.activeTab,
            page: this.data.page,
            pageSize: 10
          }
        }
      }) as any

      if (res.result && res.result.success) {
        const posts = res.result.posts.map((post: any) => ({
          ...post,
          createTimeText: this.formatTime(post.createTime)
        }))
        this.setData({
          posts: this.data.page === 1 ? posts : [...this.data.posts, ...posts],
          hasMore: res.result.hasMore
        })
      }
    } catch (err) {
      console.error('加载帖子失败:', err)
    } finally {
      this.setData({ loading: false, refreshing: false })
    }
  },

  async loadUnreadCount() {
    try {
      const res = await wx.cloud.callFunction({
        name: 'forum',
        data: { action: 'getUnreadCount' }
      }) as any
      if (res.result && res.result.success) {
        this.setData({ unreadCount: res.result.count })
      }
    } catch (err) {
      console.error('获取未读数失败:', err)
    }
  },

  formatTime(date: any): string {
    if (!date) return ''
    const d = new Date(date)
    const now = new Date()
    const diff = now.getTime() - d.getTime()
    
    if (diff < 60000) return '刚刚'
    if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前'
    if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前'
    if (diff < 604800000) return Math.floor(diff / 86400000) + '天前'
    
    return (d.getMonth() + 1) + '月' + d.getDate() + '日'
  },

  onCategoryTap(e: any) {
    const key = e.currentTarget.dataset.key
    if (key === this.data.currentCategory) return
    this.setData({ currentCategory: key, page: 1, posts: [] })
    this.loadPosts()
  },

  onTabTap(e: any) {
    const tab = e.currentTarget.dataset.tab
    if (tab === this.data.activeTab) return
    this.setData({ activeTab: tab, page: 1, posts: [] })
    this.loadPosts()
  },

  onRefresh() {
    this.setData({ refreshing: true, page: 1 })
    this.loadPosts()
  },

  onLoadMore() {
    if (!this.data.hasMore || this.data.loading) return
    this.setData({ page: this.data.page + 1 })
    this.loadPosts()
  },

  onAvatarTap(e: any) {
    const openid = e.currentTarget.dataset.openid
    const name = e.currentTarget.dataset.name
    const avatar = e.currentTarget.dataset.avatar
    const app = getApp()
    const myOpenid = app.getOpenIdSync()
    
    if (!openid || openid === myOpenid) return
    
    wx.navigateTo({
      url: '/packageForum/pages/chat/chat?toOpenid=' + openid + '&toName=' + encodeURIComponent(name || '用户') + '&toAvatar=' + encodeURIComponent(avatar || ''),
      fail: (err) => {
        console.error('跳转聊天页面失败:', err)
      }
    })
  },

  goToDetail(e: any) {
    wx.navigateTo({
      url: '/packageForum/pages/detail/detail?id=' + e.currentTarget.dataset.id,
      fail: (err) => {
        console.error('跳转详情页面失败:', err)
      }
    })
  },

  goToPost() {
    wx.navigateTo({ 
      url: '/packageForum/pages/post/post',
      fail: (err) => {
        console.error('跳转发帖页面失败:', err)
      }
    })
  },

  goToMine() {
    wx.navigateTo({ 
      url: '/pages/profile/profile?source=forum',
      fail: (err) => {
        console.error('跳转我的页面失败:', err)
      }
    })
  },

  goToMessages() {
    wx.navigateTo({ 
      url: '/packageForum/pages/messages/messages',
      fail: (err) => {
        console.error('跳转消息页面失败:', err)
      }
    })
  },

  goToSearch() {
    wx.navigateTo({ 
      url: '/packageForum/pages/list/list?search=1',
      fail: (err) => {
        console.error('跳转搜索页面失败:', err)
      }
    })
  }
})
