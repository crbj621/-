App({
  globalData: {
    userInfo: null as any,
    openid: '',
    hasUserInfo: false,
    distance: 0,
    runTime: 0,
    runCount: 0,
    runningState: null as any
  },

  onLaunch() {
    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力')
      return
    }

    wx.cloud.init({
      env: 'cloudbase-8gy1i7h07bd9a58c',
      traceUser: true
    })

    this.initLoginState()

    wx.getSetting({
      success: (res) => {
        if (!res.authSetting['scope.userLocation']) {
          wx.authorize({
            scope: 'scope.userLocation',
            fail: () => {
              console.log('用户暂未授权定位权限')
            }
          })
        }
      }
    })
  },

  initLoginState() {
    var cachedUserInfo = wx.getStorageSync('userInfo')
    var cachedOpenid = wx.getStorageSync('openid')
    
    if (cachedOpenid) {
      this.globalData.openid = cachedOpenid
    }
    
    if (cachedUserInfo) {
      this.globalData.userInfo = cachedUserInfo
      this.globalData.hasUserInfo = true
    }
    
    if (!cachedOpenid) {
      this.getOpenId()
    }
  },

  async getOpenId() {
    try {
      const res = await wx.cloud.callFunction({
        name: 'login'
      })
      console.log('获取 openid 结果:', res)
      
      if (res.result && res.result.openid) {
        this.globalData.openid = res.result.openid
        wx.setStorageSync('openid', res.result.openid)
        console.log('openid 已保存:', res.result.openid)
      }
    } catch (err) {
      console.error('获取 openid 失败:', err)
    }
  },

  getOpenIdSync() {
    if (this.globalData.openid) {
      return this.globalData.openid
    }
    return wx.getStorageSync('openid') || ''
  },

  getGlobalOpenId() {
    return this.getOpenIdSync()
  },

  getUserInfo() {
    if (this.globalData.userInfo) {
      return this.globalData.userInfo
    }
    return wx.getStorageSync('userInfo') || null
  },

  isLoggedIn() {
    if (this.globalData.hasUserInfo && this.globalData.userInfo && this.globalData.userInfo.nickName) {
      return true
    }
    var cachedUserInfo = wx.getStorageSync('userInfo')
    var cachedOpenid = wx.getStorageSync('openid')
    return !!(cachedOpenid && cachedUserInfo && cachedUserInfo.nickName)
  },

  async doLogin(userInfo: any) {
    if (!userInfo || !userInfo.nickName) {
      return { success: false, message: '请输入昵称' }
    }

    var openid = this.getOpenIdSync()
    
    if (!openid) {
      try {
        await this.getOpenId()
        openid = this.getOpenIdSync()
      } catch (err) {
        console.error('获取 openid 失败:', err)
        return { success: false, message: '获取 openid 失败' }
      }
    }

    if (!openid) {
      return { success: false, message: '登录失败，请重试' }
    }

    this.globalData.userInfo = userInfo
    this.globalData.openid = openid
    this.globalData.hasUserInfo = true

    wx.setStorageSync('userInfo', userInfo)
    wx.setStorageSync('openid', openid)
    wx.removeStorageSync('skipAuth')
    wx.removeStorageSync('food_skip_login')

    try {
      var saveRes = await wx.cloud.callFunction({
        name: 'saveUserInfo',
        data: {
          nickName: userInfo.nickName,
          avatarUrl: userInfo.avatarUrl || ''
        }
      }) as any
      
      if (saveRes.result && saveRes.result.userId) {
        wx.setStorageSync('userId', saveRes.result.userId)
      }
    } catch (err) {
      console.error('保存用户信息到云端失败:', err)
    }

    return { success: true, openid: openid }
  },

  doLogout() {
    this.globalData.userInfo = null
    this.globalData.openid = ''
    this.globalData.hasUserInfo = false

    wx.removeStorageSync('userInfo')
    wx.removeStorageSync('openid')
    wx.removeStorageSync('userId')
    wx.removeStorageSync('skipAuth')
    wx.removeStorageSync('food_openid')
    wx.removeStorageSync('food_user_info')
    wx.removeStorageSync('food_skip_login')
  },

  checkLogin(options?: { redirect?: boolean }) {
    var redirect = options && options.redirect !== false
    
    if (!this.isLoggedIn()) {
      if (redirect) {
        wx.reLaunch({ url: '/pages/login/login' })
      }
      return false
    }
    return true
  },

  updateUserInfo(userInfo: any) {
    this.globalData.userInfo = userInfo
    wx.setStorageSync('userInfo', userInfo)
  },

  updateAvatar(avatarUrl: string) {
    var userInfo = this.getUserInfo() || {}
    userInfo.avatarUrl = avatarUrl
    this.updateUserInfo(userInfo)
  },

  updateNickname(nickName: string) {
    var userInfo = this.getUserInfo() || {}
    userInfo.nickName = nickName
    this.updateUserInfo(userInfo)
  }
})
