function normalizeCloudError(err) {
  const msg = (err && (err.errMsg || err.message)) ? (err.errMsg || err.message) : ''
  if (!msg) return '网络异常，请稍后重试'
  if (msg.includes('FunctionName parameter could not be found') || msg.includes('function not found')) {
    return '云函数未部署，请先在开发者工具上传并部署 food_manager'
  }
  if (msg.includes('environment') || msg.includes('env')) {
    return '云环境配置异常，请检查 app.ts 的 envId'
  }
  if (msg.includes('permission') || msg.includes('auth')) {
    return '云数据库权限不足，请检查集合权限与登录状态'
  }
  return msg
}

function callFoodFunction(action, data, options = {}) {
  const showLoading = options.showLoading === true
  const loadingTitle = options.loadingTitle || '加载中'
  if (showLoading) {
    wx.showLoading({ title: loadingTitle, mask: true })
  }
  return wx.cloud.callFunction({
    name: 'food_manager',
    data: { action, data: data || {} }
  }).then((res) => {
    if (showLoading) wx.hideLoading()
    const result = res && res.result ? res.result : {}
    if (result.success) return result
    throw new Error(result.msg || '服务返回异常')
  }).catch((err) => {
    if (showLoading) wx.hideLoading()
    throw new Error(normalizeCloudError(err))
  })
}

module.exports = {
  callFoodFunction,
  normalizeCloudError
}
