Page({
  data: {
    loading: false,
    form: {
      realName: '',
      phone: '',
      studentId: ''
    }
  },

  onLoad() {
    this.checkProfile()
  },

  async checkProfile() {
    try {
      const res = await wx.cloud.callFunction({
        name: 'rider',
        data: { action: 'getProfile' }
      }) as any

      if (res.result && res.result.code === 0 && res.result.data && res.result.data.registered) {
        wx.setStorageSync('riderInfo', res.result.data.rider)
        wx.redirectTo({ url: '/packageRider/pages/hall/hall' })
      }
    } catch (e) {}
  },

  onInput(e: any) {
    const field = e.currentTarget.dataset.field
    this.setData({ [`form.${field}`]: e.detail.value })
  },

  async submit() {
    if (this.data.loading) return
    const { realName, phone, studentId } = this.data.form
    if (!realName || !phone || !studentId) {
      wx.showToast({ title: '请完整填写信息', icon: 'none' })
      return
    }

    this.setData({ loading: true })
    try {
      const res = await wx.cloud.callFunction({
        name: 'rider',
        data: { action: 'register', data: this.data.form }
      }) as any

      if (res.result && res.result.code === 0) {
        wx.setStorageSync('riderInfo', res.result.data.rider)
        wx.showToast({ title: '注册成功', icon: 'success' })
        setTimeout(() => {
          wx.redirectTo({ url: '/packageRider/pages/hall/hall' })
        }, 800)
      } else {
        wx.showToast({ title: (res.result && res.result.message) ? res.result.message : '注册失败', icon: 'none', duration: 2500 })
      }
    } catch (e) {
      console.error('骑手注册异常:', e)
      wx.showToast({ title: '注册失败，请检查云函数是否已部署', icon: 'none', duration: 2500 })
    } finally {
      this.setData({ loading: false })
    }
  }
})
