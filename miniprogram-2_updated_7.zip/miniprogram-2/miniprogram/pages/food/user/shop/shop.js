const { callFoodFunction } = require('../../../../utils/food-cloud')

Page({
  data: {
    shopId: '',
    shop: null,
    menu: [],
    currentCategory: 0,
    cart: {}, // dishId -> count
    cartList: [], // items with detail
    totalCount: 0,
    totalPrice: 0,
    showCartModal: false
  },

  onLoad(options) {
    if (options.id) {
      this.setData({ shopId: options.id });
      this.loadShopDetail(options.id);
    }
  },

  loadShopDetail(shopId) {
    callFoodFunction('getShopDetail', { shopId }, { showLoading: true, loadingTitle: '加载中' }).then((result) => {
      this.setData({
        shop: result.shop,
        menu: result.menu
      });
    }).catch(err => {
      wx.showToast({ title: err.message || '加载失败', icon: 'none' });
    });
  },

  switchCategory(e) {
    this.setData({ currentCategory: e.currentTarget.dataset.index });
  },

  updateCart(e) {
    const { dish, action } = e.currentTarget.dataset;
    const { cart } = this.data;
    const currentCount = cart[dish._id] || 0;
    
    let newCount = currentCount;
    if (action === 'plus') {
      newCount++;
    } else if (action === 'minus') {
      newCount = Math.max(0, newCount - 1);
    }

    if (newCount === 0) {
      delete cart[dish._id];
    } else {
      cart[dish._id] = newCount;
    }

    this.setData({ cart });
    this.computeTotals();
  },

  computeTotals() {
    const { cart, menu } = this.data;
    let totalCount = 0;
    let totalPrice = 0;
    const cartList = [];

    // 遍历菜单找到对应的菜品详情
    menu.forEach(cat => {
      cat.items.forEach((dish) => {
        if (cart[dish._id]) {
          const count = cart[dish._id];
          totalCount += count;
          totalPrice += dish.price * count;
          cartList.push({ ...dish, count });
        }
      });
    });

    this.setData({
      totalCount,
      totalPrice: Math.round(totalPrice * 100) / 100,
      cartList
    });
    
    if (totalCount === 0) {
      this.setData({ showCartModal: false });
    }
  },

  showCartDetail() {
    if (this.data.totalCount > 0) {
      this.setData({ showCartModal: !this.data.showCartModal });
    }
  },

  hideCartDetail() {
    this.setData({ showCartModal: false });
  },

  clearCart() {
    wx.showModal({
      title: '清空购物车',
      content: '确定要清空吗？',
      success: (res) => {
        if (res.confirm) {
          this.setData({
            cart: {},
            totalCount: 0,
            totalPrice: 0,
            cartList: [],
            showCartModal: false
          });
        }
      }
    });
  },

  goToCheckout() {
    const { totalPrice, shop, cartList, shopId } = this.data;
    if (totalPrice < (shop.minPrice || 0)) {
      return;
    }
    
    // 将购物车数据存入本地缓存，供结算页使用
    wx.setStorageSync('current_order', {
      shop,
      items: cartList,
      totalPrice
    });

    wx.navigateTo({
      url: `/pages/food/user/order/order`
    });
  }
});
