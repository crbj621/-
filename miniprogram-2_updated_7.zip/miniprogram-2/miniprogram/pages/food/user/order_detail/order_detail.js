const { callFoodFunction } = require('../../../../utils/food-cloud')

Page({
  data: {
    order: null,
    statusMap: {
      'pending': '待接单',
      'processing': '制作中',
      'ready': '待取/配送',
      'completed': '已完成',
      'cancelled': '已取消'
    }
  },

  onLoad(options) {
    if (options.id) {
      this.loadDetail(options.id);
    }
  },

  loadDetail(orderId) {
    callFoodFunction('getOrderDetail', { orderId }).then((result) => {
      this.setData({ order: result.detail });
    }).catch((err) => {
      wx.showToast({ title: err.message || '加载失败', icon: 'none' });
    });
  },

  cancelOrder() {
    wx.showModal({
      title: '取消订单',
      content: '确定要取消吗？',
      success: (res) => {
        if (res.confirm) {
          callFoodFunction('updateOrderStatus', {
            orderId: this.data.order._id,
            status: 'cancelled'
          }).then(() => {
            wx.showToast({ title: '已取消', icon: 'success' });
            this.loadDetail(this.data.order._id);
          }).catch((err) => {
            wx.showToast({ title: err.message || '取消失败', icon: 'none' });
          });
        }
      }
    });
  }
});
