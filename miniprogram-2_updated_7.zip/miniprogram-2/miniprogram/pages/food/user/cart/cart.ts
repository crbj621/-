Page({
  data: {
    orderData: null as any
  },

  onShow() {
    this.loadCart();
  },

  loadCart() {
    const orderData = wx.getStorageSync('current_order');
    if (orderData && orderData.items && orderData.items.length > 0) {
      this.setData({ orderData });
    } else {
      this.setData({ orderData: null });
    }
  },

  updateCount(e: any) {
    const { index, action } = e.currentTarget.dataset;
    const { orderData } = this.data;
    const item = orderData.items[index];

    if (action === 'plus') {
      item.count++;
    } else if (action === 'minus') {
      item.count--;
    }

    if (item.count <= 0) {
      orderData.items.splice(index, 1);
    }

    if (orderData.items.length === 0) {
      this.clearCart();
      return;
    }

    // Recalculate total
    let total = 0;
    orderData.items.forEach((dish: any) => {
      total += dish.price * dish.count;
    });
    orderData.totalPrice = Math.round(total * 100) / 100;

    this.setData({ orderData });
    wx.setStorageSync('current_order', orderData);
  },

  clearCart() {
    wx.removeStorageSync('current_order');
    this.setData({ orderData: null });
  },

  goShop() {
    wx.navigateBack(); // Or go to index
  },

  goToOrder() {
    wx.navigateTo({
      url: '/pages/food/user/order/order'
    });
  }
});
