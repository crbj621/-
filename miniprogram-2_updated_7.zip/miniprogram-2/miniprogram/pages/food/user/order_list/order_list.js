const { callFoodFunction } = require('../../../../utils/food-cloud')

Page({
  data: {
    orders: [],
    loading: true,
    currentTab: 'all',
    statusMap: {
      'pending': '待接单',
      'processing': '制作中',
      'ready': '待取/配送',
      'completed': '已完成',
      'cancelled': '已取消'
    }
  },

  onShow() {
    this.loadOrders();
  },

  onPullDownRefresh() {
    this.loadOrders().then(() => wx.stopPullDownRefresh());
  },

  switchTab(e) {
    this.setData({ currentTab: e.currentTarget.dataset.status }, () => {
      this.loadOrders();
    });
  },

  loadOrders() {
    this.setData({ loading: true });
    return callFoodFunction('getUserOrders', { status: this.data.currentTab }).then((result) => {
      this.setData({ orders: result.list || [] });
      this.setData({ loading: false });
    }).catch(err => {
      this.setData({ loading: false });
      wx.showToast({ title: err.message || '加载失败', icon: 'none' });
    });
  },

  goToDetail(e) {
    wx.navigateTo({
      url: `/pages/food/user/order_detail/order_detail?id=${e.currentTarget.dataset.id}`
    });
  }
});
