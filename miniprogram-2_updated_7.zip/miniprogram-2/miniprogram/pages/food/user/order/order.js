const { callFoodFunction } = require('../../../../utils/food-cloud')

Page({
  data: {
    orderData: null,
    orderType: 'pickup', // pickup, delivery
    address: '',
    phone: '',
    remark: '',
    pickupTime: '',
    finalPrice: 0,
    submitting: false
  },

  onLoad() {
    const orderData = wx.getStorageSync('current_order');
    if (!orderData) {
      wx.showToast({ title: '订单已过期', icon: 'none' });
      setTimeout(() => wx.navigateBack(), 1500);
      return;
    }
    
    this.setData({
      orderData,
      finalPrice: orderData.totalPrice
    });
  },

  switchType(e) {
    const type = e.currentTarget.dataset.type;
    const { orderData } = this.data;
    let finalPrice = orderData.totalPrice;
    
    if (type === 'delivery') {
      finalPrice += (orderData.shop.deliveryFee || 0);
    }
    
    this.setData({
      orderType: type,
      finalPrice: Math.round(finalPrice * 100) / 100
    });
  },

  onInputAddress(e) { this.setData({ address: e.detail.value }); },
  onInputPhone(e) { this.setData({ phone: e.detail.value }); },
  onInputRemark(e) { this.setData({ remark: e.detail.value }); },
  onTimeChange(e) { this.setData({ pickupTime: e.detail.value }); },

  submitOrder() {
    const { orderType, address, phone, pickupTime, orderData, finalPrice, remark } = this.data;
    
    if (!phone) {
      wx.showToast({ title: '请填写联系电话', icon: 'none' });
      return;
    }
    if (phone.length < 6) {
      wx.showToast({ title: '联系电话格式不正确', icon: 'none' });
      return;
    }
    
    if (orderType === 'delivery' && !address) {
      wx.showToast({ title: '请填写配送地址', icon: 'none' });
      return;
    }
    
    if (orderType === 'pickup' && !pickupTime) {
      wx.showToast({ title: '请选择取餐时间', icon: 'none' });
      return;
    }
    
    this.setData({ submitting: true });
    
    callFoodFunction('createOrder', {
      shopId: orderData.shop._id,
      items: orderData.items,
      totalPrice: finalPrice,
      type: orderType,
      address: orderType === 'delivery' ? address : '',
      pickupTime: orderType === 'pickup' ? pickupTime : '',
      phone,
      remark
    }).then((result) => {
      this.setData({ submitting: false });
      wx.showToast({ title: '下单成功', icon: 'success' });
      wx.removeStorageSync('current_order');
      wx.redirectTo({
        url: `/pages/food/user/order_detail/order_detail?id=${result.orderId}`
      });
    }).catch(err => {
      this.setData({ submitting: false });
      wx.showToast({ title: err.message || '下单失败', icon: 'none' });
    });
  }
});
