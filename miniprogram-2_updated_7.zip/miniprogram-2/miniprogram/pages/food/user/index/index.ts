import { callFoodFunction } from '../../../../utils/food-cloud'

Page({
  data: {
    shops: [] as any[],
    loading: true,
    keyword: '',
    page: 1,
    pageSize: 10,
    hasMore: true,
    refreshing: false
  },

  onLoad() {
    this.loadShops()
  },

  onPullDownRefresh() {
    this.onRefresh()
  },

  onRefresh() {
    this.setData({ refreshing: true, page: 1, hasMore: true })
    this.loadShops().then(() => {
      this.setData({ refreshing: false })
      wx.stopPullDownRefresh()
    })
  },

  loadMore() {
    if (this.data.loading || !this.data.hasMore) return
    this.setData({ page: this.data.page + 1 })
    this.loadShops(true)
  },

  loadShops(isLoadMore = false) {
    if (!isLoadMore) {
      this.setData({ loading: true, page: 1 })
    }
    
    return callFoodFunction('getShopList', { 
      keyword: this.data.keyword,
      page: this.data.page,
      pageSize: this.data.pageSize
    }).then((result: any) => {
      const newList = result.list || []
      const shops = isLoadMore ? [...this.data.shops, ...newList] : newList
      
      this.setData({
        shops,
        loading: false,
        hasMore: newList.length >= this.data.pageSize
      })
    }).catch(err => {
      wx.showToast({ title: err.message || '加载失败', icon: 'none' })
      this.setData({ loading: false })
    })
  },

  onSearchInput(e: any) {
    this.setData({ keyword: e.detail.value })
  },

  onSearch(e: any) {
    this.setData({ keyword: e.detail.value, page: 1, hasMore: true })
    this.loadShops()
  },

  goToShop(e: any) {
    const shopId = e.currentTarget.dataset.id
    wx.navigateTo({
      url: `/pages/food/user/shop/shop?id=${shopId}`
    })
  }
})
