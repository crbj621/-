const { callFoodFunction } = require('../../../../utils/food-cloud')

Page({
  data: {
    shops: [],
    loading: true,
    keyword: ''
  },

  onLoad() {
    this.loadShops();
  },

  onPullDownRefresh() {
    this.loadShops().then(() => {
      wx.stopPullDownRefresh();
    });
  },

  loadShops() {
    this.setData({ loading: true });
    return callFoodFunction('getShopList', { keyword: this.data.keyword }).then((result) => {
      this.setData({
        shops: result.list || [],
        loading: false
      });
    }).catch(err => {
      wx.showToast({ title: err.message || '加载失败', icon: 'none' });
      this.setData({ loading: false });
    });
  },

  onSearch(e) {
    this.setData({ keyword: e.detail.value }, () => {
      this.loadShops();
    });
  },

  goToShop(e) {
    const shopId = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/food/user/shop/shop?id=${shopId}`
    });
  },

  goToMerchantLogin() {
    wx.navigateTo({
      url: '/pages/food/shop/login/login'
    });
  },

  goToProfile() {
    wx.navigateTo({
      url: '/pages/profile/profile'
    });
  }
});
