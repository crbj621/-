Page({
  data: {
    isMerchant: false,
    shopId: '',
    shopStatus: ''
  },

  onLoad() {
    // 统一个人中心：点餐模块进入时，优先显示点餐功能区
    wx.redirectTo({ url: '/pages/profile/profile?source=food' })
  },

  onShow() {
    this.checkMerchantStatus()
  },

  async checkMerchantStatus() {
    try {
      const res = await wx.cloud.callFunction({
        name: 'food_manager',
        data: { action: 'checkMerchantStatus' }
      })
      if (res.result.success) {
        this.setData({
          isMerchant: res.result.isMerchant,
          shopId: res.result.shopId,
          shopStatus: res.result.shopStatus
        })
      }
    } catch (err) {
      console.error(err)
    }
  },

  goToRegister() {
    wx.navigateTo({
      url: '/pages/food/shop/register/register'
    })
  },

  goToShopManage() {
    if (this.data.shopId) {
      wx.navigateTo({
        url: `/pages/food/shop/index/index?shopId=${this.data.shopId}`
      })
    }
  },

  goToProductManage() {
    if (this.data.shopId) {
      wx.navigateTo({
        url: `/pages/food/shop/dish_edit/dish_edit?shopId=${this.data.shopId}`
      })
    }
  },

  goToStats() {
    wx.showToast({ title: '功能开发中', icon: 'none' })
  },

  goToShopOrders() {
    if (this.data.shopId) {
      wx.navigateTo({
        url: `/pages/food/shop/index/index?shopId=${this.data.shopId}&tab=orders`
      })
    }
  }
})
