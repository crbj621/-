import { callFoodFunction } from '../../../../utils/food-cloud'

Page({
  data: {
    shopId: '',
    shop: {}
  },

  onLoad() {
    this.setData({ shopId: wx.getStorageSync('food_shop_id') });
    this.loadShop();
  },

  loadShop() {
    callFoodFunction('getShopDetail', { shopId: this.data.shopId }).then((result: any) => {
      this.setData({ shop: result.shop || {} });
    }).catch((err) => {
      wx.showToast({ title: err.message || '加载失败', icon: 'none' });
    });
  },

  onInput(e: any) {
    const field = e.currentTarget.dataset.field;
    this.setData({
      [`shop.${field}`]: e.detail.value
    });
  },

  onSwitchStatus(e: any) {
    this.setData({
      'shop.status': e.detail.value ? 'open' : 'closed'
    });
  },

  saveSettings() {
    const { shop } = this.data;
    callFoodFunction('updateShopInfo', {
      shopData: {
        ...shop,
        minPrice: Number(shop.minPrice),
        deliveryFee: Number(shop.deliveryFee)
      }
    }, { showLoading: true, loadingTitle: '保存中' }).then(() => {
      wx.showToast({ title: '保存成功', icon: 'success' });
    }).catch((err) => {
      wx.showToast({ title: err.message || '保存失败', icon: 'none' });
    });
  }
});
