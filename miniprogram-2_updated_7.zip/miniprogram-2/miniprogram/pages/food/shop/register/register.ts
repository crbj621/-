Page({
  data: {
    coverImage: '',
    licenseImage: ''
  },

  chooseImage(e: any) {
    const type = e.currentTarget.dataset.type
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      success: async (res) => {
        const tempFilePath = res.tempFiles[0].tempFilePath
        
        // Upload to cloud storage
        const cloudPath = `shop/${type}/${Date.now()}-${Math.floor(Math.random() * 1000)}.png`
        wx.showLoading({ title: '上传中...' })
        
        try {
          const uploadRes = await wx.cloud.uploadFile({
            cloudPath,
            filePath: tempFilePath,
          })
          
          if (type === 'cover') {
            this.setData({ coverImage: uploadRes.fileID })
          } else {
            this.setData({ licenseImage: uploadRes.fileID })
          }
        } catch (err) {
          wx.showToast({ title: '上传失败', icon: 'none' })
        } finally {
          wx.hideLoading()
        }
      }
    })
  },

  async onSubmit(e: any) {
    const { name, contact, phone } = e.detail.value
    const { coverImage, licenseImage } = this.data

    if (!name || !contact || !phone || !coverImage || !licenseImage) {
      wx.showToast({ title: '请填写完整信息', icon: 'none' })
      return
    }

    wx.showLoading({ title: '提交中...' })

    try {
      const res = await wx.cloud.callFunction({
        name: 'food_manager',
        data: {
          action: 'registerMerchant',
          data: {
            name,
            contact,
            phone,
            coverImage,
            licenseImage
          }
        }
      })

      if (res.result.success) {
        wx.showToast({ title: '提交成功，等待审核', icon: 'success' })
        setTimeout(() => {
          wx.navigateBack()
        }, 1500)
      } else {
        wx.showToast({ title: res.result.msg || '提交失败', icon: 'none' })
      }
    } catch (err) {
      console.error(err)
      wx.showToast({ title: '提交失败', icon: 'none' })
    } finally {
      wx.hideLoading()
    }
  }
})