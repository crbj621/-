Page({
  data: {
    username: '',
    password: '',
    loading: false,
    autoLogging: true
  },

  onLoad() {
    this.tryAutoLogin()
  },

  async tryAutoLogin() {
    const shopId = wx.getStorageSync('food_shop_id')
    if (shopId) {
      wx.redirectTo({ url: '/pages/food/shop/index/index' })
      return
    }

    try {
      const res = await wx.cloud.callFunction({
        name: 'food_manager',
        data: { action: 'shopAutoLogin' }
      }) as any

      if (res.result.success) {
        wx.setStorageSync('food_shop_id', res.result.shopId)
        wx.setStorageSync('shop_info', res.result.shopInfo)
        wx.redirectTo({ url: '/pages/food/shop/index/index' })
        return
      }
    } catch (err) {
      console.error('自动登录失败', err)
    }

    this.setData({ autoLogging: false })
  },

  onUsernameInput(e: any) {
    this.setData({ username: e.detail.value })
  },

  onPasswordInput(e: any) {
    this.setData({ password: e.detail.value })
  },

  async login() {
    if (!this.data.username || !this.data.password) {
      wx.showToast({ title: '请输入账号密码', icon: 'none' })
      return
    }

    this.setData({ loading: true })

    try {
      const res = await wx.cloud.callFunction({
        name: 'food_manager',
        data: {
          action: 'shopLogin',
          data: {
            username: this.data.username,
            password: this.data.password
          }
        }
      }) as any

      if (res.result.success) {
        wx.setStorageSync('food_shop_id', res.result.shopId)
        wx.showToast({ title: '登录成功', icon: 'success' })
        setTimeout(() => {
          wx.redirectTo({ url: '/pages/food/shop/index/index' })
        }, 500)
      } else {
        wx.showToast({ title: res.result.msg || '登录失败', icon: 'none' })
      }
    } catch (err) {
      wx.showToast({ title: '登录失败', icon: 'none' })
    } finally {
      this.setData({ loading: false })
    }
  }
})
