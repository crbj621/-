const { callFoodFunction } = require('../../../../utils/food-cloud')

Page({
  data: {
    username: '',
    password: '',
    loading: false
  },

  onLoad() {
    const shopId = wx.getStorageSync('food_shop_id');
    if (shopId) {
      wx.redirectTo({ url: '/pages/food/shop/index/index' });
    }
  },

  login() {
    if (!this.data.username || !this.data.password) {
      wx.showToast({ title: '请输入账号密码', icon: 'none' });
      return;
    }

    this.setData({ loading: true });
    
    callFoodFunction('shopLogin', {
      username: this.data.username,
      password: this.data.password
    }).then((result) => {
      this.setData({ loading: false });
      wx.setStorageSync('food_shop_id', result.shopId);
      wx.showToast({ title: '登录成功', icon: 'success' });
      wx.redirectTo({ url: '/pages/food/shop/index/index' });
    }).catch(err => {
      this.setData({ loading: false });
      wx.showToast({ title: err.message || '登录失败', icon: 'none' });
    });
  }
});
