const { callFoodFunction } = require('../../../../utils/food-cloud')

Page({
  data: {
    shopId: '',
    dishes: [],
    showModal: false,
    isEdit: false,
    form: { name: '', price: '', category: '', image: '', _id: '' }
  },

  onLoad() {
    this.setData({ shopId: wx.getStorageSync('food_shop_id') });
    this.loadDishes();
  },

  loadDishes() {
    callFoodFunction('getShopDetail', { shopId: this.data.shopId }).then((result) => {
      const dishes = [];
      (result.menu || []).forEach((cat) => dishes.push(...cat.items));
      this.setData({ dishes });
    }).catch((err) => {
      wx.showToast({ title: err.message || '加载失败', icon: 'none' });
    });
  },

  addDish() {
    this.setData({
      showModal: true,
      isEdit: false,
      form: { name: '', price: '', category: '', image: '' }
    });
  },

  editDish(e) {
    const item = e.currentTarget.dataset.item;
    this.setData({
      showModal: true,
      isEdit: true,
      form: { ...item }
    });
  },

  hideModal() { this.setData({ showModal: false }); },

  saveDish() {
    const { form, isEdit, shopId } = this.data;
    if (!form.name || !form.price) return;

    const dishData = {
      ...form,
      price: Number(form.price),
      shopId,
      isAvailable: true
    };

    callFoodFunction('manageDish', {
      type: isEdit ? 'update' : 'add',
      dishData
    }, { showLoading: true, loadingTitle: '保存中' }).then(() => {
      this.hideModal();
      this.loadDishes();
    }).catch((err) => {
      wx.showToast({ title: err.message || '保存失败', icon: 'none' });
    });
  },

  deleteDish(e) {
    wx.showModal({
      title: '删除',
      content: '确定删除吗？',
      success: (res) => {
        if (res.confirm) {
          callFoodFunction('manageDish', {
            type: 'delete',
            dishData: { _id: e.currentTarget.dataset.id }
          }).then(() => {
            this.loadDishes();
          }).catch((err) => {
            wx.showToast({ title: err.message || '删除失败', icon: 'none' });
          });
        }
      }
    });
  }
});
