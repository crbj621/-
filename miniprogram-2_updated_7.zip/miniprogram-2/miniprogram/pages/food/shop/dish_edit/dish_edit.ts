Page({
  data: {
    shopId: '',
    dishes: [] as any[],
    categories: [] as string[],
    currentCategory: 'all',
    showModal: false,
    isEdit: false,
    form: {
      name: '',
      price: '',
      category: '',
      image: '',
      description: '',
      stock: '',
      _id: ''
    },
    uploading: false
  },

  onLoad() {
    const shopId = wx.getStorageSync('food_shop_id')
    if (!shopId) {
      wx.redirectTo({ url: '/pages/food/shop/login/login' })
      return
    }
    this.setData({ shopId })
    this.loadDishes()
  },

  onPullDownRefresh() {
    this.loadDishes().then(() => wx.stopPullDownRefresh())
  },

  async loadDishes() {
    try {
      const res = await wx.cloud.callFunction({
        name: 'food_manager',
        data: {
          action: 'getShopDishes',
          data: { shopId: this.data.shopId }
        }
      }) as any

      if (res.result.success) {
        const dishes = res.result.dishes || []
        const categories = [...new Set(dishes.map((d: any) => d.category || '默认分类'))]
        this.setData({ dishes, categories })
      }
    } catch (err) {
      wx.showToast({ title: '加载失败', icon: 'none' })
    }
  },

  filterCategory(e: any) {
    this.setData({ currentCategory: e.currentTarget.dataset.category })
  },

  get filteredDishes() {
    const { dishes, currentCategory } = this.data
    if (currentCategory === 'all') return dishes
    return dishes.filter((d: any) => (d.category || '默认分类') === currentCategory)
  },

  addDish() {
    this.setData({
      showModal: true,
      isEdit: false,
      form: {
        name: '',
        price: '',
        category: '',
        image: '',
        description: '',
        stock: '999',
        _id: ''
      }
    })
  },

  editDish(e: any) {
    const item = e.currentTarget.dataset.item
    this.setData({
      showModal: true,
      isEdit: true,
      form: {
        name: item.name || '',
        price: String(item.price || ''),
        category: item.category || '',
        image: item.image || '',
        description: item.description || '',
        stock: String(item.stock || 999),
        _id: item._id
      }
    })
  },

  hideModal() {
    this.setData({ showModal: false })
  },

  onInputChange(e: any) {
    const field = e.currentTarget.dataset.field
    this.setData({ [`form.${field}`]: e.detail.value })
  },

  chooseImage() {
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      success: async (res) => {
        const tempFilePath = res.tempFiles[0].tempFilePath
        this.setData({ uploading: true })

        try {
          const cloudPath = `dishes/${Date.now()}-${Math.random().toString(36).substr(2, 9)}.jpg`
          const uploadRes = await wx.cloud.uploadFile({
            cloudPath,
            filePath: tempFilePath
          })
          this.setData({
            'form.image': uploadRes.fileID,
            uploading: false
          })
          wx.showToast({ title: '上传成功', icon: 'success' })
        } catch (err) {
          this.setData({ uploading: false })
          wx.showToast({ title: '上传失败', icon: 'none' })
        }
      }
    })
  },

  async saveDish() {
    const { form, isEdit } = this.data
    if (!form.name || !form.price) {
      wx.showToast({ title: '请填写菜品名称和价格', icon: 'none' })
      return
    }

    wx.showLoading({ title: '保存中...' })

    try {
      const dishData: any = {
        name: form.name,
        price: Number(form.price),
        category: form.category || '默认分类',
        image: form.image,
        description: form.description,
        stock: Number(form.stock || 999),
        isAvailable: true
      }

      if (isEdit && form._id) {
        dishData._id = form._id
      }

      const res = await wx.cloud.callFunction({
        name: 'food_manager',
        data: {
          action: 'manageDish',
          data: {
            type: isEdit ? 'update' : 'add',
            dishData
          }
        }
      }) as any

      wx.hideLoading()
      if (res.result.success) {
        wx.showToast({ title: '保存成功', icon: 'success' })
        this.hideModal()
        this.loadDishes()
      } else {
        wx.showToast({ title: res.result.msg || '保存失败', icon: 'none' })
      }
    } catch (err: any) {
      wx.hideLoading()
      wx.showToast({ title: err.message || '保存失败', icon: 'none' })
    }
  },

  deleteDish(e: any) {
    const id = e.currentTarget.dataset.id
    wx.showModal({
      title: '删除菜品',
      content: '确定要删除这道菜品吗？',
      success: async (res) => {
        if (res.confirm) {
          wx.showLoading({ title: '删除中...' })
          try {
            await wx.cloud.callFunction({
              name: 'food_manager',
              data: {
                action: 'manageDish',
                data: {
                  type: 'delete',
                  dishData: { _id: id }
                }
              }
            })
            wx.hideLoading()
            wx.showToast({ title: '删除成功', icon: 'success' })
            this.loadDishes()
          } catch (err) {
            wx.hideLoading()
            wx.showToast({ title: '删除失败', icon: 'none' })
          }
        }
      }
    })
  },

  toggleAvailable(e: any) {
    const { id, available } = e.currentTarget.dataset
    wx.showLoading({ title: '处理中...' })
    wx.cloud.callFunction({
      name: 'food_manager',
      data: {
        action: 'manageDish',
        data: {
          type: 'update',
          dishData: {
            _id: id,
            isAvailable: !available
          }
        }
      }
    }).then(() => {
      wx.hideLoading()
      this.loadDishes()
    }).catch(() => {
      wx.hideLoading()
      wx.showToast({ title: '操作失败', icon: 'none' })
    })
  }
})
