const { callFoodFunction } = require('../../../../utils/food-cloud')

Page({
  data: {
    shopId: '',
    orders: [],
    currentTab: 'pending' // pending, processing, completed
  },

  onLoad() {
    const shopId = wx.getStorageSync('food_shop_id') || '';
    this.setData({ shopId });
    this.loadOrders();
  },

  onPullDownRefresh() {
    this.loadOrders().then(() => wx.stopPullDownRefresh());
  },

  switchTab(e) {
    this.setData({ currentTab: e.currentTarget.dataset.status }, () => {
      this.loadOrders();
    });
  },

  loadOrders() {
    return callFoodFunction('getShopOrders', { status: this.data.currentTab }).then((result) => {
      this.setData({ orders: result.list || [] });
    }).catch((err) => {
      wx.showToast({ title: err.message || '加载失败', icon: 'none' });
      if ((err.message || '').includes('登录')) {
        wx.redirectTo({ url: '/pages/food/shop/login/login' });
      }
    });
  },

  acceptOrder(e) {
    this.updateStatus(e.currentTarget.dataset.id, 'processing');
  },

  rejectOrder(e) {
    wx.showModal({
      title: '拒单理由',
      editable: true,
      placeholderText: '请输入理由（如：已售罄）',
      success: (res) => {
        if (res.confirm) {
          this.updateStatus(e.currentTarget.dataset.id, 'cancelled', res.content);
        }
      }
    });
  },

  readyOrder(e) {
    this.updateStatus(e.currentTarget.dataset.id, 'ready');
  },

  completeOrder(e) {
    this.updateStatus(e.currentTarget.dataset.id, 'completed');
  },

  updateStatus(orderId, status, rejectReason) {
    callFoodFunction('updateOrderStatus', { orderId, status, rejectReason }, { showLoading: true, loadingTitle: '处理中' }).then(() => {
      wx.showToast({ title: '操作成功', icon: 'success' });
      this.loadOrders();
    }).catch((err) => {
      wx.showToast({ title: err.message || '操作失败', icon: 'none' });
    });
  },

  goToDishEdit() {
    wx.navigateTo({ url: '/pages/food/shop/dish_edit/dish_edit' });
  },

  goToSettings() {
    wx.navigateTo({ url: '/pages/food/shop/settings/settings' });
  },

  logout() {
    wx.removeStorageSync('food_shop_id');
    wx.redirectTo({ url: '/pages/food/shop/login/login' });
  }
});
