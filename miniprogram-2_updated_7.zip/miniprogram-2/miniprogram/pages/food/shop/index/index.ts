Page({
  data: {
    shopId: '',
    shopInfo: null as any,
    orders: [],
    currentTab: 'pending',
    stats: {
      pending: 0,
      processing: 0,
      ready: 0,
      todaySales: 0
    }
  },

  onLoad() {
    const shopId = wx.getStorageSync('food_shop_id')
    if (!shopId) {
      wx.redirectTo({ url: '/pages/food/shop/login/login' })
      return
    }
    this.setData({ shopId })
    this.loadShopInfo()
    this.loadOrders()
  },

  onShow() {
    if (this.data.shopId) {
      this.loadOrders()
    }
  },

  onPullDownRefresh() {
    Promise.all([this.loadShopInfo(), this.loadOrders()]).then(() => {
      wx.stopPullDownRefresh()
    })
  },

  async loadShopInfo() {
    try {
      const res = await wx.cloud.callFunction({
        name: 'food_manager',
        data: {
          action: 'getShopDetail',
          data: { shopId: this.data.shopId }
        }
      }) as any

      if (res.result.success) {
        this.setData({ shopInfo: res.result.shop })
      }
    } catch (err) {
      console.error(err)
    }
  },

  async loadOrders() {
    try {
      const res = await wx.cloud.callFunction({
        name: 'food_manager',
        data: {
          action: 'getShopOrders',
          data: { status: this.data.currentTab }
        }
      }) as any

      if (res.result.success) {
        const orders = res.result.list || []
        const stats = {
          pending: 0,
          processing: 0,
          ready: 0,
          todaySales: 0
        }

        const allRes = await wx.cloud.callFunction({
          name: 'food_manager',
          data: {
            action: 'getShopOrders',
            data: { status: 'all' }
          }
        }) as any

        if (allRes.result.success) {
          const allOrders = allRes.result.list || []
          allOrders.forEach((order: any) => {
            if (order.status === 'pending') stats.pending++
            if (order.status === 'processing') stats.processing++
            if (order.status === 'ready') stats.ready++
            if (order.status === 'completed') {
              const today = new Date().toDateString()
              const orderDate = new Date(order.createTime).toDateString()
              if (today === orderDate) {
                stats.todaySales += order.totalPrice
              }
            }
          })
        }

        this.setData({ orders, stats })
      }
    } catch (err) {
      console.error(err)
      wx.showToast({ title: '加载失败', icon: 'none' })
    }
  },

  switchTab(e: any) {
    this.setData({ currentTab: e.currentTarget.dataset.status }, () => {
      this.loadOrders()
    })
  },

  acceptOrder(e: any) {
    this.updateStatus(e.currentTarget.dataset.id, 'processing')
  },

  rejectOrder(e: any) {
    wx.showModal({
      title: '拒单理由',
      editable: true,
      placeholderText: '请输入理由（如：已售罄）',
      success: (res) => {
        if (res.confirm) {
          this.updateStatus(e.currentTarget.dataset.id, 'cancelled', res.content)
        }
      }
    })
  },

  readyOrder(e: any) {
    this.updateStatus(e.currentTarget.dataset.id, 'ready')
  },

  completeOrder(e: any) {
    this.updateStatus(e.currentTarget.dataset.id, 'completed')
  },

  async updateStatus(orderId: string, status: string, rejectReason?: string) {
    wx.showLoading({ title: '处理中...' })
    try {
      const res = await wx.cloud.callFunction({
        name: 'food_manager',
        data: {
          action: 'updateOrderStatus',
          data: { orderId, status, rejectReason }
        }
      }) as any

      wx.hideLoading()
      if (res.result.success) {
        wx.showToast({ title: '操作成功', icon: 'success' })
        this.loadOrders()
      } else {
        wx.showToast({ title: res.result.msg || '操作失败', icon: 'none' })
      }
    } catch (err) {
      wx.hideLoading()
      wx.showToast({ title: '操作失败', icon: 'none' })
    }
  },

  goToDishEdit() {
    wx.navigateTo({ url: '/pages/food/shop/dish_edit/dish_edit' })
  },

  goToSettings() {
    wx.navigateTo({ url: '/pages/food/shop/settings/settings' })
  },

  logout() {
    wx.showModal({
      title: '退出登录',
      content: '确定要退出吗？',
      success: (res) => {
        if (res.confirm) {
          wx.removeStorageSync('food_shop_id')
          wx.removeStorageSync('shop_info')
          wx.redirectTo({ url: '/pages/food/shop/login/login' })
        }
      }
    })
  }
})
