Page({
  data: {
    searchValue: '',
    friendsList: [] as any[],
    searchResults: [] as any[],
    showSearchResults: false
  },

  onLoad() {
    const openid = wx.getStorageSync('openid');
    // 只在没有 openid 时跳转（游客模式也有 openid）
    if (!openid) {
      wx.redirectTo({ url: '/pages/login/login' });
      return;
    }
    this.loadFriends();
  },

  onSearchInput(e: any) {
    const value = e.detail.value;
    this.setData({ searchValue: value });
    if (value.length > 0) {
      this.searchUsers(value);
    } else {
      this.setData({ searchResults: [], showSearchResults: false });
    }
  },

  searchUsers(keyword: string) {
    wx.cloud.callFunction({
      name: 'searchUser',
      data: { keyword, searchType: 'name' },
      success: (res: any) => {
        const openid = wx.getStorageSync('openid');
        const filteredResults = (res.result || []).filter((user: any) => user.openid !== openid);
        this.setData({ searchResults: filteredResults, showSearchResults: true });
      },
      fail: () => {
        this.setData({ searchResults: [], showSearchResults: false });
      }
    });
  },

  addFriend(e: any) {
    const friendOpenid = e.currentTarget.dataset.openid;
    const openid = wx.getStorageSync('openid');
    
    wx.showLoading({ title: '添加中...' });
    wx.cloud.callFunction({
      name: 'addFriend',
      data: { openid, friendOpenid },
      success: () => {
        wx.hideLoading();
        wx.showToast({ title: '添加成功', icon: 'success' });
        this.setData({ searchResults: [], showSearchResults: false, searchValue: '' });
        this.loadFriends();
      },
      fail: () => {
        wx.hideLoading();
        wx.showToast({ title: '添加失败', icon: 'none' });
      }
    });
  },

  deleteFriend(e: any) {
    const friendOpenid = e.currentTarget.dataset.openid;
    
    wx.showModal({
      title: '确认删除',
      content: '确定要删除这个好友吗？',
      success: (res) => {
        if (res.confirm) {
          const openid = wx.getStorageSync('openid');
          wx.showLoading({ title: '删除中...' });
          wx.cloud.callFunction({
            name: 'deleteFriend',
            data: { openid, friendOpenid },
            success: () => {
              wx.hideLoading();
              wx.showToast({ title: '已删除', icon: 'success' });
              this.loadFriends();
            },
            fail: () => {
              wx.hideLoading();
              wx.showToast({ title: '删除失败', icon: 'none' });
            }
          });
        }
      }
    });
  },

  loadFriends() {
    const openid = wx.getStorageSync('openid');
    wx.cloud.callFunction({
      name: 'getFriends',
      data: { openid },
      success: (res: any) => {
        this.setData({ friendsList: res.result || [] });
      },
      fail: () => {
        this.setData({ friendsList: [] });
      }
    });
  }
});
