Page({
  data: {
    userInfo: null
  },

  onShow() {
    const userInfo = wx.getStorageSync('userInfo')
    if (userInfo) {
      this.setData({ userInfo })
    }

    this.showAnnouncementIfNeeded()
  },

  showAnnouncementIfNeeded() {
    wx.cloud.callFunction({
      name: 'globalAdmin',
      data: { action: 'getPublishedAnnouncements', data: { page: 1, pageSize: 1 } },
      success: (res) => {
        if (!(res.result && res.result.code === 0)) return
        const list = (res.result.data && res.result.data.list) ? res.result.data.list : []
        if (!list.length) return
        const a = list[0]
        const lastShown = wx.getStorageSync('lastAnnouncementId')
        if (lastShown === a._id) return
        wx.setStorageSync('lastAnnouncementId', a._id)
        wx.showModal({
          title: a.title || '公告',
          content: a.content || '',
          showCancel: false,
          confirmText: '我知道了'
        })
      },
      fail: () => {}
    })
  },

  goToRun() {
    wx.navigateTo({
      url: '/pages/index/index'
    })
  },

  goToFood() {
    wx.navigateTo({
      url: '/packageFood/pages/index/index'
    })
  },

  goToForum() {
    wx.navigateTo({
      url: '/packageForum/pages/index/index'
    })
  },

  goToProfile() {
    wx.navigateTo({
      url: '/pages/profile/profile'
    })
  },

  goToAdminLogin() {
    wx.navigateTo({
      url: '/pages/admin/login/login'
    })
  },

  logout() {
    wx.showModal({
      title: '退出登录',
      content: '确定要退出吗？',
      success: (res) => {
        if (res.confirm) {
          wx.clearStorageSync()
          wx.reLaunch({
            url: '/pages/login/login'
          })
        }
      }
    })
  }
})
