Page({
  data: {
    rankList: [] as Array<{
      id: string;
      openid: string;
      distance: number;
      time: string;
      date: string;
      nickName: string;
      avatarUrl: string;
    }>,
    activeTab: 'couple',
    isLoggedIn: false
  },

  onLoad() {
    const openid = wx.getStorageSync('openid');
    this.setData({ isLoggedIn: !!openid });
    this.getRankList();
  },

  onShow() {
    const openid = wx.getStorageSync('openid');
    this.setData({ isLoggedIn: !!openid });
    this.getRankList();
  },

  getRankList() {
    const { activeTab } = this.data;
    wx.cloud.callFunction({
      name: 'getRankList',
      data: { tab: activeTab },
      success: (res) => {
        console.log('获取排行榜数据成功：', res);
        let runList = Array.isArray(res.result) ? res.result : (res.data || []);

        if (activeTab === 'couple') {
          const teamList = runList.map((team: any, index: number) => ({
            id: team.teamId || index,
            openid: team.teamId,
            distance: team.totalDistance || 0,
            time: '--:--',
            date: '',
            nickName: team.teamName || '未命名队伍',
            avatarUrl: '/images/default-avatar.png'
          }));
          this.setData({ rankList: teamList });
          return;
        }

        switch (activeTab) {
          case 'god':
            runList = runList.slice(0, 10);
            break;
        }

        const userMap = new Map();
        runList.forEach((item: any) => {
          const userKey = item.openid || item._id;
          if (!userMap.has(userKey) || item.distance > userMap.get(userKey).distance) {
            userMap.set(userKey, item);
          }
        });

        let uniqueList = Array.from(userMap.values());
        uniqueList.sort((a: any, b: any) => b.distance - a.distance);

        const formattedList = uniqueList.map((item: any, index: number) => ({
          id: item._id || index,
          openid: item.openid,
          distance: item.distance || 0,
          time: item.time || '--:--',
          date: item.date || '',
          nickName: item.nickName || '匿名用户',
          avatarUrl: item.avatarUrl || ''
        }));

        this.setData({ rankList: formattedList });
      },
      fail: (err) => {
        console.error('获取排行榜数据失败：', err);
        this.setData({ rankList: [] });
      }
    });
  },

  switchTab(e: any) {
    const tab = e.currentTarget.dataset.tab;
    this.setData({ activeTab: tab });
    this.getRankList();
  },

  goLogin() {
    wx.navigateTo({ url: '/pages/login/login' });
  },

  clearAllData() {
    const openid = wx.getStorageSync('openid');
    if (!openid) {
      wx.showToast({ title: '请先登录', icon: 'none' });
      return;
    }
    wx.showModal({
      title: '确认清空',
      content: '是否清空所有跑步记录？此操作不可恢复！',
      confirmText: '清空',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.removeStorageSync('runList');
          this.setData({ rankList: [] });
          wx.showToast({ title: '记录已清空', icon: 'success' });
        }
      }
    });
  }
});
