Page({
  data: {
    isLoading: false,
    userInfo: {
      avatarUrl: '',
      nickName: ''
    },
    tempAvatarPath: ''
  },

  onLoad(options: any) {
    this.checkLogin(options)
  },

  checkLogin(options: any = {}) {
    const app = getApp()
    
    if (options.forceLogin === 'true') {
      console.log('强制登录模式，不检查登录状态')
      return
    }
    
    if (app.isLoggedIn()) {
      console.log('已登录，跳转到首页')
      wx.redirectTo({
        url: '/pages/portal/portal'
      })
    }
  },

  onChooseAvatar(e: any) {
    const avatarUrl = e.detail.avatarUrl
    console.log('选择的头像路径:', avatarUrl)
    this.setData({
      'userInfo.avatarUrl': avatarUrl,
      tempAvatarPath: avatarUrl
    })
  },

  onNicknameInput(e: any) {
    this.setData({
      'userInfo.nickName': e.detail.value
    })
  },

  onNicknameBlur(e: any) {
    this.setData({
      'userInfo.nickName': e.detail.value
    })
  },

  async doLogin() {
    const { userInfo, tempAvatarPath } = this.data
    
    if (!userInfo.nickName) {
      wx.showToast({ title: '请输入昵称', icon: 'none' })
      return
    }
    
    this.setData({ isLoading: true })
    wx.showLoading({ title: '登录中...', mask: true })
    
    try {
      let avatarUrl = userInfo.avatarUrl || ''
      
      if (tempAvatarPath) {
        const isTempPath = tempAvatarPath.indexOf('wxfile://') === 0 || 
                          tempAvatarPath.indexOf('http://tmp') === 0 ||
                          tempAvatarPath.indexOf('https://tmp') === 0 ||
                          tempAvatarPath.indexOf('/tmp/') !== -1
        
        if (isTempPath || tempAvatarPath.indexOf('cloud://') !== 0) {
          wx.showLoading({ title: '上传头像...', mask: true })
          const cloudPath = 'avatars/' + Date.now() + '-' + Math.random().toString(36).substr(2, 9) + '.jpg'
          console.log('开始上传头像到云存储:', cloudPath)
          
          const uploadRes = await wx.cloud.uploadFile({
            cloudPath: cloudPath,
            filePath: tempAvatarPath
          })
          
          if (uploadRes.fileID) {
            avatarUrl = uploadRes.fileID
            console.log('头像上传成功:', avatarUrl)
          } else {
            console.error('头像上传失败，fileID为空')
          }
        }
      }
      
      const app = getApp()
      const result = await app.doLogin({
        nickName: userInfo.nickName,
        avatarUrl: avatarUrl
      })
      
      wx.hideLoading()
      
      console.log('登录结果:', result)
      
      if (result.success) {
        wx.showToast({ title: '登录成功', icon: 'success' })
        setTimeout(() => {
          wx.redirectTo({
            url: '/pages/portal/portal'
          })
        }, 1000)
      } else {
        wx.showToast({ title: result.message || '登录失败', icon: 'none' })
        this.setData({ isLoading: false })
      }
    } catch (err) {
      wx.hideLoading()
      console.error('登录失败:', err)
      wx.showToast({ title: '登录失败', icon: 'none' })
      this.setData({ isLoading: false })
    }
  },

  skipLogin() {
    const app = getApp()
    const openid = app.getOpenIdSync()
    
    if (openid) {
      wx.setStorageSync('openid', openid)
    }
    
    wx.setStorageSync('skipAuth', true)
    wx.showToast({ title: '已跳过登录', icon: 'success' })
    setTimeout(() => {
      wx.redirectTo({
        url: '/pages/portal/portal'
      })
    }, 500)
  }
})
