Page({
  data: {
    totalMeter: 0,
    isRunning: false,
    isPaused: false,
    lastLat: null as number | null,
    lastLng: null as number | null,
    latitude: 34.4176,
    longitude: 115.6567,
    markers: [] as any[],
    polyline: [] as any[],
    path: [] as any[],
    pathSegments: [] as any[][],
    currentSegmentIndex: 0,
    userInfo: null,
    isLoggedIn: false,
    startTime: 0,
    pauseTime: 0,
    accumulatedPauseTime: 0,
    pace: 0,
    duration: 0,
    steps: 0,
    slideOffset: 0,
    touchStartY: 0,
    formattedPace: "--'--''",
    formattedDuration: '00:00',
    showSearchModal: false,
    searchKeyword: '',
    searchResults: [],
    isSearching: false,
    hasSearched: false,
    
    stepThreshold: 10.5,
    stepBuffer: [] as number[],
    stepLastPeakTime: 0,
    stepMinPeakInterval: 200,
    stepFilteredAcceleration: 9.8,
    stepAlpha: 0.4,
    motionMode: 'unknown',
    stepFrequency: 0,
    stepCountWindow: [] as number[],
    distanceCalibration: 1.0,
    stepLength: 0.75,
    // 仅用于内部算法/调试：原始计步（加速度峰值法）
    rawSteps: 0,
    
    showTeamModal: false,
    altitude: 0,
    speed: 0,
    accuracy: 0,
    heading: 0,
    headingAccuracy: 0,
    motionState: 'stationary',
    friendsList: [],
    selectedFriends: [],
    currentTeam: null,
    isCoupleMode: false,
    coupleRunData: null,
    couplePartner: null,
    isGuest: false,
    
    lastGyroTime: 0,
    rotationAccumulator: 0,
    isTurning: false,
    indoorMode: false,
    sensorInitialized: false,
    lastLocationTime: 0,
    locationBuffer: [] as any[],
    maxJumpDistance: 50,
    // 定位精度阈值（米）：过小会导致大量设备无法累计距离
    minAccuracy: 50,
    isLocationStable: false,
    consecutiveGoodLocations: 0,
    runId: '',
    
    lastAccelData: { x: 0, y: 0, z: 0, magnitude: 9.8 },
    lastGyroData: { x: 0, y: 0, z: 0 },
    accelHistory: [] as number[],
    gyroHistory: [] as number[],
    stepConfidence: 0,
    lastStepConfidence: 0,
    avgStepFrequency: 0,
    realTimePace: 0,
    lapTimes: [] as number[],
    lastLapDistance: 0,
    lapDistance: 1000
  },

  timer: null as any,
  locationUpdateTimer: null as any,
  locationListenerActive: false,

  onLoad() {
    this.clearRunningState()
    this.refreshLoginStatus()
    this.setData({
      latitude: 34.4176,
      longitude: 115.6567,
      markers: [{
        id: 1,
        latitude: 34.4176,
        longitude: 115.6567,
        width: 30,
        height: 30
      }]
    })
    this.setTouchEvents()
  },

  onShow() {
    this.refreshLoginStatus()
  },

  clearRunningState() {
    const app = getApp()
    if (app.globalData) {
      app.globalData.runningState = null
    }
    this.locationListenerActive = false
  },

  refreshLoginStatus() {
    const app = getApp()
    const openid = app.getGlobalOpenId ? app.getGlobalOpenId() : ''
    const userInfo = wx.getStorageSync('userInfo')
    const skipAuth = wx.getStorageSync('skipAuth')

    this.setData({
      userInfo,
      isLoggedIn: !!openid,
      isGuest: !openid || !!skipAuth
    })
  },

  getCurrentLocation() {
    wx.showLoading({ title: '定位中...', mask: true })
    
    wx.getLocation({
      type: 'gcj02',
      isHighAccuracy: true,
      highAccuracyExpireTime: 5000,
      altitude: true,
      success: (res) => {
        wx.hideLoading()
        this.setData({
          latitude: res.latitude,
          longitude: res.longitude,
          altitude: res.altitude || 0,
          speed: res.speed || 0,
          accuracy: res.accuracy || 0,
          markers: [{
            id: 1,
            latitude: res.latitude,
            longitude: res.longitude,
            width: 30,
            height: 30
          }]
        })
      },
      fail: (err) => {
        wx.hideLoading()
        wx.showModal({
          title: '定位失败',
          content: '无法获取您的位置，请检查定位权限设置',
          confirmText: '去设置',
          success: (modalRes) => {
            if (modalRes.confirm) {
              wx.openSetting()
            }
          }
        })
      }
    })
  },

  initSensorsOnStart() {
    if (this.data.sensorInitialized) return
    
    this.setData({ sensorInitialized: true })

    wx.startAccelerometer({
      interval: 'game',
      success: () => {
        console.log('加速度传感器启动成功')
      }
    })

    wx.startGyroscope({
      interval: 'game',
      success: () => {
        console.log('陀螺仪启动成功')
      }
    })

    wx.startCompass({
      interval: 'ui',
      success: () => {
        console.log('罗盘启动成功')
      }
    })

    this.setupSensorListeners()
  },

  setupSensorListeners() {
    let accelBuffer: number[] = []
    let gyroBuffer: number[] = []
    let lastStepTime = 0
    let peakCount = 0
    let valleyCount = 0
    let lastPeakValue = 0
    let lastValleyValue = 15
    let isLookingForPeak = true
    let filteredAccel = 9.8
    let filteredGyro = 0
    const alpha = 0.4

    wx.onAccelerometerChange((res) => {
      if (!this.data.isRunning || this.data.isPaused) return

      const magnitude = Math.sqrt(res.x * res.x + res.y * res.y + res.z * res.z)
      
      filteredAccel = alpha * magnitude + (1 - alpha) * filteredAccel
      
      accelBuffer.push(filteredAccel)
      if (accelBuffer.length > 15) {
        accelBuffer.shift()
      }

      this.setData({ 
        stepFilteredAcceleration: filteredAccel,
        lastAccelData: { x: res.x, y: res.y, z: res.z, magnitude: filteredAccel }
      })

      if (accelBuffer.length >= 7) {
        this.detectStepAdvanced(accelBuffer, gyroBuffer)
      }
    })

    wx.onGyroscopeChange((res) => {
      if (!this.data.isRunning || this.data.isPaused) return

      const rotationSpeed = Math.sqrt(res.x * res.x + res.y * res.y + res.z * res.z)
      
      filteredGyro = alpha * rotationSpeed + (1 - alpha) * filteredGyro
      
      gyroBuffer.push(filteredGyro)
      if (gyroBuffer.length > 15) {
        gyroBuffer.shift()
      }

      this.setData({ 
        lastGyroData: { x: res.x, y: res.y, z: res.z },
        rotationAccumulator: filteredGyro
      })

      if (filteredGyro > 1.5) {
        this.setData({ isTurning: true })
        setTimeout(() => {
          this.setData({ isTurning: false })
        }, 300)
      }
    })

    wx.onCompassChange((res) => {
      this.setData({ 
        heading: res.direction,
        headingAccuracy: res.accuracy 
      })
    })
  },

  detectStepAdvanced(accelBuffer: number[], gyroBuffer: number[]) {
    const currentTime = Date.now()
    const timeSinceLastStep = currentTime - this.data.stepLastPeakTime

    if (timeSinceLastStep < 180) return

    const len = accelBuffer.length
    const current = accelBuffer[len - 1]
    const prev1 = accelBuffer[len - 2]
    const prev2 = accelBuffer[len - 3]
    const next1 = len > 3 ? accelBuffer[len - 4] : current

    const isPeak = current > prev1 && current > prev2 && current > next1
    const isValley = current < prev1 && current < prev2 && current < next1

    const avgGyro = gyroBuffer.length > 0 
      ? gyroBuffer.reduce((a, b) => a + b, 0) / gyroBuffer.length 
      : 0

    const gyroStable = avgGyro < 1.0

    let stepConfidence = 0

    if (isPeak && current > 10.0 && current < 15.0) {
      const peakProminence = current - Math.min(prev1, prev2, next1)
      if (peakProminence > 0.8) {
        stepConfidence = 0.6
        
        if (gyroStable) {
          stepConfidence += 0.2
        }
        
        if (!this.data.isTurning) {
          stepConfidence += 0.2
        }

        if (stepConfidence >= 0.7) {
          this.registerStep(currentTime, current, stepConfidence)
        }
      }
    }
  },

  registerStep(currentTime: number, peakValue: number, confidence: number) {
    // 原始计步只用于室内模式估算距离/识别运动模式；对外展示的“步数”统一由距离换算得出
    const rawSteps = (this.data.rawSteps || 0) + 1
    
    const stepCountWindow = [...this.data.stepCountWindow, currentTime]
    if (stepCountWindow.length > 20) stepCountWindow.shift()

    let avgStepFrequency = 0
    if (stepCountWindow.length >= 2) {
      const timeSpan = stepCountWindow[stepCountWindow.length - 1] - stepCountWindow[0]
      if (timeSpan > 0) {
        avgStepFrequency = ((stepCountWindow.length - 1) / (timeSpan / 1000)) * 60
      }
    }

    const motionMode = this.recognizeMotionMode(avgStepFrequency)
    const stepLength = this.calculateStepLength(motionMode, avgStepFrequency)

    this.setData({
      rawSteps: rawSteps,
      stepLastPeakTime: currentTime,
      stepPeakValue: peakValue,
      stepCountWindow: stepCountWindow,
      stepFrequency: avgStepFrequency,
      avgStepFrequency: avgStepFrequency,
      stepConfidence: confidence,
      motionMode: motionMode,
      stepLength: stepLength
    })

    // GPS 精度较差或室内模式时，用传感器估算距离（步长 * 校准系数）
    if (this.data.indoorMode || this.data.accuracy > 50) {
      const stepDist = stepLength * this.data.distanceCalibration
      const nextTotal = Math.round((this.data.totalMeter + stepDist) * 100) / 100
      this.setData({ totalMeter: nextTotal })
      this.updateStepsByDistance(nextTotal)
    }
  },

  recognizeMotionMode(stepFrequency: number): string {
    if (stepFrequency >= 160 && stepFrequency <= 185) {
      return 'running'
    } else if (stepFrequency >= 130 && stepFrequency < 160) {
      return 'jogging'
    } else if (stepFrequency >= 100 && stepFrequency < 130) {
      return 'walking'
    } else if (stepFrequency >= 70 && stepFrequency < 100) {
      return 'slow_walking'
    }
    return this.data.motionMode || 'unknown'
  },

  calculateStepLength(motionMode: string, stepFrequency: number): number {
    let baseLength = 0.75

    switch (motionMode) {
      case 'running':
        baseLength = 1.0
        break
      case 'jogging':
        baseLength = 0.85
        break
      case 'walking':
        baseLength = 0.7
        break
      case 'slow_walking':
        baseLength = 0.5
        break
      default:
        baseLength = 0.75
    }

    if (stepFrequency > 0) {
      const frequencyFactor = Math.min(1.2, Math.max(0.8, stepFrequency / 140))
      baseLength *= frequencyFactor
    }

    return baseLength
  },

  calculatePace(): number {
    const durationMinutes = this.data.duration / 60
    const distanceKm = this.data.totalMeter / 1000
    
    if (distanceKm <= 0) return 0
    
    return durationMinutes / distanceKm
  },

  calculateRealTimePace(): number {
    const durationMinutes = this.data.duration / 60
    const distanceKm = this.data.totalMeter / 1000
    
    if (distanceKm <= 0.01) return 0
    
    return durationMinutes / distanceKm
  },

  stopSensors() {
    try {
      wx.stopAccelerometer()
      wx.stopGyroscope()
      wx.stopCompass()
    } catch (e) {
      console.log('停止传感器出错:', e)
    }
    this.setData({ sensorInitialized: false })
    console.log('传感器已停止')
  },

  goToRank() {
    wx.navigateTo({ url: '/pages/rank/rank' })
  },

  goToProfile() {
    wx.switchTab({ url: '/pages/profile/profile' })
  },

  setTouchEvents() {
    const page = this
    wx.createSelectorQuery()
      .select('.slide-container')
      .fields({ node: true, size: true })
      .exec((res) => {
        if (res[0] && res[0].node) {
          const slideContainer = res[0].node
          slideContainer.addEventListener('touchstart', (e: any) => {
            page.setData({ touchStartY: e.touches[0].clientY })
          })
          slideContainer.addEventListener('touchmove', (e: any) => {
            if (page.data.isRunning) {
              const touchY = e.touches[0].clientY
              const deltaY = touchY - page.data.touchStartY
              if (deltaY < 0 && page.data.slideOffset > -300) {
                page.setData({ slideOffset: Math.max(-300, page.data.slideOffset + deltaY * 0.5) })
              }
              page.setData({ touchStartY: touchY })
            }
          })
          slideContainer.addEventListener('touchend', () => {
            if (page.data.slideOffset < -150) {
              page.setData({ slideOffset: -300 })
            } else {
              page.setData({ slideOffset: 0 })
            }
          })
        }
      })
  },

  startRun() {
    if (this.data.isGuest) {
      wx.showModal({
        title: '需要授权',
        content: '请先登录授权后才能开始跑步',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({ url: '/pages/login/login' })
          }
        }
      })
      return
    }

    this.clearRunningState()

    this.setData({
      isRunning: true,
      isPaused: false,
      totalMeter: 0,
      path: [],
      pathSegments: [[]],
      currentSegmentIndex: 0,
      polyline: [],
      startTime: Date.now(),
      accumulatedPauseTime: 0,
      pauseTime: 0,
      pace: 0,
      realTimePace: 0,
      duration: 0,
      steps: 0,
      rawSteps: 0,
      slideOffset: 0,
      formattedPace: "--'--''",
      formattedDuration: '00:00',
      stepBuffer: [],
      stepCountWindow: [],
      stepFilteredAcceleration: 9.8,
      motionMode: 'unknown',
      stepFrequency: 0,
      avgStepFrequency: 0,
      indoorMode: false,
      lastLat: null,
      lastLng: null,
      lastLocationTime: 0,
      locationBuffer: [],
      isLocationStable: false,
      consecutiveGoodLocations: 0,
      runId: Date.now().toString(),
      lapTimes: [],
      lastLapDistance: 0,
      accelHistory: [],
      gyroHistory: [],
      stepConfidence: 0
    })

    this.startTimer()
    this.initSensorsOnStart()
    // 尽量保持前台常亮，减少锁屏导致的定位中断/漂移（用户可自行锁屏/系统仍可能限制）
    try { wx.setKeepScreenOn({ keepScreenOn: true }) } catch (e) {}

    wx.getSetting({
      success: (res) => {
        const locationAuth = res.authSetting['scope.userLocation']

        if (locationAuth === false) {
          wx.showModal({
            title: '需要定位权限',
            content: '跑步需要记录您的运动轨迹，请前往设置开启定位权限',
            confirmText: '去设置',
            success: (modalRes) => {
              if (modalRes.confirm) {
                wx.openSetting({
                  success: (settingRes) => {
                    if (settingRes.authSetting['scope.userLocation']) {
                      this.initLocation()
                    } else {
                      this.handleNoLocationPermission()
                    }
                  }
                })
              } else {
                this.handleNoLocationPermission()
              }
            }
          })
        } else {
          wx.authorize({
            scope: 'scope.userLocation',
            success: () => {
              // 尝试申请后台定位权限（不强制，不通过也可继续跑）
              try {
                wx.authorize({
                  scope: 'scope.userLocationBackground',
                  success: () => {},
                  fail: () => {
                    // iOS/部分机型必须用户到设置里手动开启，这里给温和提示即可
                    wx.showToast({ title: '建议开启后台定位', icon: 'none', duration: 1500 })
                  }
                })
              } catch (e) {}

              this.initLocation()
            },
            fail: () => this.handleNoLocationPermission()
          })
        }
      }
    })
  },

  handleNoLocationPermission() {
    this.setData({ indoorMode: true, isPaused: false })
    wx.showToast({
      title: '室内模式已启用',
      icon: 'none',
      duration: 2000
    })
  },

  pauseRun() {
    if (this.data.isPaused) {
      const pauseDuration = Date.now() - this.data.pauseTime
      this.setData({
        isPaused: false,
        accumulatedPauseTime: this.data.accumulatedPauseTime + pauseDuration,
        currentSegmentIndex: this.data.currentSegmentIndex + 1
      })
      
      if (!this.data.pathSegments[this.data.currentSegmentIndex]) {
        const newPathSegments = [...this.data.pathSegments]
        newPathSegments[this.data.currentSegmentIndex] = []
        this.setData({ pathSegments: newPathSegments })
      }
      
      this.initLocation()
      this.resumeSensors()
    } else {
      this.setData({
        isPaused: true,
        pauseTime: Date.now()
      })
      
      if (this.locationListenerActive) {
        wx.stopLocationUpdate()
        this.locationListenerActive = false
      }
      this.pauseSensors()
    }
  },

  pauseSensors() {
    try {
      wx.stopAccelerometer()
      wx.stopGyroscope()
      wx.stopCompass()
    } catch (e) {
      console.log('暂停传感器出错:', e)
    }
    console.log('传感器已暂停')
  },

  resumeSensors() {
    if (!this.data.sensorInitialized) return
    try {
      wx.startAccelerometer({ interval: 'game' })
      wx.startGyroscope({ interval: 'game' })
      wx.startCompass({ interval: 'ui' })
    } catch (e) {
      console.log('恢复传感器出错:', e)
    }
    console.log('传感器已恢复')
  },

  initLocation() {
    wx.startLocationUpdateBackground({
      success: () => {
        this.locationListenerActive = true
        if (!this.data.isPaused) {
          wx.showToast({ title: '定位已开启', icon: 'none', duration: 1500 })
        }
        this.setupLocationListener()
      },
      fail: () => {
        wx.startLocationUpdate({
          success: () => {
            this.locationListenerActive = true
            if (!this.data.isPaused) {
              wx.showToast({ title: '定位已开启', icon: 'none', duration: 1500 })
            }
            this.setupLocationListener()
          },
          fail: () => {
            this.handleNoLocationPermission()
          }
        })
      }
    })
  },

  setupLocationListener() {
    const page = this
    let lastValidLocation: any = null
    let lastValidTime = 0
    let consecutivePoorAccuracy = 0
    let locationHistory: any[] = []

    // 近 5 秒有效速度样本：用于“锁屏/长间隔”时推算合理距离上限，限制漂移
    let speedSamples: Array<{ t: number, d: number, dt: number }> = []

    // 用于识别“折返/瞬移”：A->B->A 形态（多为漂移）
    let prevAcceptedPoint: any = null
    let lastAcceptedPoint: any = null
    let lastAcceptedTime = 0
    let lastIncDistance = 0
    // 漂移补偿：记录上一次“已确认计入里程”的原始步数快照，避免飘移期间里程断档
    let lastRawStepsSnapshot = 0

    // 避免重复注册导致回调叠加/数据异常
    try { wx.offLocationChange() } catch (e) {}

    wx.onLocationChange((res: any) => {
      if (!this.data.isRunning || this.data.isPaused) return

      const now = Date.now()

      if (!res.latitude || !res.longitude || !res.accuracy) return

      const accuracy = res.accuracy

      // 允许更多设备正常累计距离：弱信号时不直接“卡死”，而是降权/过滤
      const POOR_ACCURACY = 80
      const GOOD_ACCURACY = 50

      if (accuracy > POOR_ACCURACY) {
        consecutivePoorAccuracy++
        if (consecutivePoorAccuracy >= 5 && !this.data.indoorMode) {
          this.setData({ indoorMode: true })
          wx.showToast({ title: '信号弱，室内模式', icon: 'none', duration: 1500 })
        }
        return
      }

      consecutivePoorAccuracy = 0
      if (this.data.indoorMode && accuracy < 30) {
        this.setData({ indoorMode: false })
      }

      if (this.data.indoorMode) return

      const currentLocation = {
        latitude: res.latitude,
        longitude: res.longitude,
        accuracy: accuracy,
        speed: res.speed || 0,
        altitude: res.altitude || 0,
        timestamp: now
      }

      locationHistory.push(currentLocation)
      if (locationHistory.length > 10) {
        locationHistory.shift()
      }

      if (locationHistory.length >= 3) {
        const avgAccuracy = locationHistory.reduce((sum, loc) => sum + loc.accuracy, 0) / locationHistory.length
        if (avgAccuracy < this.data.minAccuracy) {
          this.setData({ isLocationStable: true })
        }
      }

      if (lastValidLocation) {
        const timeDiff = (now - lastValidTime) / 1000
        
        if (timeDiff < 0.5) return

        const dis = this.optimizedCalcDistance(
          lastValidLocation.latitude,
          lastValidLocation.longitude,
          currentLocation.latitude,
          currentLocation.longitude
        )

        // ===== 漂移过滤核心：熄屏前 5 秒平均速度推算“合理距离上限” =====
        // 计算近 5 秒平均速度（m/s）
        const windowMs = 5000
        speedSamples = speedSamples.filter(s => now - s.t <= windowMs)
        const sumD = speedSamples.reduce((a, s) => a + s.d, 0)
        const sumDT = speedSamples.reduce((a, s) => a + s.dt, 0)
        let vAvg5s = (sumDT > 0) ? (sumD / sumDT) : 0
        if (!vAvg5s || !isFinite(vAvg5s) || vAvg5s < 0.5) {
          // fallback：用系统给的 speed 或给一个保守跑步速度
          vAvg5s = (lastValidLocation.speed && lastValidLocation.speed > 0) ? lastValidLocation.speed : 2.2
        }

        // 合理距离上限：vAvg5s * dt * 容错系数（锁屏后点间隔变长时非常关键）
        const dMax = Math.max(12, vAvg5s * timeDiff * 1.6)
        const vInst = dis / timeDiff

        // 强漂移：瞬移/超高速/精度差还跳远 -> 直接丢弃，并断开轨迹（不画、不计）
        const HARD_MAX_SPEED = 7.5 // m/s ≈ 27km/h
        const hardJump = (vInst > HARD_MAX_SPEED) || (dis > Math.max(50, dMax * 2)) || (accuracy > 60 && dis > 25)
        if (hardJump) {
          console.log('过滤漂移段:', { dis: dis.toFixed(2), dt: timeDiff.toFixed(2), vInst: vInst.toFixed(2), dMax: dMax.toFixed(2), acc: accuracy })

        // ===== 漂移补偿（用户选择：二者取小）=====
        // 说明：GPS 点被判为漂移不绘制，但用户可能真实在运动。此时用
        // min(计步距离, vAvg5s*dt*1.6) 补偿距离，防止“飘移期间无记录”。
        // 注意：accuracy>50 时 registerStep 已会持续累加距离，这里避免重复补偿。
        if (accuracy <= GOOD_ACCURACY && lastAcceptedTime > 0) {
          const dtSinceAccepted = (now - lastAcceptedTime) / 1000
          const stepsDelta = Math.max(0, (this.data.rawSteps || 0) - lastRawStepsSnapshot)
          const stepDist = stepsDelta * (this.data.stepLength || 0.75) * (this.data.distanceCalibration || 1)
          const speedDist = Math.max(0, vAvg5s * dtSinceAccepted * 1.6)
          const compensate = Math.min(stepDist, speedDist)
          if (compensate > 0.5) {
            const nextTotal = Math.round((this.data.totalMeter + compensate) * 100) / 100
            this.setData({ totalMeter: nextTotal })
            this.updateStepsByDistance(nextTotal)
            // 结算一次补偿后刷新快照，避免重复结算
            lastAcceptedTime = now
            lastRawStepsSnapshot = this.data.rawSteps || 0
          }
        }

          // 断开轨迹：进入新 segment，避免画出一条穿越全图的直线
          const newPathSegments = [...this.data.pathSegments]
          const nextIndex = this.data.currentSegmentIndex + 1
          if (!newPathSegments[nextIndex]) newPathSegments[nextIndex] = []
          this.setData({ pathSegments: newPathSegments, currentSegmentIndex: nextIndex })

          // 更新基准点，避免后续一直拿“过旧点”比较导致永远不累计
          lastValidTime = now
          lastValidLocation = currentLocation
          prevAcceptedPoint = lastAcceptedPoint
          lastAcceptedPoint = null
          lastIncDistance = 0
          speedSamples = []
          return
        }

        // 软漂移：距离超过合理上限（通常是锁屏期间漂移或定位点折返）
        // 轻微超出允许“限幅”，明显超出直接丢弃
        if (dis > dMax) {
          const tooMuch = dis > dMax * 1.2 || dis > 40
          if (tooMuch) {
            console.log('过滤超出合理上限的漂移:', dis.toFixed(2), 'dMax=', dMax.toFixed(2))

            // ===== 漂移补偿（用户选择：二者取小）=====
            if (accuracy <= GOOD_ACCURACY && lastAcceptedTime > 0) {
              const dtSinceAccepted = (now - lastAcceptedTime) / 1000
              const stepsDelta = Math.max(0, (this.data.rawSteps || 0) - lastRawStepsSnapshot)
              const stepDist = stepsDelta * (this.data.stepLength || 0.75) * (this.data.distanceCalibration || 1)
              const speedDist = Math.max(0, vAvg5s * dtSinceAccepted * 1.6)
              const compensate = Math.min(stepDist, speedDist)
              if (compensate > 0.5) {
                const nextTotal = Math.round((this.data.totalMeter + compensate) * 100) / 100
                this.setData({ totalMeter: nextTotal })
                this.updateStepsByDistance(nextTotal)
                lastAcceptedTime = now
                lastRawStepsSnapshot = this.data.rawSteps || 0
              }
            }

            const newPathSegments = [...this.data.pathSegments]
            const nextIndex = this.data.currentSegmentIndex + 1
            if (!newPathSegments[nextIndex]) newPathSegments[nextIndex] = []
            this.setData({ pathSegments: newPathSegments, currentSegmentIndex: nextIndex })

            lastValidTime = now
            lastValidLocation = currentLocation
            speedSamples = []
            return
          }
        }

        const minSpeed = 0.2
        if (dis < 2 && vInst < minSpeed) {
          return
        }

        // 折返漂移判定：A->B->A（多为漂移锯齿）
        if (prevAcceptedPoint && lastAcceptedPoint) {
          const dAB = this.optimizedCalcDistance(prevAcceptedPoint.latitude, prevAcceptedPoint.longitude, lastAcceptedPoint.latitude, lastAcceptedPoint.longitude)
          const dBC = this.optimizedCalcDistance(lastAcceptedPoint.latitude, lastAcceptedPoint.longitude, currentLocation.latitude, currentLocation.longitude)
          const dAC = this.optimizedCalcDistance(prevAcceptedPoint.latitude, prevAcceptedPoint.longitude, currentLocation.latitude, currentLocation.longitude)

          if (dAC < 8 && dAB > 15 && dBC > 15) {
            const v1x = prevAcceptedPoint.latitude - lastAcceptedPoint.latitude
            const v1y = prevAcceptedPoint.longitude - lastAcceptedPoint.longitude
            const v2x = currentLocation.latitude - lastAcceptedPoint.latitude
            const v2y = currentLocation.longitude - lastAcceptedPoint.longitude
            const dot = v1x * v2x + v1y * v2y
            const norm1 = Math.sqrt(v1x * v1x + v1y * v1y)
            const norm2 = Math.sqrt(v2x * v2x + v2y * v2y)
            const cos = (norm1 > 0 && norm2 > 0) ? (dot / (norm1 * norm2)) : 1
            const angle = Math.acos(Math.max(-1, Math.min(1, cos))) * 180 / Math.PI

            if (angle > 150) {
              console.log('识别折返漂移点，剔除中间点')
              // 回退上一次累计距离
              const nextTotal = Math.max(0, Math.round((this.data.totalMeter - lastIncDistance) * 100) / 100)
              this.setData({ totalMeter: nextTotal })
              this.updateStepsByDistance(nextTotal)

              // 删除轨迹中间点（B）
              const seg = this.data.pathSegments[this.data.currentSegmentIndex] || []
              if (seg.length > 0) {
                seg.pop()
                const newSegs = [...this.data.pathSegments]
                newSegs[this.data.currentSegmentIndex] = [...seg]
                this.setData({ pathSegments: newSegs })
              }
              speedSamples.pop()
              // 将 lastValidLocation 回退到 A
              lastValidLocation = prevAcceptedPoint
              lastValidTime = lastAcceptedTime || lastValidTime
              lastAcceptedPoint = prevAcceptedPoint
              lastAcceptedTime = lastValidTime
              prevAcceptedPoint = null
            }
          }
        }

        // 精度降权：50m以内计满，越接近 80m 越接近 0
        const weight = Math.max(0, Math.min(1, (POOR_ACCURACY - accuracy) / (POOR_ACCURACY - GOOD_ACCURACY)))
        // “限幅”：即使点可信，也避免长间隔造成距离被一次性拉爆
        const cappedDis = Math.min(dis, dMax)
        const inc = cappedDis * weight
        const nextTotal = Math.round((this.data.totalMeter + inc) * 100) / 100

        this.setData({ totalMeter: nextTotal })
        this.updateStepsByDistance(nextTotal)

        this.checkLapTime()

        // 记录速度样本（用于下一次熄屏/长间隔推算）
        speedSamples.push({ t: now, d: cappedDis, dt: timeDiff })
        if (speedSamples.length > 20) speedSamples.shift()
        lastIncDistance = inc
      }

      lastValidTime = now
      lastValidLocation = currentLocation
      prevAcceptedPoint = lastAcceptedPoint
      lastAcceptedPoint = currentLocation
      lastAcceptedTime = now
      // 每次“成功落点”后更新步数快照（用于后续漂移补偿）
      lastRawStepsSnapshot = this.data.rawSteps || 0

      const currentSegment = this.data.pathSegments[this.data.currentSegmentIndex] || []
      const newSegmentPoint = {
        latitude: currentLocation.latitude,
        longitude: currentLocation.longitude,
        timestamp: now
      }
      const updatedSegment = [...currentSegment, newSegmentPoint]
      
      const newPathSegments = [...this.data.pathSegments]
      newPathSegments[this.data.currentSegmentIndex] = updatedSegment

      const allPoints: any[] = []
      newPathSegments.forEach((segment) => {
        if (segment && segment.length > 0) {
          allPoints.push(...segment)
        }
      })

      // 用多段 polyline 表示“断点/暂停/漂移剔除”的分段轨迹，避免直线穿越
      const polylines = newPathSegments
        .filter((seg) => seg && seg.length >= 2)
        .map((seg) => ({
          points: seg,
          color: this.data.indoorMode ? "#ff9800" : "#0088ff",
          width: 5
        }))

      this.setData({
        latitude: currentLocation.latitude,
        longitude: currentLocation.longitude,
        accuracy: accuracy,
        speed: currentLocation.speed,
        altitude: currentLocation.altitude,
        markers: [{
          id: 1,
          latitude: currentLocation.latitude,
          longitude: currentLocation.longitude,
          width: 20,
          height: 20
        }],
        path: allPoints,
        pathSegments: newPathSegments,
        polyline: polylines,
        lastLat: currentLocation.latitude,
        lastLng: currentLocation.longitude,
        lastLocationTime: now
      })
    })
  },

  checkLapTime() {
    const currentDistance = this.data.totalMeter
    const lastLap = this.data.lastLapDistance
    const lapDistance = this.data.lapDistance

    if (Math.floor(currentDistance / lapDistance) > Math.floor(lastLap / lapDistance)) {
      const lapTimes = [...this.data.lapTimes, this.data.duration]
      this.setData({ 
        lapTimes: lapTimes,
        lastLapDistance: currentDistance
      })
      console.log('完成第', lapTimes.length, '公里，用时:', this.formatDuration(this.data.duration))
    }
  },

  stopRun() {
    const finalDistance = this.data.totalMeter
    const finalSteps = this.data.steps
    const finalDuration = this.data.duration

    this.setData({ isRunning: false, isPaused: false })
    
    if (this.locationListenerActive) {
      wx.stopLocationUpdate()
      this.locationListenerActive = false
    }
    
    if (this.timer) {
      clearInterval(this.timer)
      this.timer = null
    }

    // 结束后恢复常亮设置
    try { wx.setKeepScreenOn({ keepScreenOn: false }) } catch (e) {}
    
    this.stopSensors()
    this.clearRunningState()
    
    const fusedDistance = this.fusedDistanceCalculation()
    
    if (fusedDistance > 0) {
      this.saveRunData(fusedDistance)
    }

    const hours = Math.floor(finalDuration / 3600)
    const minutes = Math.floor((finalDuration % 3600) / 60)
    const seconds = finalDuration % 60
    const formattedDuration = `${hours > 0 ? hours + '小时' : ''}${minutes}分${seconds}秒`

    const finalPace = fusedDistance > 0 ? this.calculatePace() : 0
    const formattedPace = fusedDistance > 0 ? this.formatPace(finalPace) : '--'

    const avgStepFreq = finalDuration > 0 ? Math.round(finalSteps / (finalDuration / 60)) : 0

    const modeText = this.data.motionMode === 'running' ? '跑步' : 
                     this.data.motionMode === 'jogging' ? '慢跑' : 
                     this.data.motionMode === 'walking' ? '步行' : 
                     this.data.indoorMode ? '室内运动' : '运动'

    wx.showModal({ 
      title: '运动完成', 
      content: `距离：${fusedDistance} 米\n用时：${formattedDuration}\n配速：${formattedPace} 分钟/公里\n步数：${finalSteps} 步\n步频：${avgStepFreq} 步/分钟\n模式：${modeText}`, 
      showCancel: false
    })
  },

  saveRunData(fusedDistance: number) {
    const pace = fusedDistance > 0 ? this.calculatePace() : 0
    const avgStepFreq = this.data.duration > 0 ? Math.round(this.data.steps / (this.data.duration / 60)) : 0
    
    const runRecord = {
      _id: Date.now().toString(),
      distance: fusedDistance,
      time: new Date().toLocaleString('zh-CN'),
      date: new Date().toLocaleDateString('zh-CN'),
      openid: wx.getStorageSync('openid') || 'anonymous',
      nickName: this.data.userInfo ? this.data.userInfo.nickName : '匿名用户',
      avatarUrl: this.data.userInfo ? this.data.userInfo.avatarUrl : '',
      pace: pace,
      duration: this.data.duration,
      steps: this.data.steps,
      stepFrequency: avgStepFreq,
      motionMode: this.data.motionMode,
      lapTimes: this.data.lapTimes
    }

    wx.cloud.callFunction({
      name: 'saveRunData',
      data: runRecord,
      success: (res) => {
        console.log('跑步数据保存成功：', res)
      },
      fail: (err) => {
        console.error('跑步数据保存失败：', err)
        let runList = wx.getStorageSync('runList') || []
        runList.push(runRecord)
        wx.setStorageSync('runList', runList)
      }
    })
  },

  uploadRealtimeData() {
    if (!this.data.isRunning) return
    
    const app = getApp()
    const openid = app.getGlobalOpenId ? app.getGlobalOpenId() : ''
    
    const realtimeData = {
      openid: openid,
      distance: this.data.totalMeter,
      pace: this.calculatePace(),
      duration: this.data.duration,
      steps: this.data.steps,
      stepFrequency: this.data.avgStepFrequency,
      latitude: this.data.latitude,
      longitude: this.data.longitude,
      timestamp: Date.now()
    }
    
    wx.cloud.callFunction({
      name: 'saveRunData',
      data: { ...realtimeData, isRealtime: true }
    })
  },

  async doLogin() {
    wx.showLoading({ title: '登录中...', mask: true })
    
    const app = getApp()
    let openid = app.getGlobalOpenId ? app.getGlobalOpenId() : ''
    
    if (!openid) {
      try {
        if (app.getOpenId) {
          await app.getOpenId()
          openid = app.getGlobalOpenId ? app.getGlobalOpenId() : ''
        }
      } catch (err) {
        console.error('获取 openid 失败:', err)
      }
    }
    
    if (openid) {
      wx.setStorageSync('openid', openid)
      
      const userInfo = wx.getStorageSync('userInfo')
      wx.hideLoading()
      wx.showToast({ title: '登录成功', icon: 'success' })
      this.setData({
        userInfo: userInfo,
        isLoggedIn: true,
        isGuest: false
      })
    } else {
      wx.hideLoading()
      wx.showToast({ title: '登录失败，请重试', icon: 'none' })
    }
  },

  formatPace(pace: number): string {
    if (!pace || pace <= 0 || !isFinite(pace)) return "--'--''"
    const minutes = Math.floor(pace)
    const seconds = Math.floor((pace - minutes) * 60)
    return `${minutes.toString().padStart(2, '0')}'${seconds.toString().padStart(2, '0')}''`
  },

  formatDuration(seconds: number): string {
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`
  },

  optimizedCalcDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
    const R = 6378137
    const radLat1 = lat1 * Math.PI / 180
    const radLat2 = lat2 * Math.PI / 180
    const a = radLat1 - radLat2
    const b = (lng1 - lng2) * Math.PI / 180
    const s = 2 * R * Math.asin(
      Math.sqrt(
        Math.pow(Math.sin(a/2), 2) + Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(Math.sin(b/2), 2)
      )
    )
    return s
  },

  /**
   * 基于“距离”统一换算步数，避免传感器计步误差导致步数异常/不同步。
   * 约定：stepLength 单位为米，distanceCalibration 为系数（默认 1.0）。
   */
  updateStepsByDistance(distanceMeter: number) {
    const stepLen = (this.data.stepLength || 0.75) * (this.data.distanceCalibration || 1)
    if (!stepLen || stepLen <= 0) return

    const steps = Math.max(0, Math.round(distanceMeter / stepLen))
    const avgStepFreq = this.data.duration > 0 ? Math.round(steps / (this.data.duration / 60)) : 0

    this.setData({
      steps,
      avgStepFrequency: avgStepFreq
    })
  },
  
  fusedDistanceCalculation(): number {
    const stepBasedDistance = this.data.steps * this.data.stepLength * this.data.distanceCalibration
    const gpsBasedDistance = this.data.totalMeter
    
    let fusedDistance = 0
    if (this.data.path.length >= 2 && !this.data.indoorMode) {
      fusedDistance = gpsBasedDistance * 0.7 + stepBasedDistance * 0.3
    } else {
      fusedDistance = stepBasedDistance
    }
    
    return Math.round(fusedDistance)
  },

  showSearch() {
    this.setData({ showSearchModal: true, searchKeyword: '', searchResults: [] })
  },
  
  closeSearch() {
    this.setData({ showSearchModal: false })
  },
  
  onSearchInput(e: any) {
    this.setData({ searchKeyword: e.detail.value })
  },
  
  searchFriends() {
    const keyword = this.data.searchKeyword.trim()
    if (!keyword) {
      wx.showToast({ title: '请输入搜索关键词', icon: 'none' })
      return
    }
    
    this.setData({ isSearching: true, searchResults: [] })
    
    wx.cloud.callFunction({
      name: 'getFriends',
      data: { action: 'search', keyword },
      success: (res: any) => {
        this.setData({ 
          searchResults: res.result || [],
          isSearching: false,
          hasSearched: true
        })
      },
      fail: () => {
        this.setData({ isSearching: false, hasSearched: true })
        wx.showToast({ title: '搜索失败', icon: 'none' })
      }
    })
  },
  
  addFriend(e: any) {
    const friendOpenid = e.currentTarget.dataset.openid
    const app = getApp()
    const currentOpenid = app.getGlobalOpenId ? app.getGlobalOpenId() : ''
    
    if (friendOpenid === currentOpenid) {
      wx.showToast({ title: '不能添加自己', icon: 'none' })
      return
    }
    
    wx.cloud.callFunction({
      name: 'getFriends',
      data: { action: 'add', friendOpenid },
      success: () => {
        wx.showToast({ title: '添加成功', icon: 'success' })
        this.searchFriends()
      },
      fail: () => {
        wx.showToast({ title: '添加失败', icon: 'none' })
      }
    })
  },
  
  showTeamModal() {
    this.setData({ showTeamModal: true, selectedFriends: [] })
    this.loadFriendsList()
  },
  
  closeTeamModal() {
    this.setData({ showTeamModal: false, selectedFriends: [] })
  },
  
  loadFriendsList() {
    wx.cloud.callFunction({
      name: 'getFriends',
      data: { action: 'list' },
      success: (res: any) => {
        this.setData({ friendsList: res.result || [] })
      },
      fail: () => {
        wx.showToast({ title: '获取好友列表失败', icon: 'none' })
      }
    })
  },
  
  toggleFriendSelection(e: any) {
    const openid = e.currentTarget.dataset.openid
    if (!openid) return
    
    const selectedFriends = [...this.data.selectedFriends]
    const friendIndex = selectedFriends.indexOf(openid)
    
    if (friendIndex === -1) {
      selectedFriends.push(openid)
    } else {
      selectedFriends.splice(friendIndex, 1)
    }
    
    this.setData({ selectedFriends })
  },
  
  createTeam() {
    if (this.data.selectedFriends.length === 0) {
      wx.showToast({ title: '请选择好友', icon: 'none' })
      return
    }
    
    wx.cloud.callFunction({
      name: 'teamManager',
      data: {
        action: 'create',
        members: this.data.selectedFriends,
        teamType: this.data.selectedFriends.length === 1 ? 'couple' : 'team'
      },
      success: (res: any) => {
        this.setData({
          currentTeam: res.result,
          showTeamModal: false
        })
        wx.showToast({ title: '组队成功', icon: 'success' })
      },
      fail: () => {
        wx.showToast({ title: '组队失败', icon: 'none' })
      }
    })
  },

  onUnload() {
    if (this.data.isRunning) {
      this.stopRun()
    }
  },

  onHide() {
    if (this.data.isRunning && !this.data.isPaused) {
      this.saveRunningState()
    }
  },

  saveRunningState() {
    const app = getApp()
    if (app.globalData) {
      app.globalData.runningState = {
        runId: this.data.runId,
        isRunning: this.data.isRunning,
        isPaused: this.data.isPaused,
        startTime: this.data.startTime,
        accumulatedPauseTime: this.data.accumulatedPauseTime,
        totalMeter: this.data.totalMeter,
        steps: this.data.steps,
        path: this.data.path,
        pathSegments: this.data.pathSegments,
        currentSegmentIndex: this.data.currentSegmentIndex,
        pauseTime: this.data.pauseTime,
        motionMode: this.data.motionMode,
        stepLength: this.data.stepLength,
        stepCountWindow: this.data.stepCountWindow,
        avgStepFrequency: this.data.avgStepFrequency
      }
    }
  },

  startTimer() {
    if (this.timer) {
      clearInterval(this.timer)
    }
    
    this.timer = setInterval(() => {
      if (this.data.isRunning && !this.data.isPaused) {
        const duration = Math.floor((Date.now() - this.data.startTime - this.data.accumulatedPauseTime) / 1000)
        this.setData({ duration })

        const formattedDuration = this.formatDuration(duration)
        this.setData({ formattedDuration })

        if (this.data.totalMeter > 100) {
          const pace = this.calculatePace()
          this.setData({ pace, realTimePace: pace })
          const formattedPace = this.formatPace(pace)
          this.setData({ formattedPace })
        }

        if (duration % 10 === 0) {
          this.uploadRealtimeData()
          this.saveRunningState()
        }
      }
    }, 1000)
  }
})
