Page({
  data: {
    results: [] as string[],
    loading: false
  },

  addLog(msg: string) {
    const results = this.data.results
    results.unshift('[' + new Date().toLocaleTimeString() + '] ' + msg)
    this.setData({ results })
  },

  async testInitDatabase() {
    this.addLog('初始化数据库集合...')
    this.setData({ loading: true })
    try {
      const res: any = await wx.cloud.callFunction({
        name: 'globalAdmin',
        data: { action: 'initDatabase' }
      })
      console.log('initDatabase result:', res)
      if (res.result && res.result.code === 0) {
        this.addLog('数据库初始化完成')
        const results = (res.result.data && res.result.data.results) ? res.result.data.results : []
        for (let i = 0; i < results.length; i++) {
          const item = results[i]
          this.addLog('集合 ' + item.name + ': ' + item.status)
        }
      } else {
        const msg = (res.result && res.result.message) || '未知错误'
        this.addLog('初始化失败: ' + msg)
      }
    } catch (err: any) {
      console.error('initDatabase error:', err)
      this.addLog('初始化异常: ' + (err.message || err.errMsg || JSON.stringify(err)))
    }
    this.setData({ loading: false })
  },

  async testCloudInit() {
    this.addLog('测试云开发初始化...')
    try {
      wx.cloud.init({
        env: 'cloudbase-8gy1i7h07bd9a58c'
      })
      this.addLog('云开发初始化成功')
    } catch (err: any) {
      this.addLog('云开发初始化失败: ' + (err.message || JSON.stringify(err)))
    }
  },

  async testGetOpenId() {
    this.addLog('测试获取 openid...')
    this.setData({ loading: true })
    try {
      const res: any = await wx.cloud.callFunction({
        name: 'login'
      })
      console.log('getOpenId result:', res)
      if (res.result && res.result.openid) {
        this.addLog('openid: ' + res.result.openid)
      } else {
        const msg = (res.result && res.result.errMsg) || '未知错误'
        this.addLog('获取失败: ' + msg)
      }
    } catch (err: any) {
      console.error('getOpenId error:', err)
      this.addLog('获取异常: ' + (err.message || err.errMsg || JSON.stringify(err)))
    }
    this.setData({ loading: false })
  },

  async testGetShopList() {
    this.addLog('测试获取商家列表...')
    this.setData({ loading: true })
    try {
      const res: any = await wx.cloud.callFunction({
        name: 'globalAdmin',
        data: { action: 'getShopManageList', data: { keyword: '' } }
      })
      console.log('getShopList result:', res)
      if (res.result && res.result.code === 0) {
        const list = (res.result.data && res.result.data.list) ? res.result.data.list : []
        this.addLog('获取成功，共 ' + list.length + ' 家店铺')
        for (let i = 0; i < list.length; i++) {
          this.addLog('店铺: ' + list[i].name)
        }
      } else {
        const msg = (res.result && res.result.message) || '未知错误'
        this.addLog('获取失败: ' + msg)
      }
    } catch (err: any) {
      console.error('getShopList error:', err)
      this.addLog('获取异常: ' + (err.message || err.errMsg || JSON.stringify(err)))
    }
    this.setData({ loading: false })
  },

  async testCreateShop() {
    this.addLog('创建测试商家...')
    this.setData({ loading: true })
    try {
      const res: any = await wx.cloud.callFunction({
        name: 'globalAdmin',
        data: { action: 'initTestData' }
      })
      console.log('initTestData result:', res)
      if (res.result && res.result.code === 0) {
        const d = res.result.data || {}
        this.addLog('创建成功: ' + d.shopName)
        this.addLog('店铺ID: ' + d.shopId)
        this.addLog('登录账号: ' + d.loginInfo.username)
        this.addLog('登录密码: ' + d.loginInfo.password)
      } else {
        const msg = (res.result && res.result.message) || '未知错误'
        this.addLog('创建失败: ' + msg)
      }
    } catch (err: any) {
      console.error('initTestData error:', err)
      this.addLog('创建异常: ' + (err.message || err.errMsg || JSON.stringify(err)))
    }
    this.setData({ loading: false })
  },

  async testUploadImage() {
    this.addLog('测试图片上传...')
    try {
      const chooseRes: any = await wx.chooseMedia({
        count: 1,
        mediaType: ['image'],
        sourceType: ['album']
      })
      
      const tempFilePath = chooseRes.tempFiles[0].tempFilePath
      this.addLog('已选择图片')
      
      const cloudPath = 'test/' + Date.now() + '.jpg'
      const uploadRes: any = await wx.cloud.uploadFile({
        cloudPath: cloudPath,
        filePath: tempFilePath
      })
      
      this.addLog('上传成功: ' + uploadRes.fileID)
    } catch (err: any) {
      this.addLog('上传失败: ' + (err.message || err.errMsg || JSON.stringify(err)))
    }
  },

  clearLogs() {
    this.setData({ results: [] })
  }
})
