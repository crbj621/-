Page({
  data: {
    username: '',
    password: '',
    loading: false
  },

  onUsernameInput(e) {
    this.setData({ username: e.detail.value })
  },

  onPasswordInput(e) {
    this.setData({ password: e.detail.value })
  },

  async onLogin() {
    var username = this.data.username.trim()
    var password = this.data.password.trim()
    
    if (!username) {
      wx.showToast({ title: '请输入账号', icon: 'none' })
      return
    }
    
    if (!password) {
      wx.showToast({ title: '请输入密码', icon: 'none' })
      return
    }

    this.setData({ loading: true })

    try {
      console.log('开始登录, 账号:', username)

      // 统一走 globalAdmin：避免点餐/论坛/跑步等多个后台各自维护账号体系
      var res = await wx.cloud.callFunction({
        name: 'globalAdmin',
        data: {
          action: 'login',
          data: {
            account: username,
            password: password
          }
        }
      }) as any

      console.log('登录返回结果:', JSON.stringify(res))
      this.setData({ loading: false })

      if (res.result && res.result.code === 0) {
        wx.setStorageSync('isAdmin', true)
        wx.setStorageSync('adminInfo', res.result.data && res.result.data.admin ? res.result.data.admin : {})
        wx.showToast({ title: '登录成功', icon: 'success' })
        setTimeout(function() {
          wx.redirectTo({
            url: '/pages/admin/index/index'
          })
        }, 1000)
      } else {
        var msg = '登录失败'
        if (res.result && res.result.message) {
          msg = res.result.message
        }
        wx.showToast({ title: msg, icon: 'none', duration: 2000 })
      }
    } catch (err) {
      this.setData({ loading: false })
      console.error('登录异常:', err)
      wx.showToast({ title: '登录失败: ' + (err.errMsg || '网络错误'), icon: 'none', duration: 2000 })
    }
  }
})
