Page({
  data: {
    list: [] as any[],
    keyword: '',
    loading: true,
    selectedIds: [] as string[],
    selectAll: false
  },

  onLoad() {
    this.loadList()
  },

  onPullDownRefresh() {
    this.loadList().then(() => {
      wx.stopPullDownRefresh()
    })
  },

  async loadList() {
    this.setData({ loading: true })
    try {
      const res = await wx.cloud.callFunction({
        name: 'globalAdmin',
        data: {
          action: 'getRankList',
          data: { keyword: this.data.keyword }
        }
      }) as any

      if (res.result && res.result.code === 0) {
        this.setData({
          list: (res.result.data && res.result.data.list) ? res.result.data.list : [],
          loading: false
        })
      }
    } catch (err) {
      console.error(err)
      wx.showToast({ title: '加载失败', icon: 'none' })
      this.setData({ loading: false })
    }
  },

  onSearchInput(e: any) {
    this.setData({ keyword: e.detail.value })
  },

  onSearch() {
    this.loadList()
  },

  toggleSelectAll() {
    const { list, selectAll } = this.data
    if (selectAll) {
      this.setData({ selectedIds: [], selectAll: false })
    } else {
      const allIds = list.map((item: any) => item._id)
      this.setData({ selectedIds: allIds, selectAll: true })
    }
  },

  toggleSelect(e: any) {
    const id = e.currentTarget.dataset.id
    const { selectedIds } = this.data
    const index = selectedIds.indexOf(id)
    
    if (index > -1) {
      selectedIds.splice(index, 1)
    } else {
      selectedIds.push(id)
    }
    
    this.setData({
      selectedIds,
      selectAll: selectedIds.length === this.data.list.length
    })
  },

  clearSingle(e: any) {
    const id = e.currentTarget.dataset.id
    wx.showModal({
      title: '确认删除',
      content: '确定要删除该排行榜记录吗？此操作将写入日志。',
      success: async (res) => {
        if (res.confirm) {
          await this.doClear([id])
        }
      }
    })
  },

  clearSelected() {
    const { selectedIds } = this.data
    if (selectedIds.length === 0) {
      wx.showToast({ title: '请先选择记录', icon: 'none' })
      return
    }

    wx.showModal({
      title: '批量删除',
      content: `确定要删除选中的 ${selectedIds.length} 条记录吗？此操作将写入日志。`,
      success: async (res) => {
        if (res.confirm) {
          await this.doClear(selectedIds)
        }
      }
    })
  },

  async doClear(ids: string[]) {
    wx.showLoading({ title: '删除中...' })
    try {
      const res = await wx.cloud.callFunction({
        name: 'globalAdmin',
        data: {
          action: 'clearRankRecords',
          data: { ids }
        }
      }) as any

      wx.hideLoading()
      
      if (res.result && res.result.code === 0) {
        wx.showToast({ title: '删除成功', icon: 'success' })
        this.setData({ selectedIds: [], selectAll: false })
        this.loadList()
      } else {
        wx.showToast({ title: (res.result && res.result.message) ? res.result.message : '删除失败', icon: 'none' })
      }
    } catch (err) {
      wx.hideLoading()
      wx.showToast({ title: '删除失败', icon: 'none' })
    }
  }
})
