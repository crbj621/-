Page({
  data: {
    loading: false,
    result: null as any,
    shopList: [] as any[]
  },

  onLoad() {
    this.loadShopList()
  },

  async loadShopList() {
    try {
      const res = await wx.cloud.callFunction({
        name: 'globalAdmin',
        data: { action: 'getShopManageList', data: {} }
      }) as any

      if (res.result && res.result.code === 0) {
        this.setData({ shopList: (res.result.data && res.result.data.list) ? res.result.data.list : [] })
      }
    } catch (err) {
      console.error(err)
    }
  },

  async initTestShop() {
    this.setData({ loading: true })

    try {
      const res = await wx.cloud.callFunction({
        name: 'globalAdmin',
        data: { action: 'initTestData' }
      }) as any

      this.setData({ 
        loading: false,
        result: res.result
      })

      if (res.result && res.result.code === 0) {
        const d = res.result.data || {}
        this.loadShopList()
        wx.showModal({
          title: '创建成功',
          content: `店铺: ${d.shopName}\n账号: ${d.loginInfo.username}\n密码: ${d.loginInfo.password}`,
          showCancel: false
        })
      } else {
        wx.showToast({ title: (res.result && res.result.message) ? res.result.message : '创建失败', icon: 'none' })
      }
    } catch (err: any) {
      this.setData({ loading: false })
      wx.showToast({ title: err.message || '请求失败', icon: 'none' })
    }
  },

  goToShopLogin() {
    wx.navigateTo({
      url: '/packageFood/pages/shop_login/shop_login'
    })
  },

  goToFoodIndex() {
    wx.navigateTo({
      url: '/packageFood/pages/index/index'
    })
  }
})
