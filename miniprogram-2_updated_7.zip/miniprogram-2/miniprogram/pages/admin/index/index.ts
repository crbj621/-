Page({
  data: {
    adminInfo: null as any,
    stats: {
      pendingShops: 0,
      orderCount: 0,
      runCount: 0,
      postCount: 0
    },

    // 系统设置弹窗（global_settings）
    showSettingsModal: false,
    settingsLoading: false,
    settingsForm: {
      appName: '',
      themeColor: '#667eea',
      contactPhone: '',
      modules: {
        running: { enabled: true, name: '校园跑' },
        food: { enabled: true, name: '食堂点餐' },
        forum: { enabled: true, name: '校园论坛' },
        rider: { enabled: true, name: '骑手兼职' }
      }
    } as any
  },

  onLoad() {
    this.checkAdmin()
  },

  onShow() {
    if (wx.getStorageSync('isAdmin')) {
      this.loadStats()
    }
  },

  checkAdmin() {
    const isAdmin = wx.getStorageSync('isAdmin')
    if (!isAdmin) {
      wx.redirectTo({
        url: '/pages/admin/login/login'
      })
      return
    }
    const adminInfo = wx.getStorageSync('adminInfo')
    this.setData({ adminInfo })
  },

  async loadStats() {
    try {
      const res = await wx.cloud.callFunction({
        name: 'globalAdmin',
        data: { action: 'getDashboardStats' }
      }) as any

      if (res.result && res.result.code === 0) {
        const d = res.result.data || {}
        this.setData({
          stats: {
            pendingShops: d.pendingShops || 0,
            orderCount: d.orderCount || 0,
            runCount: d.runCount || 0,
            postCount: d.postCount || 0
          }
        })
      }
    } catch (err) {
      console.error(err)
    }
  },

  goToRankManage() {
    wx.navigateTo({
      url: '/pages/admin/rank/rank'
    })
  },

  goToShopAudit() {
    wx.navigateTo({
      url: '/pages/admin/audit/audit'
    })
  },

  goToShopManage() {
    wx.navigateTo({
      url: '/pages/admin/shops/shops'
    })
  },

  goToInit() {
    wx.navigateTo({
      url: '/pages/admin/init/init'
    })
  },

  goToTest() {
    wx.navigateTo({
      url: '/pages/admin/test/test'
    })
  },

  goToForumPosts() {
    wx.navigateTo({
      url: '/packageForum/pages/admin_posts/admin_posts'
    })
  },

  goToForumReports() {
    wx.navigateTo({
      url: '/packageForum/pages/admin_reports/admin_reports'
    })
  },

  goToForumUsers() {
    wx.navigateTo({
      url: '/packageForum/pages/admin_users/admin_users'
    })
  },

  goToForumLogs() {
    wx.navigateTo({
      url: '/packageForum/pages/admin_logs/admin_logs'
    })
  },

  goToAnnouncements() {
    wx.navigateTo({ url: '/pages/admin/announcements/announcements' })
  },

  goToAdminManage() {
    wx.navigateTo({ url: '/pages/admin/admins/admins' })
  },

  goToOperationLogs() {
    wx.navigateTo({ url: '/pages/admin/oplogs/oplogs' })
  },

  openSettings() {
    this.setData({ showSettingsModal: true })
    this.loadSettings()
  },

  closeSettings() {
    this.setData({ showSettingsModal: false })
  },

  async loadSettings() {
    this.setData({ settingsLoading: true })
    try {
      const res = await wx.cloud.callFunction({
        name: 'globalAdmin',
        data: { action: 'getGlobalSettings' }
      }) as any

      if (res.result && res.result.code === 0) {
        const d = res.result.data || {}
        this.setData({
          settingsForm: {
            appName: d.appName || '智慧校园',
            themeColor: d.themeColor || '#667eea',
            contactPhone: d.contactPhone || '',
            modules: d.modules || this.data.settingsForm.modules
          }
        })
      } else {
        wx.showToast({ title: (res.result && res.result.message) ? res.result.message : '获取设置失败', icon: 'none' })
      }
    } catch (e) {
      wx.showToast({ title: '获取设置失败', icon: 'none' })
    } finally {
      this.setData({ settingsLoading: false })
    }
  },

  onSettingsInput(e: any) {
    const field = e.currentTarget.dataset.field
    this.setData({ [`settingsForm.${field}`]: e.detail.value })
  },

  toggleModule(e: any) {
    const key = e.currentTarget.dataset.key
    const enabled = e.detail.value
    this.setData({ [`settingsForm.modules.${key}.enabled`]: enabled })
  },

  async saveSettings() {
    wx.showLoading({ title: '保存中...' })
    try {
      const res = await wx.cloud.callFunction({
        name: 'globalAdmin',
        data: { action: 'updateGlobalSettings', data: this.data.settingsForm }
      }) as any

      wx.hideLoading()
      if (res.result && res.result.code === 0) {
        wx.showToast({ title: '保存成功', icon: 'success' })
        this.closeSettings()
      } else {
        wx.showToast({ title: (res.result && res.result.message) ? res.result.message : '保存失败', icon: 'none' })
      }
    } catch (e) {
      wx.hideLoading()
      wx.showToast({ title: '保存失败', icon: 'none' })
    }
  },

  async goToInitDatabase() {
    wx.showModal({
      title: '初始化数据库集合',
      content: '确定要初始化数据库集合吗？（已存在的集合会自动跳过）',
      success: async (res) => {
        if (res.confirm) {
          wx.showLoading({ title: '初始化中...', mask: true })
          try {
            const result = await wx.cloud.callFunction({
              name: 'globalAdmin',
              data: { action: 'initDatabase' }
            }) as any

            wx.hideLoading()
            if (result.result && result.result.code === 0) {
              const list = (result.result.data && result.result.data.results) ? result.result.data.results : []
              wx.showModal({
                title: '初始化成功',
                content: '数据库集合初始化已完成。\n\n' + (list.length ? ('结果：' + list.map((i: any) => `${i.name}:${i.status}`).join('，')) : ''),
                showCancel: false
              })
            } else {
              wx.showToast({ title: (result.result && result.result.message) ? result.result.message : '初始化失败', icon: 'none' })
            }
          } catch (err) {
            wx.hideLoading()
            wx.showToast({ title: '初始化失败', icon: 'none' })
          }
        }
      }
    })
  },

  logout() {
    wx.showModal({
      title: '退出登录',
      content: '确定要退出管理员账号吗？',
      success: (res) => {
        if (res.confirm) {
          wx.removeStorageSync('isAdmin')
          wx.removeStorageSync('adminInfo')
          wx.redirectTo({
            url: '/pages/admin/login/login'
          })
        }
      }
    })
  }
})
