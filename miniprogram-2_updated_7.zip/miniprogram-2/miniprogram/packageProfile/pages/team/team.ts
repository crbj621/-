Page({
  data: {
    hasTeam: false,
    teamInfo: null as any,
    members: [] as any[],
    isLeader: false,
    createModalVisible: false,
    joinModalVisible: false,
    newTeamName: '',
    inviteCode: '',
    inviteCodeExpire: 0,
    expireText: ''
  },

  onLoad() {
    this.loadTeamInfo()
  },

  onShow() {
    if (this.data.hasTeam && this.data.inviteCodeExpire) {
      this.updateExpireText()
    }
  },

  updateExpireText() {
    const now = Date.now()
    const remain = this.data.inviteCodeExpire - now
    if (remain <= 0) {
      this.setData({ expireText: '已过期' })
    } else {
      const minutes = Math.floor(remain / 60000)
      const seconds = Math.floor((remain % 60000) / 1000)
      this.setData({ 
        expireText: minutes + '分' + seconds + '秒后过期' 
      })
    }
  },

  async loadTeamInfo() {
    wx.showLoading({ title: '加载中...' })
    try {
      const res = await wx.cloud.callFunction({
        name: 'teamManager',
        data: { action: 'getMyTeam' }
      })

      const result = res.result as any
      if (result.success && result.data) {
        const openid = wx.getStorageSync('openid')
        const teamData = result.data
        this.setData({
          hasTeam: true,
          teamInfo: teamData,
          isLeader: teamData.leaderOpenid === openid,
          inviteCode: teamData.inviteCode || '',
          inviteCodeExpire: teamData.inviteCodeExpire || 0,
          members: []
        })
        this.updateExpireText()
        if (teamData.members && teamData.members.length > 0) {
          this.loadMemberDetails(teamData.members)
        }
      } else {
        this.setData({ hasTeam: false })
      }
    } catch (e) {
      console.error(e)
    } finally {
      wx.hideLoading()
    }
  },

  async loadMemberDetails(memberOpenids: string[]) {
    const members = memberOpenids.map(function(id) {
      return {
        openid: id,
        nickName: '成员' + id.substring(0, 4),
        avatarUrl: '/images/default-avatar.png'
      }
    })
    this.setData({ members })
  },

  showCreateModal() {
    this.setData({ createModalVisible: true })
  },

  hideCreateModal() {
    this.setData({ createModalVisible: false, newTeamName: '' })
  },

  onTeamNameInput(e: any) {
    this.setData({ newTeamName: e.detail.value })
  },

  async createTeam() {
    wx.showLoading({ title: '创建中...' })
    try {
      const res = await wx.cloud.callFunction({
        name: 'teamManager',
        data: {
          action: 'create',
          teamName: this.data.newTeamName || '我的跑团'
        }
      })

      const result = res.result as any
      if (result.success) {
        wx.hideLoading()
        wx.showModal({
          title: '创建成功',
          content: '邀请码: ' + result.inviteCode + '\n有效期10分钟，请分享给好友',
          showCancel: false,
          success: () => {
            this.hideCreateModal()
            this.loadTeamInfo()
          }
        })
      } else {
        wx.showToast({ title: result.errMsg, icon: 'none' })
      }
    } catch (e) {
      console.error(e)
      wx.showToast({ title: '创建失败', icon: 'none' })
    } finally {
      wx.hideLoading()
    }
  },

  showJoinModal() {
    this.setData({ joinModalVisible: true })
  },

  hideJoinModal() {
    this.setData({ joinModalVisible: false, inviteCode: '' })
  },

  onInviteCodeInput(e: any) {
    this.setData({ inviteCode: e.detail.value })
  },

  async joinTeam() {
    if (!this.data.inviteCode || this.data.inviteCode.length !== 3) {
      wx.showToast({ title: '请输入3位邀请码', icon: 'none' })
      return
    }

    wx.showLoading({ title: '加入中...' })
    try {
      const res = await wx.cloud.callFunction({
        name: 'teamManager',
        data: {
          action: 'joinTeam',
          inviteCode: this.data.inviteCode
        }
      })

      const result = res.result as any
      if (result.success) {
        wx.showToast({ title: '加入成功', icon: 'success' })
        this.hideJoinModal()
        this.loadTeamInfo()
      } else {
        wx.showToast({ title: result.errMsg, icon: 'none' })
      }
    } catch (e) {
      console.error(e)
      wx.showToast({ title: '加入失败', icon: 'none' })
    } finally {
      wx.hideLoading()
    }
  },

  async refreshCode() {
    wx.showLoading({ title: '刷新中...' })
    try {
      const res = await wx.cloud.callFunction({
        name: 'teamManager',
        data: {
          action: 'refreshCode',
          teamId: this.data.teamInfo._id
        }
      })

      const result = res.result as any
      if (result.success) {
        this.setData({
          inviteCode: result.inviteCode,
          inviteCodeExpire: result.inviteCodeExpire
        })
        this.updateExpireText()
        wx.showToast({ title: '已刷新', icon: 'success' })
      } else {
        wx.showToast({ title: result.errMsg, icon: 'none' })
      }
    } catch (e) {
      console.error(e)
      wx.showToast({ title: '刷新失败', icon: 'none' })
    } finally {
      wx.hideLoading()
    }
  },

  copyInviteCode() {
    wx.setClipboardData({
      data: '邀请码: ' + this.data.inviteCode + '，10分钟内有效，快来加入我的跑团吧！',
      success: () => {
        wx.showToast({ title: '已复制', icon: 'success' })
      }
    })
  },

  async leaveTeam() {
    const content = this.data.isLeader ? '确定要解散队伍吗？' : '确定要退出队伍吗？'
    wx.showModal({
      title: '提示',
      content: content,
      success: async (res) => {
        if (res.confirm) {
          wx.showLoading({ title: '处理中...' })
          try {
            const res = await wx.cloud.callFunction({
              name: 'teamManager',
              data: {
                action: 'leaveTeam',
                teamId: this.data.teamInfo._id
              }
            })

            const result = res.result as any
            if (result.success) {
              wx.showToast({ title: result.msg, icon: 'success' })
              this.loadTeamInfo()
            } else {
              wx.showToast({ title: result.errMsg, icon: 'none' })
            }
          } catch (e) {
            console.error(e)
          } finally {
            wx.hideLoading()
          }
        }
      }
    })
  }
})
