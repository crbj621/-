Page({
  data: {
    settings: {
      highAccuracy: true,
      autoSave: true,
      notifications: true
    }
  },

  onLoad() {
    // 检查登录状态
    const userInfo = wx.getStorageSync('userInfo');
    const openid = wx.getStorageSync('openid');
    if (!userInfo || !openid) {
      // 未登录，跳转到登录页面
      wx.redirectTo({
        url: '/pages/login/login'
      });
      return;
    }
    this.loadSettings();
  },

  // 加载设置
  loadSettings() {
    const savedSettings = wx.getStorageSync('settings') || this.data.settings;
    this.setData({ settings: savedSettings });
  },

  // 保存设置
  saveSettings() {
    wx.setStorageSync('settings', this.data.settings);
    wx.showToast({ title: '设置已保存', icon: 'success' });
  },

  // 切换高精度定位
  toggleHighAccuracy(e: any) {
    const highAccuracy = e.detail.value;
    this.setData({
      'settings.highAccuracy': highAccuracy
    });
    this.saveSettings();
  },

  // 切换自动保存
  toggleAutoSave(e: any) {
    const autoSave = e.detail.value;
    this.setData({
      'settings.autoSave': autoSave
    });
    this.saveSettings();
  },

  // 切换通知
  toggleNotifications(e: any) {
    const notifications = e.detail.value;
    this.setData({
      'settings.notifications': notifications
    });
    this.saveSettings();
  },

  // 清除缓存
  clearCache() {
    wx.showModal({
      title: '确认清除',
      content: '确定要清除缓存吗？',
      success: (res) => {
        if (res.confirm) {
          wx.clearStorageSync();
          wx.showToast({ title: '缓存已清除', icon: 'success' });
        }
      }
    });
  },

  // 关于我们
  aboutUs() {
    wx.showModal({
      title: '关于校园跑',
      content: '宠辱不惊爱死你了。\n\n版本：1.0.0',
      showCancel: false
    });
  }
});