Page({
  data: {
    runList: [] as any[],
    isEmpty: true
  },

  onLoad() {
    // 检查登录状态
    const userInfo = wx.getStorageSync('userInfo');
    const openid = wx.getStorageSync('openid');
    if (!userInfo || !openid) {
      // 未登录，跳转到登录页面
      wx.redirectTo({
        url: '/pages/login/login'
      });
      return;
    }
    this.loadRunHistory();
  },

  onShow() {
    this.loadRunHistory();
  },

  // 加载跑步历史记录
  loadRunHistory() {
    const runList = wx.getStorageSync('runList') || [];
    // 按时间倒序排序
    runList.sort((a: any, b: any) => b.id - a.id);
    this.setData({
      runList,
      isEmpty: runList.length === 0
    });
  },

  // 清空所有记录
  clearAllRecords() {
    wx.showModal({
      title: '确认清空',
      content: '确定要清空所有跑步记录吗？此操作不可恢复',
      success: (res) => {
        if (res.confirm) {
          wx.removeStorageSync('runList');
          this.setData({ runList: [], isEmpty: true });
          wx.showToast({ title: '已清空所有记录', icon: 'success' });
        }
      }
    });
  },

  // 分享功能
  onShareAppMessage() {
    return {
      title: '我的跑步记录',
      path: '/pages/history/history',
      imageUrl: ''
    };
  }
});