const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  const openid = event.openid || wxContext.OPENID
  
  try {
    const res = await db.collection('friends')
      .where({
        $or: [
          { fromOpenid: openid, status: 'accepted' },
          { toOpenid: openid, status: 'accepted' }
        ]
      })
      .get()
    
    const friendsList = []
    for (const item of res.data) {
      const friendOpenid = item.fromOpenid === openid ? item.toOpenid : item.fromOpenid
      const userInfo = await db.collection('users').where({ openid: friendOpenid }).get()
      if (userInfo.data.length > 0) {
        friendsList.push({
          openid: friendOpenid,
          nickName: userInfo.data[0].nickName || '用户',
          avatarUrl: userInfo.data[0].avatarUrl || ''
        })
      }
    }
    
    return friendsList
  } catch (e) {
    console.error('获取好友列表失败：', e)
    return []
  }
}
