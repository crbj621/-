const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

const db = cloud.database()
const cmd = db.command

async function ensureCollection(name) {
  try {
    await db.createCollection(name)
  } catch (e) {
    // already exists / no permission / ignore
  }
}

function formatTime(value) {
  if (!value) return ''
  var date
  if (typeof value.toDate === 'function') {
    date = value.toDate()
  } else {
    date = new Date(value)
  }
  var y = date.getFullYear()
  var m = String(date.getMonth() + 1)
  var d = String(date.getDate())
  var hh = String(date.getHours())
  var mm = String(date.getMinutes())
  if (m.length === 1) m = '0' + m
  if (d.length === 1) d = '0' + d
  if (hh.length === 1) hh = '0' + hh
  if (mm.length === 1) mm = '0' + mm
  return y + '-' + m + '-' + d + ' ' + hh + ':' + mm
}

async function writeShopLog(shopId, type, description, operatorName) {
  try {
    await db.collection('food_shop_logs').add({
      data: {
        shopId: shopId,
        type: type,
        description: description,
        operatorName: operatorName || '骑手',
        createTime: db.serverDate()
      }
    })
  } catch (e) {
    console.error('writeShopLog error:', e)
  }
}

async function getRider(openid) {
  var res = await db.collection('food_rider').where({ _openid: openid, status: cmd.neq('disabled') }).limit(1).get()
  return res.data.length ? res.data[0] : null
}

async function getProfile(openid) {
  var rider = await getRider(openid)
  if (!rider) return { code: 0, data: { registered: false } }
  return { code: 0, data: { registered: true, rider: rider } }
}

async function register(openid, data) {
  // 兼容：若未初始化集合，尝试自动创建
  await ensureCollection('food_rider')

  var realName = (data.realName || '').trim()
  var phone = (data.phone || '').trim()
  var studentId = (data.studentId || '').trim()

  if (!realName) return { code: -1, message: '请输入姓名' }
  if (!phone) return { code: -1, message: '请输入手机号' }
  if (!studentId) return { code: -1, message: '请输入学号' }

  try {
    var exists = await db.collection('food_rider').where({ _openid: openid }).limit(1).get()
    if (exists.data.length) {
      await db.collection('food_rider').doc(exists.data[0]._id).update({
        data: {
          realName: realName,
          phone: phone,
          studentId: studentId,
          status: 'active',
          updateTime: db.serverDate()
        }
      })
      var updated = await getRider(openid)
      return { code: 0, data: { rider: updated } }
    }

    var addRes = await db.collection('food_rider').add({
      data: {
        _openid: openid,
        realName: realName,
        phone: phone,
        studentId: studentId,
        status: 'active',
        createTime: db.serverDate(),
        updateTime: db.serverDate()
      }
    })

    var rider = await db.collection('food_rider').doc(addRes._id).get().then(r => r.data).catch(() => null)
    return { code: 0, data: { rider: rider } }
  } catch (e) {
    console.error('rider register error:', e)
    return { code: -1, message: (e && e.message) ? e.message : '注册失败，请稍后重试' }
  }
}

async function attachShopInfo(orders) {
  for (var i = 0; i < orders.length; i++) {
    var order = orders[i]
    try {
      var shop = await db.collection('food_shop').doc(order.shopId).get()
      order.shopName = shop.data.name || '未知店铺'
      order.shopPhone = shop.data.phone || ''
      order.shopLogo = shop.data.logo || ''
    } catch (e) {
      order.shopName = '未知店铺'
      order.shopPhone = ''
      order.shopLogo = ''
    }
    order.createTimeText = formatTime(order.createTime)
    order.updateTimeText = formatTime(order.updateTime)
  }
  return orders
}

async function listAvailableOrders(openid) {
  var rider = await getRider(openid)
  if (!rider) return { code: -1, message: '请先注册骑手' }

  var res = await db.collection('food_order')
    .where({
      type: 'delivery',
      status: 'ready',
      riderOpenid: cmd.exists(false)
    })
    .orderBy('updateTime', 'desc')
    .limit(50)
    .get()

  var list = await attachShopInfo(res.data || [])
  return { code: 0, data: { list: list } }
}

async function acceptOrder(openid, data) {
  var rider = await getRider(openid)
  if (!rider) return { code: -1, message: '请先注册骑手' }

  var orderId = data.orderId
  if (!orderId) return { code: -1, message: '订单参数缺失' }

  var orderRes = await db.collection('food_order').doc(orderId).get().catch(() => null)
  if (!orderRes || !orderRes.data) return { code: -1, message: '订单不存在' }

  var order = orderRes.data
  if (order.type !== 'delivery') return { code: -1, message: '该订单不是配送单' }
  if (order.status !== 'ready') return { code: -1, message: '仅“待配送/已出餐”订单可接单' }
  if (order.riderOpenid) return { code: -1, message: '该订单已被接单' }

  await db.collection('food_order').doc(orderId).update({
    data: {
      riderOpenid: openid,
      riderName: rider.realName,
      riderPhone: rider.phone,
      deliveryStatus: 'accepted',
      riderAcceptTime: db.serverDate(),
      updateTime: db.serverDate()
    }
  })

  await writeShopLog(order.shopId, '配送', '骑手已接单：' + rider.realName, rider.realName)
  return { code: 0, message: '接单成功' }
}

async function listMyOrders(openid, data) {
  var rider = await getRider(openid)
  if (!rider) return { code: -1, message: '请先注册骑手' }

  var status = data.status || 'all'
  var query = { riderOpenid: openid }
  if (status !== 'all') query.deliveryStatus = status

  var res = await db.collection('food_order')
    .where(query)
    .orderBy('updateTime', 'desc')
    .limit(100)
    .get()

  var list = await attachShopInfo(res.data || [])
  return { code: 0, data: { list: list } }
}

async function updateDeliveryStatus(openid, data) {
  var orderId = data.orderId
  var status = data.deliveryStatus

  if (!orderId || !status) return { code: -1, message: '参数缺失' }

  var orderRes = await db.collection('food_order').doc(orderId).get().catch(() => null)
  if (!orderRes || !orderRes.data) return { code: -1, message: '订单不存在' }

  var order = orderRes.data
  if (order.riderOpenid !== openid) return { code: -1, message: '无权限操作该订单' }

  var allowMap = {
    accepted: ['picking'],
    picking: ['delivering'],
    delivering: ['delivered']
  }

  var current = order.deliveryStatus || 'accepted'
  var allow = allowMap[current] || []
  if (allow.indexOf(status) === -1) {
    return { code: -1, message: '配送状态流转不合法: ' + current + ' -> ' + status }
  }

  var updateData = {
    deliveryStatus: status,
    updateTime: db.serverDate()
  }
  if (status === 'delivered') {
    updateData.deliveredTime = db.serverDate()
    updateData.status = 'completed'
    updateData.completedTime = db.serverDate()
  }

  await db.collection('food_order').doc(orderId).update({ data: updateData })

  var statusText = { picking: '取餐中', delivering: '配送中', delivered: '已送达' }
  await writeShopLog(order.shopId, '配送', '骑手更新配送状态：' + (statusText[status] || status), order.riderName || '骑手')

  return { code: 0, message: '状态已更新' }
}

exports.main = async function(event) {
  var wxContext = cloud.getWXContext()
  var openid = wxContext.OPENID
  var action = event.action
  var data = event.data || {}

  try {
    switch (action) {
      case 'getProfile':
        return await getProfile(openid)
      case 'register':
        return await register(openid, data)
      case 'listAvailableOrders':
        return await listAvailableOrders(openid)
      case 'acceptOrder':
        return await acceptOrder(openid, data)
      case 'listMyOrders':
        return await listMyOrders(openid, data)
      case 'updateDeliveryStatus':
        return await updateDeliveryStatus(openid, data)
      default:
        return { code: -1, message: 'Unknown action: ' + action }
    }
  } catch (e) {
    console.error('rider cloud function error:', e)
    return { code: -1, message: e.message || '服务异常' }
  }
}
