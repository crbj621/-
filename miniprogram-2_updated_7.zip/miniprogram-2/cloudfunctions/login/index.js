const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID
  const appid = wxContext.APPID
  const unionid = wxContext.UNIONID

  console.log('login 云函数被调用')
  console.log('OPENID:', openid)
  console.log('APPID:', appid)

  return {
    openid: openid,
    appid: appid,
    unionid: unionid
  }
}
