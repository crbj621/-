const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()
const _ = db.command

// 兼容旧管理端的默认账号（建议统一使用 globalAdmin 管理端）
const ADMIN_ACCOUNT = '348156572'
const ADMIN_PASSWORD = 'jsx621621'

exports.main = async (event) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID
  const appid = wxContext.APPID
  
  console.log('=== 云函数调试信息 ===')
  console.log('OPENID:', openid)
  console.log('APPID:', appid)
  console.log('ENV:', cloud.DYNAMIC_CURRENT_ENV)
  console.log('action:', event.action)
  console.log('========================')
  
  const { action, data = {} } = event

  try {
    switch (action) {
      case 'getOpenId':
        return { success: true, openid: openid, appid: appid }
      case 'initDatabase':
        return await initDatabase()
      case 'createOrder':
        return await createOrder(openid, data)
      case 'getUserOrders':
        return await getUserOrders(openid, data)
      case 'getOrderDetail':
        return await getOrderDetail(openid, data)
      case 'getShopList':
        return await getShopList(data)
      case 'getShopDetail':
        return await getShopDetail(data)
      case 'shopLogin':
        return await shopLogin(openid, data)
      case 'getShopOrders':
        return await getShopOrders(openid, data)
      case 'updateOrderStatus':
        return await updateOrderStatus(openid, data)
      case 'manageDish':
        return await manageDish(openid, data)
      case 'updateShopInfo':
        return await updateShopInfo(openid, data)
      case 'updateShopLogo':
        return await updateShopLogo(openid, data)
      case 'updateFeaturedDishes':
        return await updateFeaturedDishes(openid, data)
      case 'checkMerchantStatus':
        return await checkMerchantStatus(openid)
      case 'registerMerchant':
        return await registerMerchant(openid, data)
      case 'resetPassword':
        return await resetPassword(data)
      case 'changePassword':
        return await changePassword(openid, data)
      case 'adminLogin':
        return await adminLogin(data)
      case 'getAdminStats':
        return await getAdminStats()
      case 'getRankList':
        return await getRankList(data)
      case 'clearRankRecords':
        return await clearRankRecords(data)
      case 'getShopAuditList':
        return await getShopAuditList(data)
      case 'auditShop':
        return await auditShop(data)
      case 'getShopManageList':
        return await getShopManageList(data)
      case 'adminUpdateShopStatus':
        return await adminUpdateShopStatus(data)
      case 'adminUpdateShopInfo':
        return await adminUpdateShopInfo(data)
      case 'adminResetShopPassword':
        return await adminResetShopPassword(data)
      case 'adminUpdateShopAccount':
        return await adminUpdateShopAccount(data)
      case 'getShopLogs':
        return await getShopLogs(data)
      case 'getShopDishes':
        return await getShopDishes(data)
      case 'shopAutoLogin':
        return await shopAutoLogin(openid)
      case 'initTestData':
        return await initTestData(openid)
      default:
        return { success: false, msg: 'Unknown action: ' + action }
    }
  } catch (error) {
    console.error('Cloud function error:', error)
    return { success: false, msg: error.message || '服务异常', error: error.toString() }
  }
}

async function initDatabase() {
  const collections = ['food_shop', 'food_shop_user', 'food_dish', 'food_order', 'food_shop_logs']
  const results = []
  
  for (const name of collections) {
    try {
      await db.createCollection(name)
      results.push({ name, status: 'created' })
    } catch (err) {
      if (err.message && err.message.includes('already exists')) {
        results.push({ name, status: 'exists' })
      } else {
        results.push({ name, status: 'error', msg: err.message })
      }
    }
  }
  
  return { success: true, msg: '数据库初始化完成', results }
}

function formatTime(value) {
  if (!value) return ''
  const date = typeof value.toDate === 'function' ? value.toDate() : new Date(value)
  const y = date.getFullYear()
  const m = String(date.getMonth() + 1).padStart(2, '0')
  const d = String(date.getDate()).padStart(2, '0')
  const hh = String(date.getHours()).padStart(2, '0')
  const mm = String(date.getMinutes()).padStart(2, '0')
  return y + '-' + m + '-' + d + ' ' + hh + ':' + mm
}

async function getMerchantByOpenid(openid) {
  const res = await db.collection('food_shop_user').where({ bindOpenid: openid }).limit(1).get()
  if (!res.data.length) return null
  return res.data[0]
}

async function writeLog(shopId, type, description, operatorName) {
  operatorName = operatorName || '系统'
  try {
    await db.collection('food_shop_logs').add({
      data: {
        shopId: shopId,
        type: type,
        description: description,
        operatorName: operatorName,
        createTime: db.serverDate()
      }
    })
  } catch (err) {
    console.error('writeLog error:', err)
  }
}

async function createOrder(openid, data) {
  const shopId = data.shopId
  const items = data.items || []
  const totalPrice = data.totalPrice || 0
  const type = data.type
  const address = data.address || ''
  const remark = data.remark || ''
  const phone = data.phone || ''
  const pickupTime = data.pickupTime || ''
  const userNickName = data.userNickName || ''
  const userAvatarUrl = data.userAvatarUrl || ''
  
  if (!shopId) return { success: false, msg: '店铺信息异常' }
  if (!Array.isArray(items) || items.length === 0) return { success: false, msg: '请先选择菜品' }
  if (!phone) return { success: false, msg: '请填写联系电话' }
  if (type === 'delivery' && !address) return { success: false, msg: '请填写配送地址' }
  if (type === 'pickup' && !pickupTime) return { success: false, msg: '请选择取餐时间' }

  const pickupCode = Math.floor(100000 + Math.random() * 900000).toString()
  
  const res = await db.collection('food_order').add({
    data: {
      _openid: openid,
      shopId: shopId,
      items: items,
      totalPrice: totalPrice,
      type: type,
      address: type === 'delivery' ? address : '',
      pickupCode: type === 'pickup' ? pickupCode : '',
      pickupTime: type === 'pickup' ? pickupTime : '',
      phone: phone,
      status: 'pending',
      remark: remark,
      userNickName: userNickName,
      userAvatarUrl: userAvatarUrl,
      createTime: db.serverDate(),
      updateTime: db.serverDate()
    }
  })

  await writeLog(shopId, '新订单', '收到新订单，等待接单')
  
  return { success: true, orderId: res._id, pickupCode: pickupCode }
}

async function attachShopInfo(orders) {
  for (let i = 0; i < orders.length; i++) {
    const order = orders[i]
    try {
      const shop = await db.collection('food_shop').doc(order.shopId).get()
      order.shopName = shop.data.name || '未知店铺'
      order.shopLogo = shop.data.logo || ''
    } catch (e) {
      order.shopName = '未知店铺'
      order.shopLogo = ''
    }
    order.createTimeText = formatTime(order.createTime)
    order.updateTimeText = formatTime(order.updateTime)
  }
  return orders
}

async function getUserOrders(openid, data) {
  const status = data.status || 'all'
  const query = { _openid: openid }
  if (status !== 'all') query.status = status

  const res = await db.collection('food_order')
    .where(query)
    .orderBy('createTime', 'desc')
    .get()

  const list = await attachShopInfo(res.data || [])
  return { success: true, list: list }
}

async function getOrderDetail(openid, data) {
  const orderId = data.orderId
  if (!orderId) return { success: false, msg: '订单参数缺失' }
  
  const res = await db.collection('food_order').doc(orderId).get().catch(function() { return null })
  if (!res || !res.data) return { success: false, msg: '订单不存在' }
  if (res.data._openid !== openid) return { success: false, msg: '无权限查看该订单' }
  
  const list = await attachShopInfo([res.data])
  return { success: true, detail: list[0] }
}

async function getShopList(data) {
  const keyword = data.keyword || ''
  const status = data.status || ''
  const page = data.page || 1
  const pageSize = data.pageSize || 10
  
  const query = { auditStatus: 'approved', status: _.neq('pending') }
  if (keyword) query.name = db.RegExp({ regexp: keyword, options: 'i' })
  if (status) query.status = status

  const skip = (page - 1) * pageSize
  const res = await db.collection('food_shop')
    .where(query)
    .orderBy('createTime', 'desc')
    .skip(skip)
    .limit(pageSize)
    .get()
  
  return { success: true, list: res.data || [] }
}

async function getShopDetail(data) {
  const shopId = data.shopId
  if (!shopId) return { success: false, msg: '店铺参数缺失' }

  const shop = await db.collection('food_shop').doc(shopId).get().catch(function() { return null })
  if (!shop || !shop.data) return { success: false, msg: '店铺不存在' }

  const dishes = await db.collection('food_dish')
    .where({ shopId: shopId, isAvailable: true })
    .orderBy('category', 'asc')
    .orderBy('name', 'asc')
    .get()

  const categories = {}
  const dishList = dishes.data || []
  for (let i = 0; i < dishList.length; i++) {
    const dish = dishList[i]
    const key = dish.category || '默认分类'
    if (!categories[key]) categories[key] = []
    categories[key].push(dish)
  }

  const menu = Object.keys(categories).map(function(name) { 
    return { name: name, items: categories[name] } 
  })
  
  return { success: true, shop: shop.data, menu: menu }
}

async function shopLogin(openid, data) {
  const username = data.username
  const password = data.password
  if (!username || !password) return { success: false, msg: '请输入账号密码' }

  const res = await db.collection('food_shop_user').where({ username: username, password: password }).limit(1).get()
  if (!res.data.length) return { success: false, msg: '用户名或密码错误' }

  const merchant = res.data[0]
  if (merchant.approved === false) return { success: false, msg: '商家账号未审核通过' }
  if (merchant.bindOpenid && merchant.bindOpenid !== openid) return { success: false, msg: '账号已在其他微信登录' }

  await db.collection('food_shop_user').doc(merchant._id).update({
    data: {
      bindOpenid: openid,
      lastLoginAt: db.serverDate()
    }
  })

  return { success: true, shopId: merchant.shopId }
}

async function getShopOrders(openid, data) {
  let shopId = data.shopId
  
  if (!shopId) {
    const merchant = await getMerchantByOpenid(openid)
    if (!merchant) return { success: false, msg: '请先登录商家账号' }
    shopId = merchant.shopId
  }

  const status = data.status || 'all'
  const query = { shopId: shopId }
  if (status !== 'all') query.status = status

  const res = await db.collection('food_order')
    .where(query)
    .orderBy('createTime', 'desc')
    .get()

  const list = (res.data || []).map(function(item) {
    return {
      ...item,
      createTimeText: formatTime(item.createTime),
      updateTimeText: formatTime(item.updateTime)
    }
  })

  return { success: true, list: list }
}

async function updateOrderStatus(openid, data) {
  const orderId = data.orderId
  const status = data.status
  const rejectReason = data.rejectReason || ''
  const shopId = data.shopId
  
  if (!orderId || !status) return { success: false, msg: '参数缺失' }

  const orderRes = await db.collection('food_order').doc(orderId).get().catch(function() { return null })
  if (!orderRes || !orderRes.data) return { success: false, msg: '订单不存在' }
  const order = orderRes.data

  let isMerchant = false
  if (shopId && shopId === order.shopId) {
    isMerchant = true
  } else {
    const merchant = await getMerchantByOpenid(openid)
    if (merchant && merchant.shopId === order.shopId) {
      isMerchant = true
    }
  }

  if (isMerchant) {
    const allowMap = {
      pending: ['processing', 'cancelled'],
      processing: ['ready'],
      ready: ['completed']
    }
    const currentAllow = allowMap[order.status] || []
    if (currentAllow.indexOf(status) === -1) return { success: false, msg: '订单状态流转不合法: ' + order.status + ' -> ' + status }

    const updateData = {
      status: status,
      updateTime: db.serverDate()
    }
    if (status === 'cancelled' && rejectReason) updateData.rejectReason = rejectReason
    if (status === 'ready') updateData.readyTime = db.serverDate()
    if (status === 'completed') updateData.completedTime = db.serverDate()

    await db.collection('food_order').doc(orderId).update({ data: updateData })
    
    const statusText = { processing: '已接单', ready: '已出餐', completed: '已完成', cancelled: '已取消' }
    await writeLog(order.shopId, '订单更新', '订单状态变更为: ' + (statusText[status] || status))
    
    return { success: true }
  }

  if (order._openid === openid) {
    if (status !== 'cancelled') return { success: false, msg: '用户仅支持取消订单' }
    if (order.status !== 'pending') return { success: false, msg: '仅待接单可取消' }
    await db.collection('food_order').doc(orderId).update({
      data: {
        status: 'cancelled',
        cancelBy: 'user',
        updateTime: db.serverDate()
      }
    })
    return { success: true }
  }

  return { success: false, msg: '无权限操作该订单' }
}

async function manageDish(openid, data) {
  const type = data.type
  const dishData = data.dishData || {}
  
  if (['add', 'update', 'delete'].indexOf(type) === -1) return { success: false, msg: '操作类型不支持' }

  let shopId = dishData.shopId
  
  if (!shopId) {
    const merchant = await getMerchantByOpenid(openid)
    if (!merchant) return { success: false, msg: '请先登录商家账号' }
    shopId = merchant.shopId
  }

  if (type === 'add') {
    const payload = {
      name: dishData.name || '',
      price: Number(dishData.price || 0),
      category: dishData.category || '默认分类',
      image: dishData.image || '',
      description: dishData.description || '',
      stock: Number(dishData.stock || 999),
      sales: Number(dishData.sales || 0),
      isAvailable: dishData.isAvailable !== false,
      shopId: shopId,
      createTime: db.serverDate(),
      updateTime: db.serverDate()
    }
    await db.collection('food_dish').add({ data: payload })
    await writeLog(shopId, '菜品管理', '添加菜品: ' + payload.name)
    return { success: true }
  }

  if (!dishData._id) return { success: false, msg: '菜品参数缺失' }
  const current = await db.collection('food_dish').doc(dishData._id).get().catch(function() { return null })
  if (!current || !current.data) return { success: false, msg: '菜品不存在' }
  if (current.data.shopId !== shopId) return { success: false, msg: '无权限操作该菜品' }

  if (type === 'delete') {
    await db.collection('food_dish').doc(dishData._id).remove()
    await writeLog(shopId, '菜品管理', '删除菜品: ' + current.data.name)
    return { success: true }
  }

  const payload = {
    name: dishData.name || current.data.name,
    price: Number(dishData.price || current.data.price),
    category: dishData.category || current.data.category,
    image: dishData.image !== undefined ? dishData.image : current.data.image,
    description: dishData.description || current.data.description,
    stock: Number(dishData.stock || current.data.stock),
    isAvailable: dishData.isAvailable !== undefined ? dishData.isAvailable : current.data.isAvailable,
    updateTime: db.serverDate()
  }
  await db.collection('food_dish').doc(dishData._id).update({ data: payload })
  await writeLog(shopId, '菜品管理', '更新菜品: ' + payload.name)
  return { success: true }
}

async function updateShopInfo(openid, data) {
  let shopId = data.shopId
  if (!shopId) {
    const merchant = await getMerchantByOpenid(openid)
    if (!merchant) return { success: false, msg: '请先登录商家账号' }
    shopId = merchant.shopId
  }

  const shopData = data.shopData || {}
  const payload = {
    updateTime: db.serverDate()
  }
  
  if (shopData.name !== undefined) payload.name = shopData.name
  if (shopData.status !== undefined) payload.status = shopData.status === 'closed' ? 'closed' : 'open'
  if (shopData.notice !== undefined) payload.notice = shopData.notice
  if (shopData.minPrice !== undefined) payload.minPrice = Number(shopData.minPrice || 0)
  if (shopData.deliveryFee !== undefined) payload.deliveryFee = Number(shopData.deliveryFee || 0)
  if (shopData.supportDelivery !== undefined) payload.supportDelivery = shopData.supportDelivery
  if (shopData.openTime !== undefined) payload.openTime = shopData.openTime
  if (shopData.closeTime !== undefined) payload.closeTime = shopData.closeTime
  if (shopData.pickupWindow !== undefined) payload.pickupWindow = shopData.pickupWindow

  await db.collection('food_shop').doc(shopId).update({ data: payload })
  await writeLog(shopId, '店铺设置', '更新店铺信息')
  return { success: true }
}

async function updateShopLogo(openid, data) {
  let shopId = data.shopId
  if (!shopId) {
    const merchant = await getMerchantByOpenid(openid)
    if (!merchant) return { success: false, msg: '请先登录商家账号' }
    shopId = merchant.shopId
  }
  
  const logo = data.logo
  if (!logo) return { success: false, msg: '请提供头像' }
  
  await db.collection('food_shop').doc(shopId).update({
    data: {
      logo: logo,
      updateTime: db.serverDate()
    }
  })
  
  await writeLog(shopId, '店铺设置', '更新店铺头像')
  return { success: true }
}

async function updateFeaturedDishes(openid, data) {
  let shopId = data.shopId
  if (!shopId) {
    const merchant = await getMerchantByOpenid(openid)
    if (!merchant) return { success: false, msg: '请先登录商家账号' }
    shopId = merchant.shopId
  }
  
  const featuredDishes = data.featuredDishes || []
  if (featuredDishes.length > 2) {
    return { success: false, msg: '最多只能设置2个推荐菜品' }
  }
  
  await db.collection('food_shop').doc(shopId).update({
    data: {
      featuredDishes: featuredDishes,
      updateTime: db.serverDate()
    }
  })
  
  await writeLog(shopId, '店铺设置', '更新推荐菜品')
  return { success: true }
}

async function checkMerchantStatus(openid) {
  const user = await getMerchantByOpenid(openid)
  if (!user) return { success: true, isMerchant: false }
  
  const shop = await db.collection('food_shop').doc(user.shopId).get().catch(function() { return null })
  if (!shop || !shop.data) return { success: true, isMerchant: false }

  return { 
    success: true, 
    isMerchant: true, 
    shopId: user.shopId, 
    shopStatus: shop.data.status 
  }
}

async function registerMerchant(openid, data) {
  const name = data.name
  const contact = data.contact
  const phone = data.phone
  const coverImage = data.coverImage
  const licenseImage = data.licenseImage
  const username = data.username
  const password = data.password
  const supportDelivery = data.supportDelivery !== false
  
  if (!name) return { success: false, msg: '请输入店铺名称' }
  if (!contact) return { success: false, msg: '请输入联系人' }
  if (!phone) return { success: false, msg: '请输入联系电话' }
  
  if (username) {
    if (username.length < 4) return { success: false, msg: '账号至少4位' }
    if (!password || password.length < 6) return { success: false, msg: '密码至少6位' }
    
    const existingUsername = await db.collection('food_shop_user').where({ username: username }).get()
    if (existingUsername.data.length > 0) {
      return { success: false, msg: '该账号已被使用' }
    }
  }
  
  const existingUser = await db.collection('food_shop_user').where({ bindOpenid: openid }).get()
  if (existingUser.data.length > 0) {
    return { success: false, msg: '您已提交过申请或已是商家' }
  }

  const shopRes = await db.collection('food_shop').add({
    data: {
      name: name,
      contact: contact,
      phone: phone,
      logo: coverImage || '',
      licenseImage: licenseImage || '',
      status: 'pending',
      auditStatus: 'pending',
      rating: 5.0,
      monthlySales: 0,
      minPrice: 0,
      deliveryFee: 0,
      supportDelivery: supportDelivery,
      createTime: db.serverDate(),
      updateTime: db.serverDate()
    }
  })

  const userData = {
    bindOpenid: openid,
    shopId: shopRes._id,
    role: 'admin',
    createTime: db.serverDate()
  }
  
  if (username && password) {
    userData.username = username
    userData.password = password
    userData.approved = false
  }

  await db.collection('food_shop_user').add({ data: userData })

  return { success: true, msg: '申请已提交，请等待审核' }
}

async function resetPassword(data) {
  const phone = data.phone
  const username = data.username
  const newPassword = data.newPassword
  
  if (!username) return { success: false, msg: '请输入账号' }
  if (!phone) return { success: false, msg: '请输入注册手机号' }
  if (!newPassword || newPassword.length < 6) return { success: false, msg: '新密码至少6位' }
  
  const shopUser = await db.collection('food_shop_user').where({ 
    username: username
  }).limit(1).get()
  
  if (!shopUser.data.length) {
    return { success: false, msg: '账号不存在' }
  }
  
  const user = shopUser.data[0]
  const shop = await db.collection('food_shop').doc(user.shopId).get().catch(function() { return null })
  
  if (!shop || !shop.data || shop.data.phone !== phone) {
    return { success: false, msg: '手机号与账号不匹配' }
  }
  
  await db.collection('food_shop_user').doc(user._id).update({
    data: {
      password: newPassword,
      updateTime: db.serverDate()
    }
  })
  
  return { success: true, msg: '密码重置成功' }
}

async function changePassword(openid, data) {
  const oldPassword = data.oldPassword
  const newPassword = data.newPassword
  
  if (!oldPassword || !newPassword) return { success: false, msg: '请输入密码' }
  if (newPassword.length < 6) return { success: false, msg: '新密码至少6位' }
  
  const merchant = await getMerchantByOpenid(openid)
  if (!merchant) return { success: false, msg: '请先登录' }
  
  if (merchant.password !== oldPassword) {
    return { success: false, msg: '原密码错误' }
  }
  
  await db.collection('food_shop_user').doc(merchant._id).update({
    data: {
      password: newPassword,
      updateTime: db.serverDate()
    }
  })
  
  return { success: true, msg: '密码修改成功' }
}

async function adminLogin(data) {
  const username = data.username
  const password = data.password
  if (username !== ADMIN_ACCOUNT || password !== ADMIN_PASSWORD) {
    return { success: false, msg: '账号或密码错误' }
  }
  return { 
    success: true, 
    adminInfo: { username: username, role: 'super_admin' }
  }
}

async function getAdminStats() {
  const pendingShopsRes = await db.collection('food_shop').where({ auditStatus: 'pending' }).count().catch(function() { return { total: 0 } })
  const totalShopsRes = await db.collection('food_shop').where({ auditStatus: 'approved' }).count().catch(function() { return { total: 0 } })
  const totalOrdersRes = await db.collection('food_order').count().catch(function() { return { total: 0 } })
  const rankRecordsRes = await db.collection('run_stats').count().catch(function() { return { total: 0 } })

  return {
    success: true,
    stats: {
      pendingShops: pendingShopsRes.total,
      totalShops: totalShopsRes.total,
      totalOrders: totalOrdersRes.total,
      rankRecords: rankRecordsRes.total
    }
  }
}

async function getRankList(data) {
  const keyword = data.keyword || ''
  const query = {}
  if (keyword) {
    query.nickName = db.RegExp({ regexp: keyword, options: 'i' })
  }

  const res = await db.collection('run_stats')
    .where(query)
    .orderBy('totalDistance', 'desc')
    .limit(100)
    .get()

  const list = res.data.map(function(item) {
    return {
      ...item,
      updateTimeText: formatTime(item.updateTime)
    }
  })

  return { success: true, list: list }
}

async function clearRankRecords(data) {
  const ids = data.ids
  if (!ids || ids.length === 0) {
    return { success: false, msg: '请选择要删除的记录' }
  }

  for (let i = 0; i < ids.length; i++) {
    await db.collection('run_stats').doc(ids[i]).remove()
  }

  await db.collection('admin_logs').add({
    data: {
      action: 'clearRankRecords',
      description: '删除了 ' + ids.length + ' 条排行榜记录',
      createTime: db.serverDate()
    }
  })

  return { success: true }
}

async function getShopAuditList(data) {
  const status = data.status || 'pending'
  const date = data.date || ''
  const name = data.name || ''
  
  const query = {}
  if (status && status !== 'all') {
    query.auditStatus = status
  }
  if (name) {
    query.name = db.RegExp({ regexp: name, options: 'i' })
  }

  const res = await db.collection('food_shop')
    .where(query)
    .orderBy('createTime', 'desc')
    .limit(50)
    .get()

  const list = res.data.map(function(item) {
    return {
      ...item,
      createTimeText: formatTime(item.createTime)
    }
  })

  return { success: true, list: list }
}

async function auditShop(data) {
  const shopId = data.shopId
  const status = data.status
  const reason = data.reason || ''
  
  if (!shopId || !status) return { success: false, msg: '参数缺失' }

  const updateData = {
    auditStatus: status,
    status: status === 'approved' ? 'open' : 'closed',
    updateTime: db.serverDate()
  }
  
  if (status === 'rejected') {
    updateData.rejectReason = reason
  }

  await db.collection('food_shop').doc(shopId).update({ data: updateData })

  if (status === 'approved') {
    const shop = await db.collection('food_shop').doc(shopId).get()
    const shopUser = await db.collection('food_shop_user').where({ shopId: shopId }).limit(1).get()
    
    if (shopUser.data.length > 0) {
      const username = 'shop_' + Date.now().toString().slice(-6)
      const password = '123456'
      await db.collection('food_shop_user').doc(shopUser.data[0]._id).update({
        data: {
          username: username,
          password: password,
          approved: true,
          updateTime: db.serverDate()
        }
      })
    }
  }

  await writeLog(shopId, '审核', status === 'approved' ? '商家入驻审核通过' : '商家入驻审核拒绝: ' + reason, '管理员')

  return { success: true }
}

async function getShopManageList(data) {
  const keyword = data.keyword || ''
  const query = { auditStatus: 'approved' }
  if (keyword) {
    query.name = db.RegExp({ regexp: keyword, options: 'i' })
  }

  const res = await db.collection('food_shop')
    .where(query)
    .orderBy('createTime', 'desc')
    .get()

  const list = res.data.map(function(item) {
    return {
      ...item,
      createTimeText: formatTime(item.createTime)
    }
  })

  return { success: true, list: list }
}

async function adminUpdateShopStatus(data) {
  const shopId = data.shopId
  const status = data.status
  if (!shopId || !status) return { success: false, msg: '参数缺失' }

  await db.collection('food_shop').doc(shopId).update({
    data: {
      status: status,
      updateTime: db.serverDate()
    }
  })

  await writeLog(shopId, '状态变更', '商家状态变更为: ' + (status === 'open' ? '营业中' : '已关闭'), '管理员')

  return { success: true }
}

async function adminUpdateShopInfo(data) {
  const shopId = data.shopId
  const shopData = data.shopData
  if (!shopId) return { success: false, msg: '参数缺失' }

  const payload = {
    name: shopData.name,
    contact: shopData.contact,
    phone: shopData.phone,
    minPrice: Number(shopData.minPrice || 0),
    deliveryFee: Number(shopData.deliveryFee || 0),
    updateTime: db.serverDate()
  }

  await db.collection('food_shop').doc(shopId).update({ data: payload })
  await writeLog(shopId, '信息编辑', '管理员编辑了商家信息', '管理员')

  return { success: true }
}

async function adminResetShopPassword(data) {
  const shopId = data.shopId
  if (!shopId) return { success: false, msg: '参数缺失' }

  const shopUser = await db.collection('food_shop_user').where({ shopId: shopId }).limit(1).get()
  if (shopUser.data.length === 0) {
    return { success: false, msg: '商家账号不存在' }
  }

  await db.collection('food_shop_user').doc(shopUser.data[0]._id).update({
    data: {
      password: '123456',
      updateTime: db.serverDate()
    }
  })

  await writeLog(shopId, '密码重置', '管理员重置了商家登录密码', '管理员')

  return { success: true }
}

async function adminUpdateShopAccount(data) {
  const shopId = data.shopId
  const username = data.username
  const password = data.password
  if (!shopId) return { success: false, msg: '参数缺失' }

  const shopUser = await db.collection('food_shop_user').where({ shopId: shopId }).limit(1).get()
  if (shopUser.data.length === 0) {
    return { success: false, msg: '商家账号不存在' }
  }

  const updateData = { updateTime: db.serverDate() }
  if (username) updateData.username = username
  if (password) updateData.password = password

  await db.collection('food_shop_user').doc(shopUser.data[0]._id).update({
    data: updateData
  })

  await writeLog(shopId, '账号修改', '管理员修改了商家账号信息', '管理员')

  return { success: true, username: username || shopUser.data[0].username }
}

async function getShopLogs(data) {
  const shopId = data.shopId
  if (!shopId) return { success: false, msg: '参数缺失' }

  const res = await db.collection('food_shop_logs')
    .where({ shopId: shopId })
    .orderBy('createTime', 'desc')
    .limit(100)
    .get()

  const list = res.data.map(function(item) {
    return {
      ...item,
      createTimeText: formatTime(item.createTime)
    }
  })

  return { success: true, list: list }
}

async function getShopDishes(data) {
  const shopId = data.shopId
  if (!shopId) return { success: false, msg: '参数缺失' }

  const res = await db.collection('food_dish')
    .where({ shopId: shopId })
    .orderBy('createTime', 'desc')
    .get()

  const dishes = res.data.map(function(item) {
    return {
      ...item,
      createTimeText: formatTime(item.createTime)
    }
  })

  return { success: true, dishes: dishes }
}

async function shopAutoLogin(openid) {
  const merchant = await getMerchantByOpenid(openid)
  if (!merchant) {
    return { success: false, msg: '您还不是商家，请先申请入驻' }
  }

  const shop = await db.collection('food_shop').doc(merchant.shopId).get().catch(function() { return null })
  if (!shop || !shop.data) {
    return { success: false, msg: '店铺不存在' }
  }

  if (shop.data.auditStatus !== 'approved') {
    return { success: false, msg: '店铺审核中或未通过', auditStatus: shop.data.auditStatus }
  }

  return {
    success: true,
    shopId: merchant.shopId,
    shopInfo: shop.data
  }
}

async function initTestData(openid) {
  const shopCount = await db.collection('food_shop').count().catch(function() { return { total: 0 } })
  const shopIndex = shopCount.total + 1
  
  const shopNames = ['美味食堂', '香喷喷餐厅', '好味道快餐', '鲜香阁', '食为天']
  const nameIndex = (shopIndex - 1) % shopNames.length
  const shopName = shopNames[nameIndex] + (shopIndex > 5 ? String(shopIndex) : '')
  
  const shopRes = await db.collection('food_shop').add({
    data: {
      name: shopName,
      contact: '测试商家',
      phone: '1380013' + String(shopIndex).padStart(4, '0'),
      logo: '',
      banners: [],
      status: 'open',
      auditStatus: 'approved',
      rating: (4 + Math.random()).toFixed(1),
      monthlySales: Math.floor(Math.random() * 500),
      minPrice: 10 + Math.floor(Math.random() * 10),
      deliveryFee: 2 + Math.floor(Math.random() * 3),
      notice: '欢迎光临' + shopName + '！',
      signatureDishes: [],
      createTime: db.serverDate(),
      updateTime: db.serverDate()
    }
  })

  const shopId = shopRes._id
  const username = 'shop_' + Date.now().toString().slice(-6)
  const password = '123456'

  await db.collection('food_shop_user').add({
    data: {
      bindOpenid: '',
      shopId: shopId,
      username: username,
      password: password,
      role: 'admin',
      approved: true,
      createTime: db.serverDate(),
      updateTime: db.serverDate()
    }
  })

  const dishes = [
    { name: '红烧肉', price: 28, category: '热销', description: '精选五花肉，入口即化', stock: 50 },
    { name: '宫保鸡丁', price: 22, category: '热销', description: '经典川菜，香辣可口', stock: 50 },
    { name: '鱼香肉丝', price: 20, category: '热销', description: '酸甜适中，下饭神器', stock: 50 },
    { name: '番茄炒蛋', price: 15, category: '家常菜', description: '简单美味，营养健康', stock: 50 },
    { name: '青椒肉丝', price: 18, category: '家常菜', description: '清爽下饭', stock: 50 },
    { name: '麻婆豆腐', price: 16, category: '家常菜', description: '麻辣鲜香', stock: 50 },
    { name: '可乐鸡翅', price: 25, category: '新品', description: '甜香入味，老少皆宜', stock: 30 },
    { name: '酸辣土豆丝', price: 12, category: '素菜', description: '酸辣爽口', stock: 50 },
    { name: '米饭', price: 2, category: '主食', description: '东北大米', stock: 200 },
    { name: '可乐', price: 5, category: '饮品', description: '冰镇可乐', stock: 100 }
  ]

  for (let i = 0; i < dishes.length; i++) {
    const dish = dishes[i]
    await db.collection('food_dish').add({
      data: {
        name: dish.name,
        price: dish.price,
        category: dish.category,
        description: dish.description,
        stock: dish.stock,
        shopId: shopId,
        image: '',
        isAvailable: true,
        sales: Math.floor(Math.random() * 100),
        createTime: db.serverDate(),
        updateTime: db.serverDate()
      }
    })
  }

  return { 
    success: true, 
    msg: '测试商家创建成功',
    shopId: shopId,
    shopName: shopName,
    loginInfo: {
      username: username,
      password: password
    }
  }
}
