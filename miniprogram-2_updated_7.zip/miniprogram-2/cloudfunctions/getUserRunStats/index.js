// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()
const _ = db.command

// 云函数入口函数
exports.main = async (event, context) => {
  try {
    const { openid } = event
    const result = await db.collection('runRecords')
      .where({
        openid: openid
      })
      .get()
    
    const records = result.data
    let totalDistance = 0
    let totalDuration = 0
    let totalRuns = records.length
    let bestDistance = 0
    let bestPace = Infinity
    
    records.forEach(record => {
      totalDistance += record.distance
      totalDuration += record.duration || 0
      if (record.distance > bestDistance) {
        bestDistance = record.distance
      }
      if (record.pace && record.pace < bestPace) {
        bestPace = record.pace
      }
    })
    
    const averagePace = totalDistance > 0 ? (totalDuration / (totalDistance / 1000)) * 60 : 0
    
    return {
      totalDistance,
      totalRuns,
      totalDuration,
      bestDistance,
      bestPace: bestPace === Infinity ? 0 : bestPace,
      averagePace
    }
  } catch (error) {
    console.error('获取用户跑步统计数据失败：', error)
    return { 
      totalDistance: 0, 
      totalRuns: 0, 
      totalDuration: 0, 
      bestDistance: 0, 
      bestPace: 0, 
      averagePace: 0 
    }
  }
}