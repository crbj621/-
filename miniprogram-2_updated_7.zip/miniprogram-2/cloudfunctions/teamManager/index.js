const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()
const _ = db.command

exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID
  const { action, teamName, teamId, members, teamType, memberOpenid, data, inviteCode } = event

  switch (action) {
    case 'create':
      return await createTeam(openid, members, teamType)
    case 'joinTeam':
      return await joinTeam(openid, inviteCode)
    case 'leaveTeam':
      return await leaveTeam(openid, teamId)
    case 'getMyTeam':
      return await getMyTeam(openid)
    case 'getTeamInfo':
      return await getTeamInfo(teamId)
    case 'syncRealtime':
      return await syncRealtimeData(teamId, memberOpenid, data)
    case 'getTeamRealtimeData':
      return await getTeamRealtimeData(teamId)
    case 'refreshCode':
      return await refreshInviteCode(teamId)
    default:
      return { success: false, errMsg: 'Unknown action' }
  }
}

function generateInviteCode() {
  return Math.floor(100 + Math.random() * 900).toString()
}

async function createTeam(leaderOpenid, members, teamType) {
  try {
    const inviteCode = generateInviteCode()
    const expireTime = Date.now() + 10 * 60 * 1000
    
    const teamData = {
      leaderOpenid: leaderOpenid,
      members: members || [],
      memberCount: (members ? members.length : 0) + 1,
      teamType: teamType || 'team',
      createTime: db.serverDate(),
      inviteCode: inviteCode,
      inviteCodeExpire: expireTime,
      realtimeData: {}
    }
    
    if (members && members.length > 0) {
      members.forEach(function(m) {
        teamData.realtimeData[m] = {
          distance: 0,
          pace: 0,
          duration: 0,
          steps: 0,
          nickName: '',
          avatarUrl: ''
        }
      })
    }
    teamData.realtimeData[leaderOpenid] = {
      distance: 0,
      pace: 0,
      duration: 0,
      steps: 0,
      nickName: '',
      avatarUrl: ''
    }

    const res = await db.collection('teams').add({
      data: teamData
    })
    
    return { 
      success: true, 
      _id: res._id, 
      teamId: res._id,
      inviteCode: inviteCode,
      inviteCodeExpire: expireTime
    }
  } catch (e) {
    return { success: false, errMsg: e.message }
  }
}

async function joinTeam(openid, inviteCode) {
  try {
    if (!inviteCode) {
      return { success: false, errMsg: '请输入邀请码' }
    }
    
    const now = Date.now()
    const res = await db.collection('teams')
      .where({
        inviteCode: inviteCode,
        inviteCodeExpire: _.gt(now)
      })
      .get()
    
    if (!res.data || res.data.length === 0) {
      return { success: false, errMsg: '邀请码无效或已过期' }
    }
    
    const team = res.data[0]
    
    if (team.leaderOpenid === openid || (team.members && team.members.indexOf(openid) !== -1)) {
      return { success: false, errMsg: '您已在队伍中' }
    }
    
    if (team.members && team.members.length >= 2) {
      return { success: false, errMsg: '该队伍已满员（仅限3人）' }
    }

    await db.collection('teams').doc(team._id).update({
      data: {
        members: _.addToSet(openid)
      }
    })

    return { success: true, teamId: team._id }
  } catch (e) {
    return { success: false, errMsg: e.message }
  }
}

async function leaveTeam(openid, teamId) {
  try {
    const team = await db.collection('teams').doc(teamId).get()
    if (!team.data) return { success: false, errMsg: '队伍不存在' }

    if (team.data.leaderOpenid === openid) {
      await db.collection('teams').doc(teamId).remove()
      return { success: true, msg: '队伍已解散' }
    } else {
      await db.collection('teams').doc(teamId).update({
        data: {
          members: _.pull(openid)
        }
      })
      return { success: true, msg: '已退出队伍' }
    }
  } catch (e) {
    return { success: false, errMsg: e.message }
  }
}

async function getMyTeam(openid) {
  try {
    const res = await db.collection('teams').where({
      members: openid
    }).get()
    
    const leaderRes = await db.collection('teams').where({
      leaderOpenid: openid
    }).get()
    
    let team = null
    if (res.data && res.data.length > 0) {
      team = res.data[0]
    } else if (leaderRes.data && leaderRes.data.length > 0) {
      team = leaderRes.data[0]
    }
    
    if (team) {
      const now = Date.now()
      if (team.inviteCodeExpire && team.inviteCodeExpire < now) {
        const newCode = generateInviteCode()
        const newExpire = Date.now() + 10 * 60 * 1000
        await db.collection('teams').doc(team._id).update({
          data: {
            inviteCode: newCode,
            inviteCodeExpire: newExpire
          }
        })
        team.inviteCode = newCode
        team.inviteCodeExpire = newExpire
      }
    }
    
    return { success: true, data: team }
  } catch (e) {
    return { success: false, errMsg: e.message }
  }
}

async function getTeamInfo(teamId) {
  try {
    const res = await db.collection('teams').doc(teamId).get()
    return { success: true, data: res.data }
  } catch (e) {
    return { success: false, errMsg: e.message }
  }
}

async function syncRealtimeData(teamId, memberOpenid, data) {
  try {
    const updateData = {}
    updateData['realtimeData.' + memberOpenid] = data
    
    await db.collection('teams').doc(teamId).update({
      data: updateData
    })
    
    return { success: true }
  } catch (e) {
    return { success: false, errMsg: e.message }
  }
}

async function getTeamRealtimeData(teamId) {
  try {
    const res = await db.collection('teams').doc(teamId).get()
    return { success: true, data: res.data.realtimeData || {} }
  } catch (e) {
    return { success: false, errMsg: e.message }
  }
}

async function refreshInviteCode(teamId) {
  try {
    const newCode = generateInviteCode()
    const newExpire = Date.now() + 10 * 60 * 1000
    
    await db.collection('teams').doc(teamId).update({
      data: {
        inviteCode: newCode,
        inviteCodeExpire: newExpire
      }
    })
    
    return { 
      success: true, 
      inviteCode: newCode,
      inviteCodeExpire: newExpire
    }
  } catch (e) {
    return { success: false, errMsg: e.message }
  }
}
