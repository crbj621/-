const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()
const _ = db.command

exports.main = async (event, context) => {
  const { tab, action } = event

  if (action === 'refresh') {
    return { success: true, message: '排行榜已刷新' }
  }

  console.log('获取排行榜，参数:', { tab, action })

  try {
    let result

    switch (tab) {
      case 'monthly':
        const now = new Date()
        const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1)
        const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59)

        result = await db.collection('runRecords')
          .where({
            date: _.gte(startOfMonth.toLocaleDateString('zh-CN')),
            date: _.lte(endOfMonth.toLocaleDateString('zh-CN'))
          })
          .orderBy('distance', 'desc')
          .limit(100)
          .get()
        console.log('月度榜查询结果:', result.data ? result.data.length : 0, '条')
        break

      case 'couple':
        const teams = await db.collection('teams').get()
        const teamRuns = []

        for (const team of teams.data) {
          const teamMembers = team.members || []
          if (teamMembers.length >= 2) {
            const teamRunResult = await db.collection('runRecords')
              .where({
                openid: _.in(teamMembers)
              })
              .get()

            let teamTotalDistance = 0
            for (const run of teamRunResult.data) {
              teamTotalDistance += run.distance || 0
            }

            teamRuns.push({
              teamId: team._id,
              teamName: team.teamName || '未命名队伍',
              totalDistance: teamTotalDistance,
              members: teamMembers
            })
          }
        }

        teamRuns.sort((a, b) => b.totalDistance - a.totalDistance)
        console.log('情侣榜查询结果:', teamRuns.length, '个队伍')
        return teamRuns

      case 'god':
        result = await db.collection('runRecords')
          .orderBy('distance', 'desc')
          .limit(10)
          .get()
        console.log('战神榜查询结果:', result.data ? result.data.length : 0, '条')
        break

      case 'total':
      default:
        result = await db.collection('runRecords')
          .orderBy('distance', 'desc')
          .limit(100)
          .get()
        console.log('总榜查询结果:', result.data ? result.data.length : 0, '条')
        break
    }

    const data = result ? (result.data || []) : []
    
    const avatarFileIDs = []
    const openidSet = new Set()
    for (let i = 0; i < data.length; i++) {
      if (data[i].openid) {
        openidSet.add(data[i].openid)
      }
    }
    
    const openids = Array.from(openidSet)
    let userMap = {}
    
    if (openids.length > 0) {
      const userRes = await db.collection('users').where({
        openid: _.in(openids)
      }).get()
      
      for (let j = 0; j < userRes.data.length; j++) {
        const user = userRes.data[j]
        userMap[user.openid] = {
          nickName: user.nickName || '用户' + user.openid.slice(-6),
          avatarUrl: user.avatarUrl || ''
        }
        if (user.avatarUrl && user.avatarUrl.indexOf('cloud://') === 0) {
          avatarFileIDs.push(user.avatarUrl)
        }
      }
    }
    
    if (avatarFileIDs.length > 0) {
      try {
        const tempUrlRes = await cloud.getTempFileURL({ fileList: avatarFileIDs })
        if (tempUrlRes.fileList && tempUrlRes.fileList.length > 0) {
          for (let k = 0; k < tempUrlRes.fileList.length; k++) {
            const fileItem = tempUrlRes.fileList[k]
            if (fileItem.tempFileURL) {
              for (let openid in userMap) {
                if (userMap[openid].avatarUrl === fileItem.fileID) {
                  userMap[openid].avatarUrl = fileItem.tempFileURL
                }
              }
            }
          }
        }
      } catch (err) {
        console.error('获取头像临时链接失败:', err)
      }
    }
    
    for (let m = 0; m < data.length; m++) {
      const item = data[m]
      if (item.openid && userMap[item.openid]) {
        item.nickName = userMap[item.openid].nickName
        item.avatarUrl = userMap[item.openid].avatarUrl
      } else {
        item.nickName = '用户' + (item.openid ? item.openid.slice(-6) : '')
        item.avatarUrl = ''
      }
    }

    return data
  } catch (error) {
    console.error('获取排行榜数据失败：', error)
    return []
  }
}
