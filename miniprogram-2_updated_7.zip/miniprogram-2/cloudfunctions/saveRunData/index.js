// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

exports.main = async (event, context) => {
  const { isRealtime } = event
  
  if (isRealtime === true) {
    return await saveRealtimeData(event)
  } else {
    return await saveRunRecord(event)
  }
}

async function saveRealtimeData(data) {
  try {
    const { openid, distance, pace, duration, steps, latitude, longitude, isCoupleMode, teamId, timestamp } = data
    
    const realtimeCollection = db.collection('realtimeData')
    
    const existing = await realtimeCollection.where({ openid }).get()
    
    const realtimeRecord = {
      openid,
      distance,
      pace,
      duration,
      steps,
      latitude,
      longitude,
      isCoupleMode,
      teamId,
      timestamp,
      updateTime: db.serverDate()
    }
    
    if (existing.data.length > 0) {
      await realtimeCollection.where({ openid }).update({
        data: realtimeRecord
      })
    } else {
      await realtimeCollection.add({
        data: realtimeRecord
      })
    }
    
    return { success: true }
  } catch (error) {
    console.error('保存实时数据失败：', error)
    return { success: false, errMsg: error.message }
  }
}

async function saveRunRecord(data) {
  try {
    const result = await db.collection('runRecords').add({
      data: {
        _id: data._id,
        distance: data.distance,
        time: data.time,
        date: data.date,
        openid: data.openid,
        nickName: data.nickName,
        avatarUrl: data.avatarUrl,
        pace: data.pace,
        duration: data.duration,
        steps: data.steps,
        motionMode: data.motionMode,
        stepFrequency: data.stepFrequency,
        stepLength: data.stepLength,
        createTime: db.serverDate()
      }
    })
    return { success: true, _id: result._id }
  } catch (error) {
    console.error('保存跑步数据失败：', error)
    return { success: false, errMsg: error.message }
  }
}
