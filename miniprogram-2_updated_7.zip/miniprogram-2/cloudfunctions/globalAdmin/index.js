const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

const db = cloud.database()
const cmd = db.command

// 默认超级管理员（比赛演示用，避免多套后台账号混淆）
const DEFAULT_SUPER_ACCOUNT = '348156572'
const DEFAULT_SUPER_PASSWORD = 'jsx621621'

function md5(str) {
  var crypto = require('crypto')
  return crypto.createHash('md5').update(str).digest('hex')
}

function formatTime(value) {
  if (!value) return ''
  var date
  if (typeof value.toDate === 'function') {
    date = value.toDate()
  } else {
    date = new Date(value)
  }
  var y = date.getFullYear()
  var m = String(date.getMonth() + 1)
  var d = String(date.getDate())
  var hh = String(date.getHours())
  var mm = String(date.getMinutes())
  var ss = String(date.getSeconds())
  if (m.length === 1) m = '0' + m
  if (d.length === 1) d = '0' + d
  if (hh.length === 1) hh = '0' + hh
  if (mm.length === 1) mm = '0' + mm
  if (ss.length === 1) ss = '0' + ss
  return y + '-' + m + '-' + d + ' ' + hh + ':' + mm + ':' + ss
}

async function checkSuperAdmin(openid) {
  var adminRes = await db.collection('global_admin').where({
    bindOpenid: openid,
    role: 'super'
  }).limit(1).get()
  if (!adminRes.data.length) return { isSuperAdmin: false }
  return { isSuperAdmin: true, admin: adminRes.data[0] }
}

async function checkAdmin(openid) {
  var adminRes = await db.collection('global_admin').where({
    bindOpenid: openid,
    status: cmd.neq('disabled')
  }).limit(1).get()
  if (!adminRes.data.length) return { isAdmin: false }
  return { isAdmin: true, admin: adminRes.data[0] }
}

async function addLog(openid, module, action, detail, adminName) {
  try {
    await db.collection('global_admin_log').add({
      data: {
        _openid: openid,
        module: module,
        action: action,
        detail: detail,
        adminName: adminName || '系统',
        createTime: db.serverDate()
      }
    })
  } catch (e) {
    console.error('addLog error:', e)
  }
}

async function getAdminName(openid) {
  try {
    var res = await db.collection('global_admin').where({ bindOpenid: openid }).limit(1).get()
    if (res.data.length) {
      return res.data[0].username || res.data[0].name || res.data[0].account
    }
  } catch (e) {}
  return '管理员'
}

exports.main = async function(event) {
  var wxContext = cloud.getWXContext()
  var openid = wxContext.OPENID
  var action = event.action
  var data = event.data || {}

  try {
    switch (action) {
      case 'initDatabase':
        return await initDatabase()
      case 'login':
        return await adminLogin(data)
      case 'checkLogin':
        return await checkLogin(openid)
      case 'logout':
        return await adminLogout(openid)
      case 'getGlobalSettings':
        return await getGlobalSettings(openid)
      case 'updateGlobalSettings':
        return await updateGlobalSettings(openid, data)
      case 'getModuleList':
        return await getModuleList(openid)
      case 'updateModuleStatus':
        return await updateModuleStatus(openid, data)
      case 'getAdminList':
        return await getAdminList(openid)
      case 'createAdmin':
        return await createAdmin(openid, data)
      case 'updateAdmin':
        return await updateAdmin(openid, data)
      case 'deleteAdmin':
        return await deleteAdmin(openid, data)
      case 'resetAdminPassword':
        return await resetAdminPassword(openid, data)
      case 'resetPasswordWithVerify':
        return await resetPasswordWithVerify(data)
      case 'getOperationLogs':
        return await getOperationLogs(openid, data)
      case 'getAnnouncementList':
        return await getAnnouncementList(openid, data)
      case 'getPublishedAnnouncements':
        return await getPublishedAnnouncements(data)
      case 'createAnnouncement':
        return await createAnnouncement(openid, data)
      case 'updateAnnouncement':
        return await updateAnnouncement(openid, data)
      case 'deleteAnnouncement':
        return await deleteAnnouncement(openid, data)
      case 'getFoodStatistics':
        return await getFoodStatistics(openid)
      case 'getFoodOrders':
        return await getFoodOrders(openid, data)
      case 'updateFoodOrder':
        return await updateFoodOrder(openid, data)
      case 'getFoodMenus':
        return await getFoodMenus(openid, data)
      case 'createFoodMenu':
        return await createFoodMenu(openid, data)
      case 'updateFoodMenu':
        return await updateFoodMenu(openid, data)
      case 'deleteFoodMenu':
        return await deleteFoodMenu(openid, data)
      case 'getFoodCategories':
        return await getFoodCategories(openid)
      case 'createFoodCategory':
        return await createFoodCategory(openid, data)
      case 'updateFoodCategory':
        return await updateFoodCategory(openid, data)
      case 'deleteFoodCategory':
        return await deleteFoodCategory(openid, data)
      case 'getPosts':
        return await getPosts(openid, data)
      case 'deletePost':
        return await deletePost(openid, data)
      case 'batchDeletePosts':
        return await batchDeletePosts(openid, data)
      case 'getUsers':
        return await getUsers(openid, data)
      case 'updateUser':
        return await updateUser(openid, data)
      case 'getStorageInfo':
        return await getStorageInfo(openid)
      case 'cleanOldPosts':
        return await cleanOldPosts(openid, data)
      case 'cleanDeletedPosts':
        return await cleanDeletedPosts(openid)
      case 'cleanOrphanImages':
        return await cleanOrphanImages(openid)
      case 'getDashboardStats':
        return await getDashboardStats(openid)
      case 'getRankList':
        return await getRankList(openid, data)
      case 'clearRankRecords':
        return await clearRankRecords(openid, data)
      case 'getShopAuditList':
        return await getShopAuditList(openid, data)
      case 'auditShop':
        return await auditShop(openid, data)
      case 'getShopManageList':
        return await getShopManageList(openid, data)
      case 'initTestData':
        return await initTestData(openid)
      case 'adminUpdateShopStatus':
        return await adminUpdateShopStatus(openid, data)
      case 'adminUpdateShopInfo':
        return await adminUpdateShopInfo(openid, data)
      case 'adminUpdateShopAccount':
        return await adminUpdateShopAccount(openid, data)
      case 'adminResetShopPassword':
        return await adminResetShopPassword(openid, data)
      case 'getShopLogs':
        return await getShopLogs(openid, data)
      case 'getShopDishes':
        return await getShopDishes(openid, data)
      case 'getReports':
        return await getReports(openid, data)
      case 'handleReport':
        return await handleReport(openid, data)
      case 'getForumCategories':
        return await getForumCategories(openid)
      case 'updatePostStatus':
        return await updatePostStatus(openid, data)
      case 'setPostTop':
        return await setPostTop(openid, data)
      case 'setPostEssence':
        return await setPostEssence(openid, data)
      default:
        return { code: -1, message: 'Unknown action: ' + action }
    }
  } catch (error) {
    console.error('Global admin cloud function error:', error)
    return { code: -1, message: error.message || '服务异常', error: error.toString() }
  }
}

async function initDatabase() {
  var results = []
  var collections = ['global_admin', 'global_settings', 'global_admin_log', 'global_announcement', 'global_module', 'food_category', 'food_shop', 'food_shop_user', 'food_dish', 'food_order', 'food_shop_logs', 'food_rider', 'forum_post', 'forum_comment', 'forum_report', 'forum_admin', 'run_stats', 'user']
  
  for (var i = 0; i < collections.length; i++) {
    var name = collections[i]
    try {
      await db.createCollection(name)
      results.push({ name: name, status: 'created' })
    } catch (err) {
      if (err.message && err.message.indexOf('already exists') !== -1) {
        results.push({ name: name, status: 'exists' })
      } else {
        results.push({ name: name, status: 'error', msg: err.message })
      }
    }
  }

  // 初始化/重置默认超级管理员账号（比赛演示用）
  var superAdminPassword = md5(DEFAULT_SUPER_PASSWORD)
  var existingAdmin = await db.collection('global_admin').where({ account: DEFAULT_SUPER_ACCOUNT }).get()
  if (!existingAdmin.data.length) {
    await db.collection('global_admin').add({
      data: {
        account: DEFAULT_SUPER_ACCOUNT,
        password: superAdminPassword,
        username: '超级管理员',
        role: 'super',
        permissions: ['all'],
        status: 'active',
        verifyPassword: md5(DEFAULT_SUPER_PASSWORD),
        bindOpenid: cloud.getWXContext().OPENID,
        createTime: db.serverDate(),
        lastLoginTime: null
      }
    })
    results.push({ name: 'super_admin', status: 'created', account: DEFAULT_SUPER_ACCOUNT, password: DEFAULT_SUPER_PASSWORD })
  } else {
    await db.collection('global_admin').where({ account: DEFAULT_SUPER_ACCOUNT }).update({
      data: {
        password: superAdminPassword,
        verifyPassword: md5(DEFAULT_SUPER_PASSWORD),
        bindOpenid: cloud.getWXContext().OPENID
      }
    })
    results.push({ name: 'super_admin', status: 'updated', account: DEFAULT_SUPER_ACCOUNT, password: DEFAULT_SUPER_PASSWORD })
  }

  var existingSettings = await db.collection('global_settings').limit(1).get()
  if (!existingSettings.data.length) {
    await db.collection('global_settings').add({
      data: {
        appName: '智慧校园',
        logo: '',
        modules: {
          running: { enabled: true, name: '校园跑' },
          food: { enabled: true, name: '食堂点餐' },
          forum: { enabled: true, name: '校园论坛' },
          rider: { enabled: true, name: '骑手兼职' }
        },
        announcements: [],
        createTime: db.serverDate(),
        updateTime: db.serverDate()
      }
    })
    results.push({ name: 'global_settings', status: 'initialized' })
  }

  return { code: 0, message: '数据库初始化完成', data: { results: results } }
}

async function adminLogin(data) {
  var account = data.account
  var password = data.password
  
  if (!account || !password) {
    return { code: -1, message: '请输入账号和密码' }
  }

  var encryptedPwd = md5(password)
  var adminRes = await db.collection('global_admin').where({
    account: account,
    password: encryptedPwd
  }).limit(1).get()

  // 若未初始化，但输入默认超级管理员账号/密码，则自动创建/重置，避免误以为“账号密码错误”
  if (!adminRes.data.length && account === DEFAULT_SUPER_ACCOUNT && password === DEFAULT_SUPER_PASSWORD) {
    var ensureRes = await db.collection('global_admin').where({ account: DEFAULT_SUPER_ACCOUNT }).limit(1).get()
    if (!ensureRes.data.length) {
      await db.collection('global_admin').add({
        data: {
          account: DEFAULT_SUPER_ACCOUNT,
          password: md5(DEFAULT_SUPER_PASSWORD),
          username: '超级管理员',
          role: 'super',
          permissions: ['all'],
          status: 'active',
          verifyPassword: md5(DEFAULT_SUPER_PASSWORD),
          bindOpenid: cloud.getWXContext().OPENID,
          createTime: db.serverDate(),
          lastLoginTime: null
        }
      })
    } else {
      await db.collection('global_admin').doc(ensureRes.data[0]._id).update({
        data: {
          password: md5(DEFAULT_SUPER_PASSWORD),
          verifyPassword: md5(DEFAULT_SUPER_PASSWORD),
          status: 'active',
          bindOpenid: cloud.getWXContext().OPENID,
          updateTime: db.serverDate()
        }
      })
    }
    adminRes = await db.collection('global_admin').where({
      account: DEFAULT_SUPER_ACCOUNT,
      password: md5(DEFAULT_SUPER_PASSWORD)
    }).limit(1).get()
  }

  if (!adminRes.data.length) return { code: -1, message: '账号或密码错误' }

  var admin = adminRes.data[0]
  
  if (admin.status === 'disabled') {
    return { code: -1, message: '该账号已被禁用' }
  }

  await db.collection('global_admin').doc(admin._id).update({
    data: {
      lastLoginTime: db.serverDate(),
      bindOpenid: cloud.getWXContext().OPENID
    }
  })

  await addLog(cloud.getWXContext().OPENID, 'admin', 'login', '管理员登录：' + account, admin.username || account)

  return {
    code: 0,
    message: '登录成功',
    data: {
      admin: {
        _id: admin._id,
        account: admin.account,
        username: admin.username || admin.name,
        role: admin.role,
        permissions: admin.permissions
      }
    }
  }
}

async function checkLogin(openid) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '未登录或账号已被禁用' }
  }
  
  return {
    code: 0,
    data: {
      admin: {
        _id: adminCheck.admin._id,
        account: adminCheck.admin.account,
        username: adminCheck.admin.username || adminCheck.admin.name,
        role: adminCheck.admin.role,
        permissions: adminCheck.admin.permissions
      }
    }
  }
}

async function adminLogout(openid) {
  var adminName = await getAdminName(openid)
  await addLog(openid, 'admin', 'logout', '管理员退出登录', adminName)
  return { code: 0, message: '已退出登录' }
}

async function getGlobalSettings(openid) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var settingsRes = await db.collection('global_settings').limit(1).get()
  if (!settingsRes.data.length) {
    return {
      code: 0,
      data: {
        appName: '智慧校园',
        logo: '',
        modules: {
          running: { enabled: true, name: '校园跑' },
          food: { enabled: true, name: '食堂点餐' },
          forum: { enabled: true, name: '校园论坛' },
          rider: { enabled: true, name: '骑手兼职' }
        }
      }
    }
  }

  return { code: 0, data: settingsRes.data[0] }
}

async function updateGlobalSettings(openid, data) {
  var adminCheck = await checkSuperAdmin(openid)
  if (!adminCheck.isSuperAdmin) {
    return { code: -1, message: '仅超级管理员可修改全局设置' }
  }

  var adminName = await getAdminName(openid)
  var settingsRes = await db.collection('global_settings').limit(1).get()
  
  if (settingsRes.data.length) {
    await db.collection('global_settings').doc(settingsRes.data[0]._id).update({
      data: {
        appName: data.appName,
        logo: data.logo,
        modules: data.modules,
        contactEmail: data.contactEmail,
        contactPhone: data.contactPhone,
        copyright: data.copyright,
        postReview: data.postReview,
        sensitiveWords: data.sensitiveWords,
        userRegister: data.userRegister,
        notifications: data.notifications,
        autoCleanup: data.autoCleanup,
        imageLimit: data.imageLimit,
        themeColor: data.themeColor,
        updateTime: db.serverDate()
      }
    })
  } else {
    await db.collection('global_settings').add({
      data: {
        appName: data.appName,
        logo: data.logo,
        modules: data.modules,
        createTime: db.serverDate(),
        updateTime: db.serverDate()
      }
    })
  }

  await addLog(openid, 'system', 'update', '更新全局设置', adminName)
  return { code: 0, message: '设置已保存' }
}

async function getModuleList(openid) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var settingsRes = await db.collection('global_settings').limit(1).get()
  var modules = {
    running: { key: 'running', name: '校园跑', enabled: true, icon: 'running' },
    food: { key: 'food', name: '食堂点餐', enabled: true, icon: 'utensils' },
    forum: { key: 'forum', name: '校园论坛', enabled: true, icon: 'comments' },
    rider: { key: 'rider', name: '骑手兼职', enabled: true, icon: 'motorcycle' }
  }

  if (settingsRes.data.length && settingsRes.data[0].modules) {
    var savedModules = settingsRes.data[0].modules
    for (var key in savedModules) {
      if (modules[key]) {
        modules[key].enabled = savedModules[key].enabled !== false
        if (savedModules[key].name) {
          modules[key].name = savedModules[key].name
        }
      }
    }
  }

  return { code: 0, data: { list: Object.values(modules) } }
}

async function updateModuleStatus(openid, data) {
  var adminCheck = await checkSuperAdmin(openid)
  if (!adminCheck.isSuperAdmin) {
    return { code: -1, message: '仅超级管理员可修改模块状态' }
  }

  var adminName = await getAdminName(openid)
  var moduleKey = data.module
  var enabled = data.enabled

  var settingsRes = await db.collection('global_settings').limit(1).get()
  var modules = {}
  
  if (settingsRes.data.length && settingsRes.data[0].modules) {
    modules = settingsRes.data[0].modules
  } else {
    modules = {
      running: { enabled: true, name: '校园跑' },
      food: { enabled: true, name: '食堂点餐' },
      forum: { enabled: true, name: '校园论坛' }
    }
  }

  if (modules[moduleKey]) {
    modules[moduleKey].enabled = enabled
  }

  if (settingsRes.data.length) {
    await db.collection('global_settings').doc(settingsRes.data[0]._id).update({
      data: { modules: modules, updateTime: db.serverDate() }
    })
  } else {
    await db.collection('global_settings').add({
      data: {
        modules: modules,
        createTime: db.serverDate(),
        updateTime: db.serverDate()
      }
    })
  }

  await addLog(openid, 'system', 'update', (enabled ? '启用' : '禁用') + '模块：' + moduleKey, adminName)
  return { code: 0, message: enabled ? '模块已启用' : '模块已禁用' }
}

async function getAdminList(openid) {
  var adminCheck = await checkSuperAdmin(openid)
  if (!adminCheck.isSuperAdmin) {
    return { code: -1, message: '仅超级管理员可查看管理员列表' }
  }

  var res = await db.collection('global_admin')
    .orderBy('createTime', 'desc')
    .get()

  var admins = res.data.map(function(item) {
    return {
      _id: item._id,
      account: item.account,
      username: item.username || item.name,
      role: item.role,
      permissions: item.permissions,
      status: item.status,
      createTime: item.createTime,
      lastLoginTime: item.lastLoginTime
    }
  })

  return { code: 0, data: { list: admins } }
}

async function createAdmin(openid, data) {
  var adminCheck = await checkSuperAdmin(openid)
  if (!adminCheck.isSuperAdmin) {
    return { code: -1, message: '仅超级管理员可创建管理员' }
  }

  var adminName = await getAdminName(openid)
  var account = data.account
  var password = data.password
  var username = data.username
  var role = data.role || 'normal'
  var permissions = data.permissions || []

  if (!account || !password || !username) {
    return { code: -1, message: '请填写完整信息' }
  }

  var existingAdmin = await db.collection('global_admin').where({ account: account }).get()
  if (existingAdmin.data.length) {
    return { code: -1, message: '账号已存在' }
  }

  await db.collection('global_admin').add({
    data: {
      account: account,
      password: md5(password),
      username: username,
      role: role,
      permissions: permissions,
      status: 'active',
      createTime: db.serverDate(),
      lastLoginTime: null
    }
  })

  await addLog(openid, 'admin', 'create', '创建管理员：' + account, adminName)
  return { code: 0, message: '管理员创建成功' }
}

async function updateAdmin(openid, data) {
  var adminCheck = await checkSuperAdmin(openid)
  if (!adminCheck.isSuperAdmin) {
    return { code: -1, message: '仅超级管理员可修改管理员' }
  }

  var adminName = await getAdminName(openid)
  var adminId = data.id
  var username = data.username
  var role = data.role
  var permissions = data.permissions
  var status = data.status

  if (!adminId) {
    return { code: -1, message: '管理员ID缺失' }
  }

  var targetAdmin = await db.collection('global_admin').doc(adminId).get()
  if (!targetAdmin.data) {
    return { code: -1, message: '管理员不存在' }
  }

  if (targetAdmin.data.role === 'super') {
    return { code: -1, message: '不能修改超级管理员' }
  }

  var updateData = { updateTime: db.serverDate() }
  if (username) updateData.username = username
  if (role) updateData.role = role
  if (permissions) updateData.permissions = permissions
  if (status) updateData.status = status

  await db.collection('global_admin').doc(adminId).update({ data: updateData })

  await addLog(openid, 'admin', 'update', '修改管理员：' + targetAdmin.data.account, adminName)
  return { code: 0, message: '管理员信息已更新' }
}

async function deleteAdmin(openid, data) {
  var adminCheck = await checkSuperAdmin(openid)
  if (!adminCheck.isSuperAdmin) {
    return { code: -1, message: '仅超级管理员可删除管理员' }
  }

  var adminName = await getAdminName(openid)
  var adminId = data.id
  if (!adminId) {
    return { code: -1, message: '管理员ID缺失' }
  }

  var targetAdmin = await db.collection('global_admin').doc(adminId).get()
  if (!targetAdmin.data) {
    return { code: -1, message: '管理员不存在' }
  }

  if (targetAdmin.data.role === 'super') {
    return { code: -1, message: '不能删除超级管理员' }
  }

  await db.collection('global_admin').doc(adminId).remove()

  await addLog(openid, 'admin', 'delete', '删除管理员：' + targetAdmin.data.account, adminName)
  return { code: 0, message: '管理员已删除' }
}

async function resetAdminPassword(openid, data) {
  var adminCheck = await checkSuperAdmin(openid)
  if (!adminCheck.isSuperAdmin) {
    return { code: -1, message: '仅超级管理员可重置密码' }
  }

  var adminName = await getAdminName(openid)
  var adminId = data.id
  var newPassword = data.newPassword

  if (!adminId || !newPassword) {
    return { code: -1, message: '参数缺失' }
  }

  var targetAdmin = await db.collection('global_admin').doc(adminId).get()
  if (!targetAdmin.data) {
    return { code: -1, message: '管理员不存在' }
  }

  await db.collection('global_admin').doc(adminId).update({
    data: { password: md5(newPassword) }
  })

  await addLog(openid, 'admin', 'update', '重置管理员密码：' + targetAdmin.data.account, adminName)
  return { code: 0, message: '密码已重置' }
}

async function resetPasswordWithVerify(data) {
  var account = data.account
  var verifyPassword = data.verifyPassword
  var newPassword = data.newPassword

  if (!account || !verifyPassword || !newPassword) {
    return { code: -1, message: '参数缺失' }
  }

  var adminRes = await db.collection('global_admin').where({
    account: account
  }).limit(1).get()

  if (!adminRes.data.length) {
    return { code: -1, message: '账号不存在' }
  }

  var admin = adminRes.data[0]
  var encryptedVerify = md5(verifyPassword)

  if (admin.verifyPassword !== encryptedVerify) {
    return { code: -1, message: '辅助验证密码错误' }
  }

  await db.collection('global_admin').doc(admin._id).update({
    data: { password: md5(newPassword) }
  })

  await addLog('', 'admin', 'update', '通过验证重置密码：' + account, account)
  return { code: 0, message: '密码重置成功' }
}

async function getOperationLogs(openid, data) {
  var adminCheck = await checkSuperAdmin(openid)
  if (!adminCheck.isSuperAdmin) {
    return { code: -1, message: '仅超级管理员可查看操作日志' }
  }

  if (data.stats) {
    var totalRes = await db.collection('global_admin_log').count()
    var deleteRes = await db.collection('global_admin_log').where({ action: 'delete' }).count()
    var createRes = await db.collection('global_admin_log').where({ action: 'create' }).count()
    var updateRes = await db.collection('global_admin_log').where({ action: 'update' }).count()
    
    return {
      code: 0,
      data: {
        stats: {
          total: totalRes.total,
          delete: deleteRes.total,
          create: createRes.total,
          update: updateRes.total
        }
      }
    }
  }

  var page = data.page || 1
  var pageSize = data.pageSize || 20
  var skip = (page - 1) * pageSize

  var query = {}
  if (data.module) query.module = data.module
  if (data.action) query.action = data.action

  var totalRes = await db.collection('global_admin_log').where(query).count()
  
  var res = await db.collection('global_admin_log')
    .where(query)
    .orderBy('createTime', 'desc')
    .skip(skip)
    .limit(pageSize)
    .get()

  var logs = res.data.map(function(item) {
    return {
      _id: item._id,
      module: item.module,
      action: item.action,
      detail: item.detail,
      adminName: item.adminName,
      ip: item.ip,
      createTime: item.createTime
    }
  })

  return { code: 0, data: { list: logs, total: totalRes.total } }
}

async function getAnnouncementList(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  if (data.id) {
    var singleRes = await db.collection('global_announcement').doc(data.id).get()
    if (singleRes.data) {
      return { code: 0, data: singleRes.data }
    }
    return { code: -1, message: '公告不存在' }
  }

  if (data.stats) {
    var totalRes = await db.collection('global_announcement').count()
    var publishedRes = await db.collection('global_announcement').where({ status: 'published' }).count()
    var draftRes = await db.collection('global_announcement').where({ status: 'draft' }).count()
    
    var viewsRes = await db.collection('global_announcement').get()
    var totalViews = 0
    for (var i = 0; i < viewsRes.data.length; i++) {
      totalViews += viewsRes.data[i].views || 0
    }
    
    return {
      code: 0,
      data: {
        stats: {
          total: totalRes.total,
          published: publishedRes.total,
          draft: draftRes.total,
          views: totalViews
        }
      }
    }
  }

  var page = data.page || 1
  var pageSize = data.pageSize || 20
  var skip = (page - 1) * pageSize

  var query = {}
  if (data.type) query.type = data.type
  if (data.status) query.status = data.status

  var totalRes = await db.collection('global_announcement').where(query).count()
  
  var res = await db.collection('global_announcement')
    .where(query)
    .orderBy('createTime', 'desc')
    .skip(skip)
    .limit(pageSize)
    .get()

  var announcements = res.data.map(function(item) {
    return {
      _id: item._id,
      title: item.title,
      content: item.content,
      type: item.type,
      isTop: item.isTop,
      isImportant: item.isImportant,
      status: item.status,
      cover: item.cover,
      views: item.views || 0,
      createTime: item.createTime,
      startTime: item.startTime,
      endTime: item.endTime
    }
  })

  return { code: 0, data: { list: announcements, total: totalRes.total } }
}

// 用户端公告（不需要管理员权限）：仅返回已发布公告，用于弹窗展示
async function getPublishedAnnouncements(data) {
  var page = (data && data.page) ? data.page : 1
  var pageSize = (data && data.pageSize) ? data.pageSize : 1
  var skip = (page - 1) * pageSize

  var query = { status: 'published' }
  if (data && data.type) query.type = data.type

  var totalRes = await db.collection('global_announcement').where(query).count()
  var res = await db.collection('global_announcement')
    .where(query)
    .orderBy('createTime', 'desc')
    .skip(skip)
    .limit(pageSize)
    .get()

  var list = res.data.map(function(item) {
    return {
      _id: item._id,
      title: item.title,
      content: item.content,
      type: item.type,
      isTop: item.isTop,
      isImportant: item.isImportant,
      cover: item.cover,
      views: item.views || 0,
      createTime: item.createTime
    }
  })

  return { code: 0, data: { list: list, total: totalRes.total } }
}

async function createAnnouncement(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var adminName = await getAdminName(openid)
  var title = data.title
  var content = data.content
  var type = data.type || 'notice'

  if (!title || !content) {
    return { code: -1, message: '请填写标题和内容' }
  }

  await db.collection('global_announcement').add({
    data: {
      title: title,
      content: content,
      type: type,
      isTop: data.isTop === true,
      isImportant: data.isImportant === true,
      status: data.status || 'published',
      cover: data.cover || '',
      views: 0,
      startTime: data.startTime || null,
      endTime: data.endTime || null,
      createTime: db.serverDate()
    }
  })

  await addLog(openid, 'system', 'create', '发布公告：' + title, adminName)
  return { code: 0, message: '公告发布成功' }
}

async function updateAnnouncement(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var adminName = await getAdminName(openid)
  var announcementId = data.id

  if (!announcementId) {
    return { code: -1, message: '公告ID缺失' }
  }

  var updateData = {}
  if (data.title) updateData.title = data.title
  if (data.content) updateData.content = data.content
  if (data.type) updateData.type = data.type
  if (data.isTop !== undefined) updateData.isTop = data.isTop
  if (data.isImportant !== undefined) updateData.isImportant = data.isImportant
  if (data.status) updateData.status = data.status
  if (data.cover !== undefined) updateData.cover = data.cover
  if (data.startTime !== undefined) updateData.startTime = data.startTime
  if (data.endTime !== undefined) updateData.endTime = data.endTime
  updateData.updateTime = db.serverDate()

  await db.collection('global_announcement').doc(announcementId).update({
    data: updateData
  })

  await addLog(openid, 'system', 'update', '更新公告', adminName)
  return { code: 0, message: '公告已更新' }
}

async function deleteAnnouncement(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var adminName = await getAdminName(openid)
  var announcementId = data.id
  if (!announcementId) {
    return { code: -1, message: '公告ID缺失' }
  }

  await db.collection('global_announcement').doc(announcementId).remove()

  await addLog(openid, 'system', 'delete', '删除公告', adminName)
  return { code: 0, message: '公告已删除' }
}

async function getFoodStatistics(openid) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var today = new Date()
  today.setHours(0, 0, 0, 0)
  var todayStart = today.getTime()

  var todayOrders = await db.collection('food_order')
    .where({ createTime: cmd.gte(new Date(todayStart)) })
    .count()

  var totalOrders = await db.collection('food_order').count()

  var todayOrdersData = await db.collection('food_order')
    .where({ createTime: cmd.gte(new Date(todayStart)) })
    .get()

  var todayRevenue = 0
  for (var i = 0; i < todayOrdersData.data.length; i++) {
    todayRevenue += todayOrdersData.data[i].totalPrice || 0
  }

  var allOrdersData = await db.collection('food_order').get()
  var totalRevenue = 0
  for (var j = 0; j < allOrdersData.data.length; j++) {
    totalRevenue += allOrdersData.data[j].totalPrice || 0
  }

  var menuCount = await db.collection('food_menu').count()
  var pendingShops = await db.collection('food_shop').where({ auditStatus: 'pending' }).count()
  var totalShops = await db.collection('food_shop').where({ auditStatus: 'approved' }).count()

  return {
    code: 0,
    data: {
      todayOrders: todayOrders.total,
      totalOrders: totalOrders.total,
      todayRevenue: todayRevenue,
      totalRevenue: totalRevenue,
      menuCount: menuCount.total,
      pendingShops: pendingShops.total,
      totalShops: totalShops.total
    }
  }
}

async function getFoodOrders(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var page = data.page || 1
  var pageSize = data.pageSize || 20
  var status = data.status
  var skip = (page - 1) * pageSize

  var query = {}
  if (status) query.status = status

  var totalRes = await db.collection('food_order').where(query).count()
  
  var res = await db.collection('food_order')
    .where(query)
    .orderBy('createTime', 'desc')
    .skip(skip)
    .limit(pageSize)
    .get()

  var orders = res.data.map(function(item) {
    return {
      _id: item._id,
      orderNo: item.orderNo,
      userName: item.userName,
      userPhone: item.userPhone,
      totalPrice: item.totalPrice,
      status: item.status,
      items: item.items,
      createTime: item.createTime,
      pickupTime: item.pickupTime,
      remark: item.remark
    }
  })

  return { code: 0, data: { list: orders, total: totalRes.total } }
}

async function updateFoodOrder(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var adminName = await getAdminName(openid)
  var orderId = data.id
  var updateData = JSON.parse(JSON.stringify(data))

  if (!orderId) {
    return { code: -1, message: '订单ID缺失' }
  }

  delete updateData.id
  delete updateData.action

  await db.collection('food_order').doc(orderId).update({
    data: updateData
  })

  await addLog(openid, 'food', 'update', '更新订单：' + orderId, adminName)
  return { code: 0, message: '订单已更新' }
}

async function getFoodMenus(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  if (data.id) {
    var singleRes = await db.collection('food_menu').doc(data.id).get()
    if (singleRes.data) {
      return { code: 0, data: singleRes.data }
    }
    return { code: -1, message: '菜品不存在' }
  }

  var page = data.page || 1
  var pageSize = data.pageSize || 20
  var skip = (page - 1) * pageSize

  var query = {}
  if (data.categoryId) query.categoryId = data.categoryId
  if (data.status) query.status = data.status === 'available'

  var totalRes = await db.collection('food_menu').where(query).count()
  
  var res = await db.collection('food_menu')
    .where(query)
    .orderBy('sort', 'asc')
    .orderBy('createTime', 'desc')
    .skip(skip)
    .limit(pageSize)
    .get()

  var menus = res.data.map(function(item) {
    return {
      _id: item._id,
      name: item.name,
      price: item.price,
      originalPrice: item.originalPrice,
      categoryId: item.categoryId,
      image: item.image,
      description: item.description,
      status: item.status,
      stock: item.stock,
      sales: item.sales || 0,
      recommend: item.recommend,
      sort: item.sort || 0,
      createTime: item.createTime
    }
  })

  return { code: 0, data: { list: menus, total: totalRes.total } }
}

async function createFoodMenu(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var adminName = await getAdminName(openid)

  if (!data.name || !data.price) {
    return { code: -1, message: '请填写菜品名称和价格' }
  }

  await db.collection('food_menu').add({
    data: {
      name: data.name,
      price: data.price,
      originalPrice: data.originalPrice || null,
      categoryId: data.categoryId || '',
      image: data.image || '',
      description: data.description || '',
      status: data.status !== false,
      stock: data.stock || 999,
      sales: 0,
      recommend: data.recommend === true,
      sort: data.sort || 0,
      createTime: db.serverDate()
    }
  })

  await addLog(openid, 'food', 'create', '创建菜品：' + data.name, adminName)
  return { code: 0, message: '菜品创建成功' }
}

async function updateFoodMenu(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var adminName = await getAdminName(openid)
  var menuId = data.id

  if (!menuId) {
    return { code: -1, message: '菜品ID缺失' }
  }

  var updateData = {}
  if (data.name) updateData.name = data.name
  if (data.price !== undefined) updateData.price = data.price
  if (data.originalPrice !== undefined) updateData.originalPrice = data.originalPrice
  if (data.categoryId !== undefined) updateData.categoryId = data.categoryId
  if (data.image !== undefined) updateData.image = data.image
  if (data.description !== undefined) updateData.description = data.description
  if (data.status !== undefined) updateData.status = data.status
  if (data.stock !== undefined) updateData.stock = data.stock
  if (data.recommend !== undefined) updateData.recommend = data.recommend
  if (data.sort !== undefined) updateData.sort = data.sort
  updateData.updateTime = db.serverDate()

  await db.collection('food_menu').doc(menuId).update({
    data: updateData
  })

  await addLog(openid, 'food', 'update', '更新菜品：' + menuId, adminName)
  return { code: 0, message: '菜品已更新' }
}

async function deleteFoodMenu(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var adminName = await getAdminName(openid)
  var menuId = data.id
  if (!menuId) {
    return { code: -1, message: '菜品ID缺失' }
  }

  await db.collection('food_menu').doc(menuId).remove()

  await addLog(openid, 'food', 'delete', '删除菜品：' + menuId, adminName)
  return { code: 0, message: '菜品已删除' }
}

async function getFoodCategories(openid) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var res = await db.collection('food_category')
    .orderBy('sort', 'asc')
    .get()

  var categories = res.data.map(function(item) {
    return {
      _id: item._id,
      name: item.name,
      sort: item.sort || 0,
      status: item.status !== false,
      count: item.count || 0
    }
  })

  return { code: 0, data: categories }
}

async function createFoodCategory(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var adminName = await getAdminName(openid)

  if (!data.name) {
    return { code: -1, message: '请输入分类名称' }
  }

  await db.collection('food_category').add({
    data: {
      name: data.name,
      sort: data.sort || 0,
      status: data.status !== false,
      count: 0,
      createTime: db.serverDate()
    }
  })

  await addLog(openid, 'food', 'create', '创建分类：' + data.name, adminName)
  return { code: 0, message: '分类创建成功' }
}

async function updateFoodCategory(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var adminName = await getAdminName(openid)
  var categoryId = data.id

  if (!categoryId) {
    return { code: -1, message: '分类ID缺失' }
  }

  var updateData = {}
  if (data.name) updateData.name = data.name
  if (data.sort !== undefined) updateData.sort = data.sort
  if (data.status !== undefined) updateData.status = data.status
  updateData.updateTime = db.serverDate()

  await db.collection('food_category').doc(categoryId).update({
    data: updateData
  })

  await addLog(openid, 'food', 'update', '更新分类：' + categoryId, adminName)
  return { code: 0, message: '分类已更新' }
}

async function deleteFoodCategory(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var adminName = await getAdminName(openid)
  var categoryId = data.id
  if (!categoryId) {
    return { code: -1, message: '分类ID缺失' }
  }

  await db.collection('food_menu').where({ categoryId: categoryId }).update({
    data: { categoryId: '' }
  })

  await db.collection('food_category').doc(categoryId).remove()

  await addLog(openid, 'food', 'delete', '删除分类：' + categoryId, adminName)
  return { code: 0, message: '分类已删除' }
}

async function getPosts(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var page = data.page || 1
  var pageSize = data.pageSize || 20
  var skip = (page - 1) * pageSize

  var query = { status: cmd.neq('deleted') }
  if (data.status) query.status = data.status
  if (data.category) query.category = data.category

  var totalRes = await db.collection('forum_post').where(query).count()
  
  var res = await db.collection('forum_post')
    .where(query)
    .orderBy('createTime', 'desc')
    .skip(skip)
    .limit(pageSize)
    .get()

  var posts = res.data.map(function(item) {
    return {
      _id: item._id,
      title: item.title,
      content: item.content,
      authorName: item.authorName || item.nickName,
      authorAvatar: item.authorAvatar || item.avatarUrl,
      authorOpenid: item._openid,
      images: item.images || [],
      likes: item.likes || 0,
      comments: item.comments || 0,
      category: item.category,
      status: item.status || 'normal',
      isTop: item.isTop === true,
      isEssence: item.isEssence === true,
      createTime: item.createTime
    }
  })

  return { code: 0, data: { list: posts, total: totalRes.total } }
}

async function deletePost(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var adminName = await getAdminName(openid)
  var postId = data.id
  if (!postId) {
    return { code: -1, message: '帖子ID缺失' }
  }

  await db.collection('forum_post').doc(postId).remove()

  await addLog(openid, 'forum', 'delete', '删除帖子：' + postId, adminName)
  return { code: 0, message: '帖子已删除' }
}

async function batchDeletePosts(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var adminName = await getAdminName(openid)
  var postIds = data.ids
  if (!postIds || !postIds.length) {
    return { code: -1, message: '请选择要删除的帖子' }
  }

  var deletedCount = 0
  for (var i = 0; i < postIds.length; i++) {
    try {
      await db.collection('forum_post').doc(postIds[i]).remove()
      deletedCount++
    } catch (e) {
      console.error('delete post error:', e)
    }
  }

  await addLog(openid, 'forum', 'delete', '批量删除帖子：' + deletedCount + '条', adminName)
  return { code: 0, message: '已删除 ' + deletedCount + ' 条帖子', data: { deletedCount: deletedCount } }
}

async function updatePostStatus(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var adminName = await getAdminName(openid)
  var postId = data.id
  var status = data.status

  if (!postId || !status) {
    return { code: -1, message: '参数缺失' }
  }

  await db.collection('forum_post').doc(postId).update({
    data: { status: status, updateTime: db.serverDate() }
  })

  await addLog(openid, 'forum', 'update', '更新帖子状态：' + postId + ' -> ' + status, adminName)
  return { code: 0, message: '状态已更新' }
}

async function setPostTop(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var adminName = await getAdminName(openid)
  var postId = data.id
  var isTop = data.isTop === true

  if (!postId) {
    return { code: -1, message: '帖子ID缺失' }
  }

  await db.collection('forum_post').doc(postId).update({
    data: { isTop: isTop, updateTime: db.serverDate() }
  })

  await addLog(openid, 'forum', 'update', (isTop ? '置顶' : '取消置顶') + '帖子：' + postId, adminName)
  return { code: 0, message: isTop ? '已置顶' : '已取消置顶' }
}

async function setPostEssence(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var adminName = await getAdminName(openid)
  var postId = data.id
  var isEssence = data.isEssence === true

  if (!postId) {
    return { code: -1, message: '帖子ID缺失' }
  }

  await db.collection('forum_post').doc(postId).update({
    data: { isEssence: isEssence, updateTime: db.serverDate() }
  })

  await addLog(openid, 'forum', 'update', (isEssence ? '设为精华' : '取消精华') + '帖子：' + postId, adminName)
  return { code: 0, message: isEssence ? '已设为精华' : '已取消精华' }
}

async function getUsers(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var page = data.page || 1
  var pageSize = data.pageSize || 20
  var skip = (page - 1) * pageSize

  var query = {}
  if (data.status) query.status = data.status
  if (data.keyword) {
    query.nickName = db.RegExp({ regexp: data.keyword, options: 'i' })
  }

  var totalRes = await db.collection('users').where(query).count()
  
  var res = await db.collection('users')
    .where(query)
    .orderBy('createTime', 'desc')
    .skip(skip)
    .limit(pageSize)
    .get()

  var users = res.data.map(function(item) {
    return {
      _id: item._id,
      nickName: item.nickName,
      avatarUrl: item.avatarUrl,
      gender: item.gender,
      city: item.city,
      province: item.province,
      status: item.status || 'normal',
      lastLoginTime: item.lastLoginTime,
      createTime: item.createTime
    }
  })

  return { code: 0, data: { list: users, total: totalRes.total } }
}

async function updateUser(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var adminName = await getAdminName(openid)
  var userId = data.id
  if (!userId) {
    return { code: -1, message: '用户ID缺失' }
  }

  var updateData = {}
  if (data.status) updateData.status = data.status
  if (data.nickName) updateData.nickName = data.nickName
  updateData.updateTime = db.serverDate()

  await db.collection('users').doc(userId).update({
    data: updateData
  })

  await addLog(openid, 'admin', 'update', '更新用户：' + userId, adminName)
  return { code: 0, message: '用户信息已更新' }
}

async function getStorageInfo(openid) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  return {
    code: 0,
    data: {
      used: 0,
      total: 5120
    }
  }
}

async function cleanOldPosts(openid, data) {
  var adminCheck = await checkSuperAdmin(openid)
  if (!adminCheck.isSuperAdmin) {
    return { code: -1, message: '仅超级管理员可执行清理操作' }
  }

  var adminName = await getAdminName(openid)
  var days = data.days || 30
  var cutoffDate = new Date()
  cutoffDate.setDate(cutoffDate.getDate() - days)

  var res = await db.collection('forum_post')
    .where({
      createTime: cmd.lt(cutoffDate)
    })
    .get()

  var deletedCount = 0
  for (var i = 0; i < res.data.length; i++) {
    try {
      await db.collection('forum_post').doc(res.data[i]._id).remove()
      deletedCount++
    } catch (e) {
      console.error('delete error:', e)
    }
  }

  await addLog(openid, 'forum', 'cleanup', '清理' + days + '天前的帖子：' + deletedCount + '条', adminName)
  return { code: 0, message: '已清理 ' + deletedCount + ' 条帖子', data: { deletedCount: deletedCount } }
}

async function cleanDeletedPosts(openid) {
  var adminCheck = await checkSuperAdmin(openid)
  if (!adminCheck.isSuperAdmin) {
    return { code: -1, message: '仅超级管理员可执行清理操作' }
  }

  var adminName = await getAdminName(openid)

  var res = await db.collection('forum_post')
    .where({
      isDeleted: true
    })
    .get()

  var deletedCount = 0
  for (var i = 0; i < res.data.length; i++) {
    try {
      await db.collection('forum_post').doc(res.data[i]._id).remove()
      deletedCount++
    } catch (e) {
      console.error('delete error:', e)
    }
  }

  await addLog(openid, 'forum', 'cleanup', '清理已删除帖子：' + deletedCount + '条', adminName)
  return { code: 0, message: '已清理 ' + deletedCount + ' 条帖子', data: { deletedCount: deletedCount } }
}

async function cleanOrphanImages(openid) {
  var adminCheck = await checkSuperAdmin(openid)
  if (!adminCheck.isSuperAdmin) {
    return { code: -1, message: '仅超级管理员可执行清理操作' }
  }

  var adminName = await getAdminName(openid)

  await addLog(openid, 'system', 'cleanup', '清理孤立图片', adminName)
  return { code: 0, message: '孤立图片清理完成' }
}

async function getDashboardStats(openid) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var postCount = await db.collection('forum_post').where({ status: cmd.neq('deleted') }).count()
  var userCount = await db.collection('users').count()
  var orderCount = await db.collection('food_order').count()
  var runCount = await db.collection('run_stats').count()
  var pendingShops = await db.collection('food_shop').where({ auditStatus: 'pending' }).count()
  var pendingReports = await db.collection('forum_report').where({ status: 'pending' }).count()
  
  var today = new Date()
  today.setHours(0, 0, 0, 0)
  var todayStart = today.getTime()

  var todayPosts = await db.collection('forum_post')
    .where({ createTime: cmd.gte(new Date(todayStart)), status: cmd.neq('deleted') })
    .count()

  var todayOrders = await db.collection('food_order')
    .where({ createTime: cmd.gte(new Date(todayStart)) })
    .count()

  var todayOrdersData = await db.collection('food_order')
    .where({ createTime: cmd.gte(new Date(todayStart)) })
    .get()

  var todayRevenue = 0
  for (var i = 0; i < todayOrdersData.data.length; i++) {
    todayRevenue += todayOrdersData.data[i].totalPrice || 0
  }

  return {
    code: 0,
    data: {
      postCount: postCount.total,
      userCount: userCount.total,
      orderCount: orderCount.total,
      runCount: runCount.total,
      pendingShops: pendingShops.total,
      pendingReports: pendingReports.total,
      todayPosts: todayPosts.total,
      todayOrders: todayOrders.total,
      todayRevenue: todayRevenue
    }
  }
}

async function getRankList(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var keyword = data.keyword || ''
  var query = {}
  if (keyword) {
    query.nickName = db.RegExp({ regexp: keyword, options: 'i' })
  }

  var res = await db.collection('run_stats')
    .where(query)
    .orderBy('totalDistance', 'desc')
    .limit(100)
    .get()

  var list = res.data.map(function(item) {
    return {
      _id: item._id,
      nickName: item.nickName,
      avatarUrl: item.avatarUrl,
      totalDistance: item.totalDistance || 0,
      totalRuns: item.totalRuns || 0,
      updateTime: item.updateTime
    }
  })

  return { code: 0, data: { list: list } }
}

async function clearRankRecords(openid, data) {
  var adminCheck = await checkSuperAdmin(openid)
  if (!adminCheck.isSuperAdmin) {
    return { code: -1, message: '仅超级管理员可执行此操作' }
  }

  var adminName = await getAdminName(openid)
  var ids = data.ids

  if (!ids || !ids.length) {
    return { code: -1, message: '请选择要删除的记录' }
  }

  var deletedCount = 0
  for (var i = 0; i < ids.length; i++) {
    try {
      await db.collection('run_stats').doc(ids[i]).remove()
      deletedCount++
    } catch (e) {
      console.error('delete error:', e)
    }
  }

  await addLog(openid, 'running', 'delete', '删除排行榜记录：' + deletedCount + '条', adminName)
  return { code: 0, message: '已删除 ' + deletedCount + ' 条记录' }
}

async function getShopAuditList(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var status = data.status || 'pending'
  var query = {}
  if (status && status !== 'all') {
    query.auditStatus = status
  }
  if (data.keyword) {
    query.name = db.RegExp({ regexp: data.keyword, options: 'i' })
  }

  var res = await db.collection('food_shop')
    .where(query)
    .orderBy('createTime', 'desc')
    .limit(50)
    .get()

  var list = res.data.map(function(item) {
    return {
      _id: item._id,
      name: item.name,
      contact: item.contact,
      phone: item.phone,
      logo: item.logo,
      licenseImage: item.licenseImage,
      auditStatus: item.auditStatus,
      rejectReason: item.rejectReason,
      createTime: item.createTime
    }
  })

  return { code: 0, data: { list: list } }
}

async function auditShop(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var adminName = await getAdminName(openid)
  var shopId = data.shopId
  var status = data.status
  var reason = data.reason || ''

  if (!shopId || !status) {
    return { code: -1, message: '参数缺失' }
  }

  var updateData = {
    auditStatus: status,
    status: status === 'approved' ? 'open' : 'closed',
    updateTime: db.serverDate()
  }
  
  if (status === 'rejected') {
    updateData.rejectReason = reason
  }

  await db.collection('food_shop').doc(shopId).update({ data: updateData })

  if (status === 'approved') {
    var shopUser = await db.collection('food_shop_user').where({ shopId: shopId }).limit(1).get()
    if (shopUser.data.length > 0) {
      var username = 'shop_' + Date.now().toString().slice(-6)
      var password = '123456'
      await db.collection('food_shop_user').doc(shopUser.data[0]._id).update({
        data: {
          username: username,
          password: password,
          approved: true,
          updateTime: db.serverDate()
        }
      })
    }
  }

  await addLog(openid, 'food', 'audit', (status === 'approved' ? '通过' : '拒绝') + '商家审核：' + shopId, adminName)
  return { code: 0, message: status === 'approved' ? '审核通过' : '已拒绝' }
}

async function getShopManageList(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var query = { auditStatus: 'approved' }
  if (data.keyword) {
    query.name = db.RegExp({ regexp: data.keyword, options: 'i' })
  }

  var res = await db.collection('food_shop')
    .where(query)
    .orderBy('createTime', 'desc')
    .get()

  var list = res.data.map(function(item) {
    return {
      _id: item._id,
      name: item.name,
      contact: item.contact,
      phone: item.phone,
      logo: item.logo,
      status: item.status,
      rating: item.rating,
      monthlySales: item.monthlySales || 0,
      createTime: item.createTime
    }
  })

  return { code: 0, data: { list: list } }
}

async function initTestData(openid) {
  var adminCheck = await checkSuperAdmin(openid)
  if (!adminCheck.isSuperAdmin) {
    return { code: -1, message: '仅超级管理员可初始化测试数据' }
  }

  var adminName = await getAdminName(openid)

  var shopCount = await db.collection('food_shop').count().catch(function() { return { total: 0 } })
  var shopIndex = shopCount.total + 1
  
  var shopNames = ['美味食堂', '香喷喷餐厅', '好味道快餐', '鲜香阁', '食为天']
  var nameIndex = (shopIndex - 1) % shopNames.length
  var shopName = shopNames[nameIndex] + (shopIndex > 5 ? String(shopIndex) : '')
  
  var shopRes = await db.collection('food_shop').add({
    data: {
      name: shopName,
      contact: '测试商家',
      phone: '1380013' + String(shopIndex).padStart(4, '0'),
      logo: '',
      banners: [],
      status: 'open',
      auditStatus: 'approved',
      rating: (4 + Math.random()).toFixed(1),
      monthlySales: Math.floor(Math.random() * 500),
      minPrice: 10 + Math.floor(Math.random() * 10),
      deliveryFee: 2 + Math.floor(Math.random() * 3),
      notice: '欢迎光临' + shopName + '！',
      signatureDishes: [],
      createTime: db.serverDate(),
      updateTime: db.serverDate()
    }
  })

  var shopId = shopRes._id
  var username = 'shop_' + Date.now().toString().slice(-6)
  var password = '123456'

  await db.collection('food_shop_user').add({
    data: {
      bindOpenid: '',
      shopId: shopId,
      username: username,
      password: password,
      role: 'admin',
      approved: true,
      createTime: db.serverDate(),
      updateTime: db.serverDate()
    }
  })

  var dishes = [
    { name: '红烧肉', price: 28, category: '热销', description: '精选五花肉，入口即化', stock: 50 },
    { name: '宫保鸡丁', price: 22, category: '热销', description: '经典川菜，香辣可口', stock: 50 },
    { name: '鱼香肉丝', price: 20, category: '热销', description: '酸甜适中，下饭神器', stock: 50 },
    { name: '番茄炒蛋', price: 15, category: '家常菜', description: '简单美味，营养健康', stock: 50 },
    { name: '青椒肉丝', price: 18, category: '家常菜', description: '清爽下饭', stock: 50 },
    { name: '麻婆豆腐', price: 16, category: '家常菜', description: '麻辣鲜香', stock: 50 },
    { name: '可乐鸡翅', price: 25, category: '新品', description: '甜香入味，老少皆宜', stock: 30 },
    { name: '酸辣土豆丝', price: 12, category: '素菜', description: '酸辣爽口', stock: 50 },
    { name: '米饭', price: 2, category: '主食', description: '东北大米', stock: 200 },
    { name: '可乐', price: 5, category: '饮品', description: '冰镇可乐', stock: 100 }
  ]

  for (var i = 0; i < dishes.length; i++) {
    var dish = dishes[i]
    await db.collection('food_dish').add({
      data: {
        name: dish.name,
        price: dish.price,
        category: dish.category,
        description: dish.description,
        stock: dish.stock,
        shopId: shopId,
        image: '',
        isAvailable: true,
        sales: Math.floor(Math.random() * 100),
        createTime: db.serverDate(),
        updateTime: db.serverDate()
      }
    })
  }

  await addLog(openid, 'system', 'create', '初始化测试商家：' + shopName, adminName)
  return {
    code: 0,
    data: {
      shopId: shopId,
      shopName: shopName,
      loginInfo: { username: username, password: password }
    }
  }
}

async function adminUpdateShopStatus(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var adminName = await getAdminName(openid)
  var shopId = data.shopId
  var status = data.status

  if (!shopId || !status) {
    return { code: -1, message: '参数缺失' }
  }

  await db.collection('food_shop').doc(shopId).update({
    data: {
      status: status,
      updateTime: db.serverDate()
    }
  })

  await addLog(openid, 'food', 'update', '更新商家状态：' + shopId + ' -> ' + status, adminName)
  return { code: 0, message: '状态已更新' }
}

async function adminUpdateShopInfo(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var adminName = await getAdminName(openid)
  var shopId = data.shopId
  var shopData = data.shopData

  if (!shopId) {
    return { code: -1, message: '参数缺失' }
  }

  var updateData = {
    updateTime: db.serverDate()
  }
  if (shopData.name) updateData.name = shopData.name
  if (shopData.contact) updateData.contact = shopData.contact
  if (shopData.phone) updateData.phone = shopData.phone
  if (shopData.minPrice !== undefined) updateData.minPrice = Number(shopData.minPrice || 0)
  if (shopData.deliveryFee !== undefined) updateData.deliveryFee = Number(shopData.deliveryFee || 0)

  await db.collection('food_shop').doc(shopId).update({ data: updateData })

  await addLog(openid, 'food', 'update', '更新商家信息：' + shopId, adminName)
  return { code: 0, message: '信息已更新' }
}

async function adminUpdateShopAccount(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var adminName = await getAdminName(openid)
  var shopId = data.shopId
  var username = data.username
  var password = data.password

  if (!shopId) {
    return { code: -1, message: '参数缺失' }
  }
  if (!username && !password) {
    return { code: -1, message: '请输入账号或密码' }
  }

  var shopUserRes = await db.collection('food_shop_user').where({ shopId: shopId }).limit(1).get()

  if (shopUserRes.data.length) {
    var updateData = { approved: true, updateTime: db.serverDate() }
    if (username) updateData.username = username
    if (password) updateData.password = password
    await db.collection('food_shop_user').doc(shopUserRes.data[0]._id).update({ data: updateData })
  } else {
    await db.collection('food_shop_user').add({
      data: {
        shopId: shopId,
        username: username || ('shop_' + Date.now().toString().slice(-6)),
        password: password || '123456',
        approved: true,
        createTime: db.serverDate(),
        updateTime: db.serverDate()
      }
    })
  }

  await addLog(openid, 'food', 'update', '更新商家账号：' + shopId, adminName)
  return { code: 0, message: '账号已更新' }
}

async function adminResetShopPassword(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var adminName = await getAdminName(openid)
  var shopId = data.shopId

  if (!shopId) {
    return { code: -1, message: '参数缺失' }
  }

  var shopUser = await db.collection('food_shop_user').where({ shopId: shopId }).limit(1).get()
  if (shopUser.data.length === 0) {
    return { code: -1, message: '商家账号不存在' }
  }

  await db.collection('food_shop_user').doc(shopUser.data[0]._id).update({
    data: {
      password: '123456',
      updateTime: db.serverDate()
    }
  })

  await addLog(openid, 'food', 'update', '重置商家密码：' + shopId, adminName)
  return { code: 0, message: '密码已重置为 123456' }
}

async function getShopLogs(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var shopId = data.shopId
  if (!shopId) {
    return { code: -1, message: '参数缺失' }
  }

  var res = await db.collection('food_shop_logs')
    .where({ shopId: shopId })
    .orderBy('createTime', 'desc')
    .limit(100)
    .get()

  var list = res.data.map(function(item) {
    return {
      _id: item._id,
      type: item.type,
      description: item.description,
      operatorName: item.operatorName,
      createTime: item.createTime
    }
  })

  return { code: 0, data: { list: list } }
}

async function getShopDishes(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var shopId = data.shopId
  if (!shopId) {
    return { code: -1, message: '参数缺失' }
  }

  var res = await db.collection('food_dish')
    .where({ shopId: shopId })
    .orderBy('createTime', 'desc')
    .get()

  var dishes = res.data.map(function(item) {
    return {
      _id: item._id,
      name: item.name,
      price: item.price,
      category: item.category,
      image: item.image,
      isAvailable: item.isAvailable,
      stock: item.stock,
      sales: item.sales || 0,
      createTime: item.createTime
    }
  })

  return { code: 0, data: { dishes: dishes } }
}

async function getReports(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var page = data.page || 1
  var pageSize = data.pageSize || 20
  var skip = (page - 1) * pageSize

  var query = {}
  if (data.status) query.status = data.status

  var totalRes = await db.collection('forum_report').where(query).count()
  
  var res = await db.collection('forum_report')
    .where(query)
    .orderBy('createTime', 'desc')
    .skip(skip)
    .limit(pageSize)
    .get()

  var reports = res.data.map(function(item) {
    return {
      _id: item._id,
      postId: item.postId,
      postTitle: item.postTitle,
      postContent: item.postContent,
      reporterName: item.reporterName,
      reason: item.reason,
      status: item.status || 'pending',
      handleResult: item.handleResult,
      createTime: item.createTime
    }
  })

  return { code: 0, data: { list: reports, total: totalRes.total } }
}

async function handleReport(openid, data) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var adminName = await getAdminName(openid)
  var reportId = data.reportId
  var status = data.status
  var handleResult = data.handleResult || ''
  var deletePost = data.deletePost

  if (!reportId || !status) {
    return { code: -1, message: '参数缺失' }
  }

  var report = await db.collection('forum_report').doc(reportId).get()
  if (!report.data) {
    return { code: -1, message: '举报不存在' }
  }

  await db.collection('forum_report').doc(reportId).update({
    data: {
      status: status,
      handleResult: handleResult,
      handleTime: db.serverDate()
    }
  })

  if (deletePost && report.data.postId) {
    await db.collection('forum_post').doc(report.data.postId).update({
      data: { status: 'deleted', updateTime: db.serverDate() }
    })
  }

  await addLog(openid, 'forum', 'handle', '处理举报：' + reportId, adminName)
  return { code: 0, message: '已处理' }
}

async function getForumCategories(openid) {
  var adminCheck = await checkAdmin(openid)
  if (!adminCheck.isAdmin) {
    return { code: -1, message: '无权限' }
  }

  var categories = [
    { key: 'gossip', name: '闲聊灌水', icon: '💬' },
    { key: 'confession', name: '表白墙', icon: '💕' },
    { key: 'lost', name: '失物招领', icon: '🔍' },
    { key: 'job', name: '兼职互助', icon: '💼' },
    { key: 'study', name: '学习交流', icon: '📚' },
    { key: 'market', name: '二手市场', icon: '🛒' }
  ]

  return { code: 0, data: { list: categories } }
}
