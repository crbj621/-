---
name: "wechat-miniprogram-debug"
description: "微信小程序调试指南，包含常见错误排查、分包机制、TypeScript与JavaScript混用问题。Invoke when debugging WeChat miniprogram issues, especially login, subpackage, or TypeScript errors."
---

# 微信小程序调试指南

## 本次问题案例分析

### 问题描述
论坛个人中心无法显示用户信息，点击"去登录"按钮无响应，真机报错 `app.getGlobalOpenId is not a function`

### 根本原因分析

#### 1. TypeScript 与 JavaScript 文件共存问题
**现象**：同一页面存在 `mine.js` 和 `mine.ts` 两个文件
**问题**：小程序编译时优先使用 TypeScript 文件，但修改了 `.js` 文件而忽略了 `.ts` 文件
**教训**：
```
检查步骤：
1. 使用 Glob 搜索所有相关文件：**/packageForum/pages/**/*.ts 和 **/packageForum/pages/**/*.js
2. 确认实际使用的是哪个文件
3. 修改时同步更新两个文件，或删除冗余文件
```

#### 2. 方法重命名导致的兼容性问题
**现象**：`app.ts` 中方法名从 `getGlobalOpenId()` 改为 `getOpenIdSync()`
**问题**：其他模块仍在调用旧方法名
**教训**：
```typescript
// 重命名方法时，保留旧方法作为别名
getOpenIdSync() {
  // 新方法实现
}

getGlobalOpenId() {
  return this.getOpenIdSync()  // 兼容旧代码
}
```

#### 3. 分包与主包的 App 实例问题
**现象**：分包页面调用 `getApp()` 获取的 App 实例
**问题**：分包可能有独立的 `app.js`，或者主包 `app.ts` 未正确编译
**教训**：
```
检查步骤：
1. 确认分包是否有独立的 app.js
2. 检查 app.ts 是否正确编译为 app.js
3. 使用 Grep 搜索所有调用该方法的位置
```

#### 4. 异步数据获取时序问题
**现象**：openid 异步获取，但同步代码已经执行
**问题**：`loadUserInfo()` 同步执行时 openid 还未获取到
**教训**：
```javascript
// 错误做法
loadUserInfo() {
  var openid = app.getOpenIdSync()  // 可能为空
  if (!openid) {
    this.setData({ isLoggedIn: false, userInfo: null })  // 错误清空
    return
  }
}

// 正确做法
loadUserInfo() {
  var openid = app.getOpenIdSync()
  var userInfo = app.getUserInfo()  // 保留 userInfo
  
  this.setData({
    userInfo: userInfo,  // 不强制清空
    isLoggedIn: app.isLoggedIn() && !skipAuth
  })
  
  if (!openid && app.isLoggedIn()) {
    this.tryGetOpenId()  // 异步重试
  }
}
```

## 调试检查清单

### 1. 文件检查
```bash
# 搜索所有相关文件
Glob: **/pages/**/*.ts
Glob: **/pages/**/*.js

# 检查是否有重复文件
# 同一目录下同时存在 .ts 和 .js 文件时需要特别注意
```

### 2. 方法调用检查
```bash
# 搜索方法调用
Grep: getGlobalOpenId
Grep: getOpenIdSync
Grep: app.isLoggedIn
Grep: app.getUserInfo

# 确保所有调用点都已更新
```

### 3. App 实例检查
```bash
# 检查 app.ts/app.js 定义的方法
Read: miniprogram/app.ts

# 检查分包是否有独立 app.js
Glob: **/package*/app.js
```

### 4. 登录状态检查
```javascript
// 添加调试日志
console.log('=== 调试信息 ===')
console.log('isLoggedIn:', app.isLoggedIn())
console.log('userInfo:', app.getUserInfo())
console.log('openid:', app.getOpenIdSync())
console.log('skipAuth:', wx.getStorageSync('skipAuth'))
```

## 常见错误模式

### 错误 1: `xxx is not a function`
**原因**：方法未定义或方法名拼写错误
**排查**：
1. 检查 app.ts/app.js 中是否定义了该方法
2. 检查调用处的方法名拼写
3. 检查是否有 TypeScript 编译错误

### 错误 2: 数据不显示
**原因**：条件渲染逻辑错误或数据未正确设置
**排查**：
1. 检查 WXML 中的 `wx:if` 条件
2. 检查 `setData` 是否正确调用
3. 添加调试日志查看数据状态

### 错误 3: 按钮点击无响应
**原因**：CSS 样式遮挡或事件未绑定
**排查**：
1. 检查 `bindtap` 是否正确绑定
2. 检查 CSS 是否有 `pointer-events: none`
3. 检查 button 的 `::after` 伪元素

## 最佳实践

### 1. 统一登录管理
```typescript
// app.ts 中统一封装登录方法
App({
  globalData: { userInfo: null, openid: '', hasUserInfo: false },
  
  // 统一登录方法
  async doLogin(userInfo) { /* ... */ },
  
  // 统一登出方法
  doLogout() { /* ... */ },
  
  // 统一状态检查
  isLoggedIn() { /* ... */ },
  
  // 统一数据获取
  getUserInfo() { /* ... */ },
  getOpenIdSync() { /* ... } },
  
  // 兼容旧方法
  getGlobalOpenId() { return this.getOpenIdSync() }
})
```

### 2. 分包页面调用主包方法
```javascript
// 分包页面统一使用 getApp() 获取主包 App 实例
const app = getApp()
const isLoggedIn = app.isLoggedIn()
const userInfo = app.getUserInfo()
```

### 3. 条件渲染优化
```html
<!-- 使用 block 包裹条件内容 -->
<block wx:if="{{isLoggedIn && userInfo && userInfo.nickName}}">
  <!-- 已登录内容 -->
</block>
<block wx:else>
  <!-- 未登录内容 -->
</block>
```

## 问题排查流程图

```
报错: xxx is not a function
         ↓
    检查 app.ts/app.js
         ↓
    方法是否存在？ ─否→ 添加方法定义
         ↓是
    检查调用处
         ↓
    方法名是否正确？ ─否→ 修正方法名
         ↓是
    检查是否有 .ts/.js 共存
         ↓
    是否修改了错误文件？ ─是→ 修改正确的文件
         ↓否
    检查 TypeScript 编译
         ↓
    是否有编译错误？ ─是→ 修复编译错误
         ↓否
    添加兼容别名方法
```

## 记住这些教训

1. **修改方法名时保留旧方法作为别名**
2. **检查是否有 TypeScript 和 JavaScript 文件共存**
3. **使用 Grep 搜索所有调用点**
4. **添加调试日志帮助定位问题**
5. **异步数据获取要有重试机制**
6. **不要在数据未获取时强制清空已有数据**
