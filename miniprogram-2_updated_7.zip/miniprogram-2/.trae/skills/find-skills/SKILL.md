---
name: "find-skills"
description: "Searches for available skills in skill repositories. Invoke when user wants to find, search, or discover skills to install."
---

# Find Skills

This skill helps you search and discover available skills from skill repositories.

## Usage

When user wants to find skills:
1. Ask what type of skill they're looking for
2. Search available skill repositories
3. Present matching skills with descriptions
4. Help install selected skills

## Available Skill Sources

- GitHub repositories (vercel-labs/skills, etc.)
- Local skill directories
- Community skill registries

## Search Tips

- Use keywords like "frontend", "backend", "testing", etc.
- Skills are categorized by functionality
- Check skill ratings and usage stats
