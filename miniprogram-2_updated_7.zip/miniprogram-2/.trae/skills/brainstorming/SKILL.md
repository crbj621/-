***

name: "brainstorming"
description: "Socratic design refinement skill. Activates before writing code to refine rough ideas through questions and explore alternatives. Invoke when planning new features."
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# Brainstorming

This skill activates before writing code. It doesn't just jump into trying to write code. Instead, it steps back and asks what you're really trying to do.

## When to Use

- Before starting any new feature or project
- When requirements are unclear
- When exploring design alternatives
- When user says "help me plan this feature"

## Process

### 1. Understand the Goal

Ask clarifying questions to understand:

- What problem are we solving?
- Who are the users?
- What are the constraints?
- What does success look like?

### 2. Explore Alternatives

Present multiple approaches:

- Option A: \[description with pros/cons]
- Option B: \[description with pros/cons]
- Option C: \[description with pros/cons]

### 3. Present Design in Sections

Break down the design into digestible chunks:

- Architecture overview
- Data flow
- API design
- UI/UX considerations
- Security considerations

### 4. Validate with User

After each section:

- Ask if the approach makes sense
- Get confirmation before proceeding
- Adjust based on feedback

### 5. Save Design Document

Once approved:

- Create a design document
- Save to project docs
- Use as reference for implementation

## Example Questions

- "What's the main use case for this feature?"
- "Have you considered \[alternative approach]?"
- "What happens if \[edge case]?"
- "How should this handle errors?"
- "What's the expected scale/volume?"

## Output Format

```markdown
# Design: [Feature Name]

## Problem Statement
[Clear description of the problem]

## Proposed Solution
[Description of the approach]

## Alternatives Considered
- [Alternative 1]: Why not chosen
- [Alternative 2]: Why not chosen

## Implementation Plan
1. [Step 1]
2. [Step 2]
3. [Step 3]

## Open Questions
- [Question 1]
- [Question 2]
```

