---
name: "composition-patterns"
description: "React composition patterns that scale. Helps avoid boolean prop proliferation through compound components, state lifting, and internal composition. Invoke when refactoring components."
---

# React Composition Patterns

React composition patterns that scale. Helps avoid boolean prop proliferation through compound components, state lifting, and internal composition.

## When to Use

- Refactoring components with many boolean props
- Building reusable component libraries
- Designing flexible APIs
- Reviewing component architecture

## Patterns Covered

### 1. Extracting Compound Components

**Problem**: Too many props controlling different parts of a component

**Bad**:
```jsx
<Card 
  header="Title"
  showHeader={true}
  headerStyle={{}}
  body="Content"
  showBody={true}
  footer="Footer"
  showFooter={false}
/>
```

**Good**:
```jsx
<Card>
  <Card.Header>Title</Card.Header>
  <Card.Body>Content</Card.Body>
</Card>
```

### 2. Lifting State to Reduce Props

**Problem**: Passing state and handlers through multiple levels

**Bad**:
```jsx
<Parent isOpen={isOpen} onToggle={() => setIsOpen(!isOpen)}>
  <Child isOpen={isOpen} onToggle={() => setIsOpen(!isOpen)}>
    <GrandChild isOpen={isOpen} onToggle={() => setIsOpen(!isOpen)} />
  </Child>
</Parent>
```

**Good**:
```jsx
<Accordion>
  <Accordion.Item>
    <Accordion.Trigger>Click me</Accordion.Trigger>
    <Accordion.Content>Hidden content</Accordion.Content>
  </Accordion.Item>
</Accordion>
```

### 3. Composing Internals for Flexibility

**Problem**: Component is too rigid, can't customize internal parts

**Bad**:
```jsx
<List items={items} renderItem={(item) => <div>{item.name}</div>} />
```

**Good**:
```jsx
<List>
  {items.map(item => (
    <List.Item key={item.id}>
      <List.Item.Title>{item.name}</List.Item.Title>
      <List.Item.Description>{item.desc}</List.Item.Description>
    </List.Item>
  ))}
</List>
```

### 4. Avoiding Prop Drilling

**Problem**: Props passed through components that don't use them

**Bad**:
```jsx
<App theme={theme} user={user}>
  <Layout theme={theme} user={user}>
    <Sidebar theme={theme} user={user}>
      <UserMenu user={user} />
    </Sidebar>
  </Layout>
</App>
```

**Good**:
```jsx
// Use Context for truly global state
const ThemeContext = createContext();
const UserContext = createContext();

function App() {
  return (
    <ThemeProvider>
      <UserProvider>
        <Layout>
          <Sidebar>
            <UserMenu />
          </Sidebar>
        </Layout>
      </UserProvider>
    </ThemeProvider>
  );
}
```

## Best Practices

1. **Prefer children over render props** - More readable and composable
2. **Use context sparingly** - Only for truly global state
3. **Keep components small** - Each component should do one thing
4. **Use TypeScript** - Better developer experience with proper types
5. **Document composition patterns** - Show examples in Storybook or docs

## Checklist for Component Review

- [ ] Does this component have more than 5 props?
- [ ] Are there boolean props that control rendering?
- [ ] Is state being drilled through multiple levels?
- [ ] Can internal parts be customized?
- [ ] Would compound components make this cleaner?
