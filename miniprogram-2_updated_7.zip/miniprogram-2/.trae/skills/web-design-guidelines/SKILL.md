---
name: "web-design-guidelines"
description: "Review UI code for compliance with web interface best practices. Audits your code for 100+ rules covering accessibility, performance, and UX. Invoke when reviewing UI, checking accessibility, or auditing design."
---

# Web Design Guidelines

Comprehensive UI/UX audit guidelines for web interfaces.

## Categories Covered

### 1. Accessibility (Critical)
- Proper aria-labels on interactive elements
- Semantic HTML structure
- Keyboard navigation handlers
- Screen reader compatibility
- Color contrast ratios (WCAG 2.1 AA minimum: 4.5:1 for text)

### 2. Focus States (High)
- Visible focus indicators
- focus-visible patterns
- Logical tab order
- Skip navigation links

### 3. Forms (High)
- Autocomplete attributes
- Input validation
- Error handling and messaging
- Label association
- Required field indication

### 4. Animation (Medium)
- prefers-reduced-motion media query
- Compositor-friendly transforms (transform, opacity)
- Avoid layout thrashing
- Smooth transitions (150-300ms)

### 5. Typography (Medium)
- Proper quotation marks (curly quotes)
- Ellipsis for truncated text
- tabular-nums for numeric data
- Readable font sizes (16px minimum for body)

### 6. Images (High)
- Explicit dimensions to prevent CLS
- Lazy loading for below-fold images
- Descriptive alt text
- Responsive images with srcset

### 7. Performance (Critical)
- Virtualization for long lists
- Avoid layout thrashing
- Preconnect for external resources
- Debounce/throttle event handlers

### 8. Navigation & State (High)
- URL reflects application state
- Deep-linking support
- Browser history integration
- Loading states

### 9. Dark Mode & Theming (Medium)
- color-scheme meta tag
- theme-color meta tag
- CSS custom properties for theming
- System preference detection

### 10. Touch & Interaction (Medium)
- touch-action for gestures
- tap-highlight-color
- Touch target sizes (44x44px minimum)
- Prevent double-tap zoom

### 11. Locale & i18n (Medium)
- Intl.DateTimeFormat for dates
- Intl.NumberFormat for numbers
- RTL support
- Locale-aware sorting

## Pre-Delivery Checklist

- [ ] All interactive elements have focus states
- [ ] Color contrast meets WCAG AA standards
- [ ] Images have alt text or aria-hidden
- [ ] Forms have proper labels and validation
- [ ] Animations respect prefers-reduced-motion
- [ ] Touch targets are at least 44x44px
- [ ] Page is keyboard navigable
- [ ] Loading and error states are handled
- [ ] Responsive across breakpoints (375px, 768px, 1024px, 1440px)

## Common Anti-Patterns to Avoid

- Using divs instead of buttons for clickable elements
- Missing focus states on interactive elements
- Hardcoded colors instead of CSS variables
- Inline styles for dynamic theming
- Missing loading states for async operations
- Not handling edge cases (empty states, errors)
