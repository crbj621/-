---
name: "react-best-practices"
description: "React and Next.js performance optimization guidelines. Invoke when writing React components, optimizing performance, or reviewing code for best practices."
---

# React Best Practices

Performance optimization guidelines from Vercel Engineering. Contains 40+ rules across 8 categories, prioritized by impact.

## Critical Priority

### 1. Eliminating Waterfalls
- Avoid sequential data fetching when possible
- Use Promise.all for parallel requests
- Implement proper loading states
- Consider React Server Components for data fetching

### 2. Bundle Size Optimization
- Use dynamic imports for code splitting
- Lazy load components below the fold
- Analyze bundle with webpack-bundle-analyzer
- Remove unused dependencies
- Use tree-shaking compatible libraries

## High Priority

### 3. Server-Side Performance
- Optimize database queries
- Use caching strategies (Redis, CDN)
- Implement proper error handling
- Consider edge functions for global performance

### 4. Client-Side Data Fetching
- Use SWR or React Query for caching
- Implement optimistic updates
- Handle loading and error states
- Debounce rapid requests

## Medium-High Priority

### 5. Re-render Optimization
- Use React.memo for expensive components
- Implement useMemo and useCallback appropriately
- Avoid creating new objects/arrays in render
- Use stable keys in lists

## Medium Priority

### 6. Rendering Performance
- Virtualize long lists (react-window, react-virtualized)
- Use CSS transforms for animations
- Avoid layout thrashing
- Implement intersection observer for lazy loading

### 7. JavaScript Micro-optimizations
- Use optional chaining (?.) and nullish coalescing (??)
- Prefer const over let
- Use array methods over for loops when appropriate
- Avoid unnecessary type conversions

## Component Patterns

### State Management
- Lift state only as high as necessary
- Use context for global state sparingly
- Consider Zustand or Jotai for complex state
- Implement proper cleanup in useEffect

### Code Organization
- One component per file
- Co-locate related files
- Use barrel exports (index.ts)
- Separate business logic from UI

### TypeScript Best Practices
- Define proper prop types
- Use discriminated unions for complex state
- Avoid any type
- Use utility types (Pick, Omit, Partial)

## Next.js Specific

### App Router
- Use Server Components by default
- Implement proper loading.tsx and error.tsx
- Use route handlers for API routes
- Leverage parallel routes and intercepting routes

### Data Fetching
- Use fetch with proper caching options
- Implement revalidation strategies
- Use server actions for mutations
- Consider partial prerendering
