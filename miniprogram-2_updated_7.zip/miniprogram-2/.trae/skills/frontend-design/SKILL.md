---
name: "frontend-design"
description: "Frontend design guidelines for creating beautiful, accessible, and performant web interfaces. Invoke when designing UI components, reviewing layouts, or implementing responsive designs."
---

# Frontend Design Guidelines

This skill provides comprehensive guidelines for creating high-quality frontend interfaces.

## Design Principles

### 1. Visual Hierarchy
- Use size, color, and spacing to guide user attention
- Important elements should be visually prominent
- Create clear focal points on each screen

### 2. Consistency
- Maintain consistent spacing, colors, and typography
- Use design tokens for reusable values
- Follow established patterns across the application

### 3. Accessibility
- Ensure sufficient color contrast (WCAG 2.1 AA minimum)
- Provide keyboard navigation support
- Include proper ARIA labels and roles
- Support screen readers with semantic HTML

### 4. Responsive Design
- Mobile-first approach
- Use flexible grids and layouts
- Test on multiple screen sizes
- Consider touch targets (minimum 44x44px)

## Color Guidelines

- Primary: Main brand color for CTAs and emphasis
- Secondary: Supporting color for less prominent elements
- Neutral: Grays for text, borders, backgrounds
- Semantic: Success (green), Warning (yellow), Error (red), Info (blue)

## Typography

- Use a maximum of 2-3 font families
- Establish a type scale (h1-h6, body, small)
- Ensure readable line height (1.5 for body text)
- Maintain proper line length (50-75 characters)

## Spacing System

- Use 4px or 8px base unit
- Create consistent spacing scale (4, 8, 12, 16, 24, 32, 48, 64)
- Apply consistent padding and margins

## Component Patterns

### Buttons
- Clear visual affordance
- Hover and active states
- Disabled state styling
- Loading state indicator

### Forms
- Clear labels and placeholders
- Inline validation feedback
- Error messages near fields
- Logical tab order

### Cards
- Consistent padding
- Clear content hierarchy
- Subtle shadows or borders
- Hover effects for interactive cards
