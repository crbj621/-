---
name: "using-superpowers"
description: "Complete software development workflow for coding agents. Activates brainstorming, planning, TDD, and code review skills automatically. Invoke when starting any new development task."
---

# Using Superpowers

Superpowers is a complete software development workflow for your coding agents, built on top of a set of composable "skills" that make sure your agent follows best practices.

## The Basic Workflow

### 1. Brainstorming
**Activates before writing code**
- Steps back and asks what you're really trying to do
- Teases a spec out of the conversation
- Shows design in chunks short enough to digest
- Explores alternatives and validates with user

### 2. Using Git Worktrees
**Activates after design approval**
- Creates isolated workspace on new branch
- Runs project setup
- Verifies clean test baseline

### 3. Writing Plans
**Activates with approved design**
- Breaks work into bite-sized tasks (2-5 minutes each)
- Every task has exact file paths, complete code, verification steps
- Clear enough for a junior engineer to follow
- Emphasizes TDD, YAGNI, DRY

### 4. Subagent-Driven Development
**Activates with plan**
- Dispatches fresh subagent per task
- Two-stage review (spec compliance, then code quality)
- Can work autonomously for hours

### 5. Test-Driven Development
**Activates during implementation**
- Enforces RED-GREEN-REFACTOR cycle
- Write failing test → Watch it fail → Write minimal code → Watch it pass → Commit
- Deletes code written before tests

### 6. Requesting Code Review
**Activates between tasks**
- Reviews against plan
- Reports issues by severity
- Critical issues block progress

### 7. Finishing a Development Branch
**Activates when tasks complete**
- Verifies tests pass
- Presents options (merge/PR/keep/discard)
- Cleans up worktree

## Skills Library

### Testing
- `test-driven-development` - RED-GREEN-REFACTOR cycle

### Debugging
- `systematic-debugging` - 4-phase root cause process
- `verification-before-completion` - Ensure it's actually fixed

### Collaboration
- `brainstorming` - Socratic design refinement
- `writing-plans` - Detailed implementation plans
- `executing-plans` - Batch execution with checkpoints
- `dispatching-parallel-agents` - Concurrent subagent workflows
- `requesting-code-review` - Pre-review checklist
- `receiving-code-review` - Responding to feedback
- `using-git-worktrees` - Parallel development branches
- `finishing-a-development-branch` - Merge/PR decision workflow

## When to Use

- Starting any new feature or project
- User says "help me plan this feature"
- User says "let's debug this issue"
- User wants to implement something new

## Key Principles

1. **Don't jump into code** - Always start with brainstorming
2. **Validate design with user** - Get sign-off before implementation
3. **Write tests first** - TDD is mandatory, not optional
4. **Small tasks** - 2-5 minute tasks are the goal
5. **Review everything** - Code review between tasks
6. **Clean up** - Always finish by cleaning up branches

## Example Workflow

```
User: "Help me add a login feature"

Agent activates brainstorming:
→ "What authentication method do you want to use?"
→ "Should it support social login?"
→ "What are the security requirements?"

User approves design

Agent activates writing-plans:
→ Task 1: Create User model (2 min)
→ Task 2: Write login tests (3 min)
→ Task 3: Implement login logic (5 min)
→ Task 4: Add UI components (4 min)

User says "go"

Agent activates subagent-driven-development:
→ Dispatches agent for Task 1
→ Reviews output
→ Dispatches agent for Task 2
→ ...continues until complete

Agent activates finishing-a-development-branch:
→ "All tasks complete. Tests passing."
→ "Options: merge / create PR / keep branch / discard"
```

## Automatic Activation

The agent checks for relevant skills before any task. These are mandatory workflows, not suggestions. You don't need to do anything special - your coding agent just has Superpowers.
