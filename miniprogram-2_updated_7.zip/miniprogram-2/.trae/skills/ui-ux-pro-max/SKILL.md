---
name: "ui-ux-pro-max"
description: "AI-powered design intelligence for building professional UI/UX across multiple platforms. Generates design systems, analyzes patterns, and provides optimization recommendations. Invoke when designing new features or optimizing existing UI."
---

# UI/UX Pro Max - Design Intelligence Skill

## Design System Generator

The flagship feature - an AI-powered reasoning engine that analyzes project requirements and generates a complete, tailored design system.

### Output Structure

```
+----------------------------------------------------------------------------------------+
|  TARGET: [Project Name] - RECOMMENDED DESIGN SYSTEM                                    |
+----------------------------------------------------------------------------------------+
|                                                                                        |
|  PATTERN: [Pattern Name]                                                               |
|     Conversion: [Strategy]                                                             |
|     CTA: [Placement strategy]                                                          |
|     Sections: [Ordered list]                                                           |
|                                                                                        |
|  STYLE: [Style Name]                                                                   |
|     Keywords: [Descriptive keywords]                                                   |
|     Best For: [Use cases]                                                              |
|     Performance: [Rating] | Accessibility: [Rating]                                    |
|                                                                                        |
|  COLORS:                                                                               |
|     Primary:    #XXXXXX ([Name])                                                       |
|     Secondary:  #XXXXXX ([Name])                                                       |
|     CTA:        #XXXXXX ([Name])                                                       |
|     Background: #XXXXXX ([Name])                                                       |
|     Text:       #XXXXXX ([Name])                                                       |
|                                                                                        |
|  TYPOGRAPHY: [Font Pairing]                                                            |
|     Mood: [Emotional tone]                                                             |
|     Best For: [Use cases]                                                              |
|                                                                                        |
|  KEY EFFECTS:                                                                          |
|     [List of recommended effects]                                                      |
|                                                                                        |
|  AVOID (Anti-patterns):                                                                |
|     [List of patterns to avoid]                                                        |
+----------------------------------------------------------------------------------------+
```

## Design Patterns Library

### Layout Patterns
- **Hero-Centric**: Large hero section with clear CTA
- **Card Grid**: Organized content in card format
- **Dashboard**: Data-focused with widgets
- **Magazine**: Editorial-style content flow
- **Landing Page**: Conversion-optimized single page

### Style Patterns
- **Soft UI Evolution**: Soft shadows, subtle depth, calming
- **Glassmorphism**: Frosted glass effect, transparency
- **Neumorphism**: Soft extruded shapes
- **Flat Modern**: Clean, minimal, bold colors
- **Gradient Flow**: Smooth color transitions

## Color Psychology

| Color | Emotion | Best For |
|-------|---------|----------|
| Blue | Trust, Stability | Finance, Tech, Healthcare |
| Green | Growth, Nature | Wellness, Environment, Finance |
| Purple | Luxury, Creativity | Beauty, Art, Premium |
| Orange | Energy, Enthusiasm | Food, Sports, Youth |
| Red | Urgency, Passion | Sales, Food, Entertainment |
| Yellow | Optimism, Warmth | Children, Food, Leisure |

## Typography Pairings

### Professional
- Heading: Inter / Body: Inter
- Heading: Poppins / Body: Open Sans

### Editorial
- Heading: Playfair Display / Body: Lora
- Heading: Merriweather / Body: Open Sans

### Modern Tech
- Heading: Space Grotesk / Body: DM Sans
- Heading: Outfit / Body: Plus Jakarta Sans

### Luxury
- Heading: Cormorant Garamond / Body: Montserrat
- Heading: Bodoni Moda / Body: Libre Baskerville

## Pre-Delivery Checklist

- [ ] No emojis as icons (use SVG: Heroicons/Lucide)
- [ ] cursor-pointer on all clickable elements
- [ ] Hover states with smooth transitions (150-300ms)
- [ ] Light mode: text contrast 4.5:1 minimum
- [ ] Focus states visible for keyboard nav
- [ ] prefers-reduced-motion respected
- [ ] Responsive: 375px, 768px, 1024px, 1440px
- [ ] Consistent spacing using 8px grid
- [ ] Loading states for async operations
- [ ] Error states with clear recovery path

## Anti-Patterns to Avoid

- Bright neon colors in professional contexts
- Harsh animations without purpose
- AI purple/pink gradients (overused)
- Tiny touch targets (< 44px)
- Auto-playing media
- Infinite scroll without progress indicator
- Hidden navigation on mobile
- Form fields without labels
