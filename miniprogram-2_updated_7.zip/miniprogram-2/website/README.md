# 校园跑排行榜网站

这是一个独立的网站项目，用于展示校园跑小程序的排行榜数据。

## 功能特点

- 📊 实时排行榜展示（总榜、月榜、情侣榜、战神榜）
- 🔄 数据自动刷新（每30秒）
- 📱 响应式设计，支持手机和电脑访问
- 🎨 美观的UI设计

## 部署方式

### 方式一：云开发静态网站托管

1. 登录腾讯云控制台，进入云开发环境
2. 选择「静态网站托管」
3. 上传 `website` 文件夹中的所有文件
4. 访问分配的域名即可

### 方式二：本地运行

1. 安装 Node.js
2. 进入 website 目录
3. 运行本地服务器：
```bash
npx http-server -p 8080
```
4. 访问 http://localhost:8080

### 方式三：部署到其他平台

可以部署到 Vercel、Netlify、GitHub Pages 等静态网站托管平台。

## 配置说明

### 修改云开发环境ID

在 `js/app.js` 文件中修改：

```javascript
const CLOUD_ENV_ID = 'cloudbase-8gy1i7h07bd9a58c'; // 改为你的云开发环境ID
```

### 数据库权限设置

确保云开发数据库的以下集合权限设置为「所有用户可读」：

- `runRecords` - 跑步记录
- `users` - 用户信息
- `teams` - 队伍信息

### 开启匿名登录

在云开发控制台 → 设置 → 登录方式中，开启「匿名登录」。

## 文件结构

```
website/
├── index.html      # 主页面
├── css/
│   └── style.css   # 样式文件
├── js/
│   └── app.js      # 业务逻辑
└── README.md       # 说明文档
```

## 技术栈

- HTML5 + CSS3 + JavaScript
- 腾讯云开发 JavaScript SDK
- 云开发数据库

## 注意事项

1. 网站使用云开发 JavaScript SDK 直接访问数据库
2. 需要配置数据库权限允许匿名访问
3. 建议开启 HTTPS 以确保数据安全
4. 情侣榜查询较多，建议添加缓存机制

## 自定义修改

### 修改刷新间隔

在 `js/app.js` 中修改：

```javascript
// 自动刷新数据（每30秒）
setInterval(() => {
    loadRankData(currentTab);
    loadStats();
}, 30000); // 改为你需要的毫秒数
```

### 修改排行榜数量

在 `getTotalRank`、`getMonthlyRank`、`getGodRank` 函数中修改 `limit` 参数。

## 联系方式

如有问题，请联系开发团队。
