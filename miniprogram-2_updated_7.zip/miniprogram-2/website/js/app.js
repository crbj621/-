// 云开发环境配置
const CLOUD_ENV_ID = 'cloudbase-8gy1i7h07bd9a58c';

// 初始化云开发
const app = cloudbase.init({
    env: CLOUD_ENV_ID
});

// 数据库引用
const db = app.database();

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', function() {
    loadAllData();
    updateTime();
    
    // 每60秒自动刷新
    setInterval(() => {
        loadAllData();
        updateTime();
    }, 20000);
});

// 更新时间
function updateTime() {
    const now = new Date();
    const timeStr = now.toLocaleString('zh-CN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
    document.getElementById('updateTime').textContent = timeStr;
}

// 加载所有数据
async function loadAllData() {
    // 并行加载三个排行榜
    await Promise.all([
        loadGodRank(),
        loadCoupleRank(),
        loadMonthlyRank()
    ]);
    
    // 加载统计数据
    await loadStats();
}

// 加载统计数据
async function loadStats() {
    try {
        const result = await db.collection('runRecords').get();
        const records = result.data || [];
        
        // 计算总人数
        const uniqueUsers = new Set(records.map(r => r.openid));
        document.getElementById('totalRunners').textContent = uniqueUsers.size.toLocaleString();
        
        // 计算总里程
        const totalDistance = records.reduce((sum, r) => sum + (r.distance || 0), 0);
        document.getElementById('totalDistance').textContent = totalDistance.toLocaleString();
        
        // 计算跑步次数
        document.getElementById('totalRuns').textContent = records.length.toLocaleString();
    } catch (error) {
        console.error('加载统计数据失败:', error);
    }
}

// 加载战神榜
async function loadGodRank() {
    const container = document.getElementById('godList');
    
    try {
        const result = await db.collection('runRecords')
            .orderBy('distance', 'desc')
            .limit(15)
            .get();
        
        const data = result.data || [];
        
        if (data.length === 0) {
            container.innerHTML = createEmptyState();
            return;
        }
        
        container.innerHTML = data.map((item, index) => createRankItem(item, index + 1)).join('');
    } catch (error) {
        console.error('加载战神榜失败:', error);
        container.innerHTML = createEmptyState();
    }
}

// 加载月榜
async function loadMonthlyRank() {
    const container = document.getElementById('monthlyList');
    
    try {
        const now = new Date();
        const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
        const startDate = startOfMonth.toLocaleDateString('zh-CN');
        
        const result = await db.collection('runRecords')
            .where({
                date: db.command.gte(startDate)
            })
            .orderBy('distance', 'desc')
            .limit(15)
            .get();
        
        const data = result.data || [];
        
        if (data.length === 0) {
            container.innerHTML = createEmptyState();
            return;
        }
        
        container.innerHTML = data.map((item, index) => createRankItem(item, index + 1)).join('');
    } catch (error) {
        console.error('加载月榜失败:', error);
        container.innerHTML = createEmptyState();
    }
}

// 加载情侣榜
async function loadCoupleRank() {
    const container = document.getElementById('coupleList');
    
    try {
        const teamsResult = await db.collection('teams').get();
        const teams = teamsResult.data || [];
        
        const coupleRuns = [];
        
        for (const team of teams) {
            if (team.members && team.members.length >= 2) {
                const recordsResult = await db.collection('runRecords')
                    .where({
                        openid: db.command.in(team.members)
                    })
                    .get();
                
                const records = recordsResult.data || [];
                const totalDistance = records.reduce((sum, r) => sum + (r.distance || 0), 0);
                
                const members = [];
                for (const openid of team.members) {
                    const userResult = await db.collection('users')
                        .where({ openid: openid })
                        .limit(1)
                        .get();
                    if (userResult.data && userResult.data.length > 0) {
                        members.push(userResult.data[0]);
                    }
                }
                
                coupleRuns.push({
                    teamId: team._id,
                    teamName: team.teamName || '未命名队伍',
                    totalDistance: totalDistance,
                    members: members
                });
            }
        }
        
        coupleRuns.sort((a, b) => b.totalDistance - a.totalDistance);
        
        if (coupleRuns.length === 0) {
            container.innerHTML = createEmptyState('暂无情侣/组队数据');
            return;
        }
        
        container.innerHTML = coupleRuns.slice(0, 15).map((item, index) => createCoupleItem(item, index + 1)).join('');
    } catch (error) {
        console.error('加载情侣榜失败:', error);
        container.innerHTML = createEmptyState();
    }
}

// 创建排行项
function createRankItem(item, position) {
    const topClass = position <= 3 ? `top-${position}` : '';
    const avatarUrl = item.avatarUrl || 'https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0';
    const nickName = item.nickName || '匿名用户';
    const distance = item.distance || 0;
    const pace = item.pace ? item.pace.toFixed(1) + ' 分/km' : '--';
    
    return `
        <div class="rank-item ${topClass}">
            <div class="rank-position">${position}</div>
            <div class="rank-avatar">
                <img src="${avatarUrl}" alt="${nickName}">
            </div>
            <div class="rank-info">
                <div class="rank-name">${nickName}</div>
                <div class="rank-meta">配速 ${pace}</div>
            </div>
            <div class="rank-distance">
                <span class="distance-value">${distance.toLocaleString()}</span>
                <span class="distance-unit">米</span>
            </div>
        </div>
    `;
}

// 创建情侣排行项
function createCoupleItem(item, position) {
    const topClass = position <= 3 ? `top-${position}` : '';
    const members = item.members || [];
    const defaultAvatar = 'https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0';
    
    let avatarsHtml = '';
    if (members.length >= 2) {
        avatarsHtml = `
            <div class="couple-avatar">
                <img src="${members[0].avatarUrl || defaultAvatar}" alt="">
            </div>
            <span class="couple-heart">❤️</span>
            <div class="couple-avatar">
                <img src="${members[1].avatarUrl || defaultAvatar}" alt="">
            </div>
        `;
    } else if (members.length === 1) {
        avatarsHtml = `
            <div class="couple-avatar">
                <img src="${members[0].avatarUrl || defaultAvatar}" alt="">
            </div>
        `;
    }
    
    const names = members.map(m => m.nickName || '用户').join(' & ');
    
    return `
        <div class="couple-item ${topClass}">
            <div class="couple-position">${position}</div>
            <div class="couple-avatars">
                ${avatarsHtml}
            </div>
            <div class="couple-info">
                <div class="couple-names">${names}</div>
                <div class="couple-meta">${item.teamName}</div>
            </div>
            <div class="rank-distance">
                <span class="distance-value">${item.totalDistance.toLocaleString()}</span>
                <span class="distance-unit">米</span>
            </div>
        </div>
    `;
}

// 创建空状态
function createEmptyState(text = '暂无排行数据') {
    return `
        <div class="empty-state">
            <div class="empty-icon">🏃</div>
            <div class="empty-text">${text}</div>
        </div>
    `;
}
